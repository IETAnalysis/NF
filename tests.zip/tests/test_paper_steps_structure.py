from paper_pipeline import PAPER_STEP_ORDER
from node_A import algorithm_steps as sender_steps
from node_D import algorithm_steps as receiver_steps


def test_paper_step_order_has_no_embedded_parameter_values():
    assert PAPER_STEP_ORDER
    assert all(isinstance(step, str) and step for step in PAPER_STEP_ORDER)


def test_sender_paper_step_interfaces_exist():
    assert callable(sender_steps.attach_crc)
    assert callable(sender_steps.tail_biting_encode)
    assert callable(sender_steps.prepend_public_synchronization)
    assert callable(sender_steps.map_logical_positions)
    assert callable(sender_steps.construct_watermark_frame)


def test_receiver_paper_step_interfaces_exist():
    assert callable(receiver_steps.select_target_flow)
    assert callable(receiver_steps.retain_first_arrivals)
    assert callable(receiver_steps.reconstruct_temporal_reference)
    assert callable(receiver_steps.generate_candidate_grid)
    assert callable(receiver_steps.score_synchronization_candidates)
    assert callable(receiver_steps.align_dynamic_windows)
    assert callable(receiver_steps.soft_decode_candidate)
    assert callable(receiver_steps.accept_first_crc_valid)
