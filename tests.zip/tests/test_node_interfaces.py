from pathlib import Path

from node_B.channel.nfqueue_channel import classify, split_equal
from node_B.forward.kernel_forward import enable_ipv4_forwarding
from node_C.capture.interface_capture import tcpdump_command
from node_C.forward.nat_router import nat_commands


def test_b_first_arrival_classification():
    kind, intervals = classify([], 100, 80)
    assert kind == "NEW"
    assert intervals == [(100, 180)]
    assert callable(split_equal)


def test_b_and_c_public_interfaces_are_callable():
    assert callable(enable_ipv4_forwarding)
    assert tcpdump_command(
        interface="eth0", port=45133, output=Path("capture.pcap")
    )[-1] == "tcp port 45133"
    commands = nat_commands(
        ingress_iface="eth0",
        egress_iface="eth1",
        destination="192.0.2.10",
        port=45133,
    )
    assert len(commands) == 4
