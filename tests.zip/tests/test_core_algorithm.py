from node_A.code.frame_codec import (
    FIXED_SYNC_WORD,
    build_frame,
    decode_body,
    validate_crc,
)
from node_A.code.synchronization import bipolar_autocorrelation
from node_D.detect.spdw_sr_detector import build_public_plan


def test_fixed_sync_is_session_independent():
    first = build_frame(public_session_id="trial-a", payload_bits="001100110011")
    second = build_frame(public_session_id="trial-b", payload_bits="001100110011")
    assert FIXED_SYNC_WORD == "00010110"
    assert first.sync_bits == second.sync_bits == tuple(map(int, FIXED_SYNC_WORD))
    assert bipolar_autocorrelation() == [-1, 0, 1, -2, -1, 0, 1]


def test_frame_and_tbcc_roundtrip():
    frame = build_frame(public_session_id="trial", payload_bits="101001011010")
    assert len(frame.logical_bits) == 48
    assert len(frame.chip_bits) == 144
    body, _, _ = decode_body([8.0 if bit else -8.0 for bit in frame.coded_bits])
    assert body == list(frame.body_bits)
    assert validate_crc(body)


def test_receiver_plan_uses_frozen_sync():
    plan = build_public_plan("public-trial-id")
    assert plan["protocol"]["public_sync_bits"] == "00010110"
    assert plan["protocol"]["fixed_sync_word_hex"] == "0x16"

