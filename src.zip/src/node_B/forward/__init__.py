"""Node-B forwarding helpers."""
