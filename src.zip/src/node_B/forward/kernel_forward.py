"""Kernel forwarding configuration for node B."""

from __future__ import annotations

import subprocess


def enable_ipv4_forwarding(*, apply: bool = False) -> list[str]:
    command = ["sysctl", "-w", "net.ipv4.ip_forward=1"]
    if apply:
        subprocess.run(command, check=True)
    return command
