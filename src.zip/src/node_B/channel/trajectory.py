#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from common.io_utils import canonical_sha256, read_yaml, utc_now, write_json


def uniform(master_seed: str, mother_id: str, condition_id: str, block_index: int, label: str) -> float:
    key = json.dumps([master_seed, mother_id, condition_id, int(block_index), label], separators=(',', ':'))
    integer = int.from_bytes(hashlib.sha256(key.encode('utf-8')).digest()[:8], 'big')
    return integer / 2**64


def build_plan(*, protocol: dict, mother_id: str, payload_bytes: int, condition: dict) -> dict:
    block_size = int(protocol['trajectory']['byte_block_size'])
    block_count = max(1, (payload_bytes + block_size - 1) // block_size)
    master_seed = str(protocol['master_seed'])
    rows = []
    for block in range(block_count):
        jitter_u = uniform(master_seed, mother_id, condition['id'], block, 'jitter')
        loss_u = uniform(master_seed, mother_id, condition['id'], block, 'loss')
        reseg_u = uniform(master_seed, mother_id, condition['id'], block, 'resegmentation')
        rows.append({
            'block_index': block,
            'byte_start': block * block_size,
            'byte_end': min(payload_bytes, (block + 1) * block_size),
            'jitter_u': jitter_u,
            'loss_u': loss_u,
            'resegmentation_u': reseg_u,
            'jitter_ms': float(condition['jitter_max_ms']) * jitter_u,
            'loss_selected': loss_u < float(condition['loss_rate']),
            'resegmentation_selected': reseg_u < float(condition['reseg_rate']),
        })
    body = {
        'schema': 'spdw-sr-common-byte-block-trajectory-v1',
        'created_utc': utc_now(),
        'master_seed': master_seed,
        'mother_id': mother_id,
        'condition': condition,
        'payload_bytes': int(payload_bytes),
        'block_size': block_size,
        'operation_order': list(protocol['trajectory']['operation_order']),
        'blocks': rows,
    }
    body['content_sha256'] = canonical_sha256({k: v for k, v in body.items() if k not in ('created_utc', 'content_sha256')})
    return body


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--protocol', type=Path, required=True)
    parser.add_argument('--mother-id', required=True)
    parser.add_argument('--payload-bytes', type=int, required=True)
    parser.add_argument('--condition-id', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    protocol = read_yaml(args.protocol)
    conditions = {row['id']: row for row in protocol['conditions']}
    if args.condition_id not in conditions:
        raise SystemExit(f'unknown condition: {args.condition_id}')
    plan = build_plan(protocol=protocol, mother_id=args.mother_id, payload_bytes=args.payload_bytes, condition=conditions[args.condition_id])
    write_json(args.out, plan)
    print(json.dumps({'type': 'trajectory_created', 'path': str(args.out), 'sha256': plan['content_sha256']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
