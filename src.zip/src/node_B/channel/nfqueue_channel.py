#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import heapq
import itertools
import json
import signal
import socket
import statistics
import struct
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from common.io_utils import canonical_sha256, read_json, sha256_file, utc_now, write_json

SO_MARK = 36


@dataclass
class FlowState:
    base_seq: int | None = None
    intervals: list[tuple[int, int]] = field(default_factory=list)
    last_release: float = 0.0
    ipid_offset: int = 0


@dataclass
class Queued:
    kind: str
    value: Any
    arrival: float
    release: float
    row_index: int


def classify(intervals: list[tuple[int, int]], start: int, length: int) -> tuple[str, list[tuple[int, int]]]:
    end = start + length
    if any(left <= start and right >= end for left, right in intervals):
        return 'RETRANSMISSION', intervals
    if any(not (right <= start or left >= end) for left, right in intervals):
        return 'PARTIAL_OVERLAP', intervals
    merged = sorted(intervals + [(start, end)])
    result: list[tuple[int, int]] = []
    for left, right in merged:
        if not result or result[-1][1] < left:
            result.append((left, right))
        else:
            result[-1] = (result[-1][0], max(result[-1][1], right))
    return 'NEW', result


def clear_checksums(packet: Any) -> Any:
    from scapy.all import IP, TCP
    for layer, attr in ((IP, 'len'), (IP, 'chksum'), (TCP, 'chksum')):
        try:
            delattr(packet[layer], attr)
        except (AttributeError, IndexError):
            pass
    return IP(bytes(packet))


def split_equal(packet: Any, *, ipid_base: int, minimum_child: int) -> tuple[list[Any], int] | None:
    from scapy.all import IP, Raw, TCP
    payload = bytes(packet[TCP].payload)
    split = len(payload) // 2
    if split < minimum_child or len(payload) - split < minimum_child:
        return None
    pieces = (payload[:split], payload[split:])
    children = []
    for index, piece in enumerate(pieces):
        child = packet.copy()
        child[TCP].remove_payload()
        child[TCP].seq = (int(packet[TCP].seq) + (split if index else 0)) % 2**32
        original_flags = int(packet[TCP].flags)
        child[TCP].flags = original_flags if index else original_flags & ~0x09  # FIN/PSH only on final child
        child[IP].id = (ipid_base + index) % 65536
        child = child / Raw(load=piece)
        children.append(clear_checksums(child))
    if bytes(children[0][TCP].payload) + bytes(children[1][TCP].payload) != payload:
        raise RuntimeError('resegmentation byte conservation failed')
    if int(children[1][TCP].seq) != (int(packet[TCP].seq) + split) % 2**32:
        raise RuntimeError('resegmentation sequence continuity failed')
    return children, split


class Channel:
    def __init__(self, args: argparse.Namespace) -> None:
        self.args = args
        self.plan = read_json(args.trajectory)
        expected = self.plan.get('content_sha256')
        actual = canonical_sha256({k: v for k, v in self.plan.items() if k not in ('created_utc', 'content_sha256')})
        if expected != actual:
            raise ValueError('trajectory content SHA-256 mismatch')
        self.condition = self.plan['condition']
        # A CLEAN trajectory has no selected loss, resegmentation, or jitter.
        # It must be an identity channel: parsing is still retained below for
        # retransmission accounting, but target packets must not be rewritten
        # or queued merely to traverse the test harness.
        self.identity_channel = (
            float(self.condition.get('jitter_max_ms', 0.0)) == 0.0
            and float(self.condition.get('loss_rate', 0.0)) == 0.0
            and float(self.condition.get('reseg_rate', 0.0)) == 0.0
        )
        self.blocks = {int(row['block_index']): row for row in self.plan['blocks']}
        self.block_size = int(self.plan['block_size'])
        self.running = True
        self.started = time.monotonic()
        self.flows: dict[tuple[str, str, int, int], FlowState] = {}
        self.events: list[dict[str, Any]] = []
        self.heap: list[tuple[float, int, Queued]] = []
        self.counter = itertools.count()
        self.lock = threading.Lock()
        self.errors: list[str] = []
        self.stats = {
            'eligible_originals': 0,
            'retransmissions_bypassed': 0,
            'partial_overlaps_bypassed': 0,
            'loss_selected': 0,
            'dropped_originals': 0,
            'reseg_selected': 0,
            'reseg_eligible': 0,
            'reseg_emitted': 0,
            'reseg_selected_then_lost': 0,
            'injected_children': 0,
            'jittered_survivors': 0,
            'non_target': 0,
            'queue_high_water': 0,
        }
        self.actual_delays_ms: list[float] = []
        self.requested_jitter_ms: list[float] = []

    @staticmethod
    def flow_key(packet: Any) -> tuple[str, str, int, int]:
        from scapy.all import TCP
        tcp = packet[TCP]
        return str(packet.src), str(packet.dst), int(tcp.sport), int(tcp.dport)

    def target(self, packet: Any) -> bool:
        from scapy.all import TCP
        return packet.haslayer(TCP) and int(packet[TCP].dport) == self.args.port and len(bytes(packet[TCP].payload)) > 0

    def observe_syn(self, packet: Any) -> None:
        from scapy.all import TCP
        if not packet.haslayer(TCP):
            return
        tcp = packet[TCP]
        if int(tcp.dport) == self.args.port and int(tcp.flags) & 0x02 and not int(tcp.flags) & 0x10:
            self.flows.setdefault(self.flow_key(packet), FlowState()).base_seq = (int(tcp.seq) + 1) % 2**32

    def record(self, row: dict[str, Any]) -> int:
        self.events.append({'utc': utc_now(), **row})
        return len(self.events) - 1

    def plan_for(self, relative_start: int) -> dict[str, Any]:
        block = relative_start // self.block_size
        if block in self.blocks:
            return self.blocks[block]
        # TCP may carry bytes slightly beyond the declared payload because of an invalid mother manifest.
        # Such packets are accepted without disturbance and audited.
        return {
            'block_index': block,
            'jitter_ms': 0.0,
            'loss_selected': False,
            'resegmentation_selected': False,
            'out_of_plan': True,
        }

    def set_packet(self, nfpacket: Any, packet: Any) -> None:
        nfpacket.set_payload(bytes(clear_checksums(packet)))

    def queue(self, *, kind: str, value: Any, arrival: float, release: float, row: dict[str, Any]) -> None:
        if kind == 'nfpacket' and hasattr(value, 'retain'):
            value.retain()
        index = self.record({**row, 'scheduled_release_monotonic': release})
        with self.lock:
            heapq.heappush(self.heap, (release, next(self.counter), Queued(kind, value, arrival, release, index)))
            self.stats['queue_high_water'] = max(self.stats['queue_high_water'], len(self.heap))

    def raw_send(self, raw: bytes) -> None:
        from scapy.all import IP
        packet = IP(raw)
        with socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_RAW) as sock:
            sock.setsockopt(socket.SOL_SOCKET, SO_MARK, struct.pack('I', self.args.child_mark))
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
            sock.sendto(raw, (str(packet.dst), 0))

    def schedule_original(self, nfpacket: Any, state: FlowState, packet: Any, delay_ms: float, row: dict[str, Any]) -> None:
        now = time.monotonic()
        self.set_packet(nfpacket, packet)
        release = max(now + delay_ms / 1000.0, state.last_release + self.args.minimum_release_gap_s)
        state.last_release = release
        if release <= now + 1e-9:
            nfpacket.accept()
            self.record({**row, 'action': 'accept_original', 'actual_delay_ms': 0.0})
        else:
            self.queue(kind='nfpacket', value=nfpacket, arrival=now, release=release, row={**row, 'action': 'schedule_original'})

    def schedule_children(self, children: list[Any], state: FlowState, delay_ms: float, row: dict[str, Any]) -> None:
        now = time.monotonic()
        first = max(now + delay_ms / 1000.0, state.last_release + self.args.minimum_release_gap_s)
        for index, child in enumerate(children):
            release = first + index * self.args.minimum_release_gap_s
            self.queue(kind='raw', value=bytes(child), arrival=now, release=release, row={**row, 'action': 'schedule_child', 'child_index': index})
        state.last_release = first + (len(children) - 1) * self.args.minimum_release_gap_s

    def handle(self, nfpacket: Any) -> None:
        try:
            from scapy.all import IP, TCP
            packet = IP(nfpacket.get_payload())
            self.observe_syn(packet)
            if not self.target(packet):
                self.stats['non_target'] += 1
                nfpacket.accept()
                return
            tcp = packet[TCP]
            state = self.flows.setdefault(self.flow_key(packet), FlowState())
            seq = int(tcp.seq)
            payload_len = len(bytes(tcp.payload))
            if state.base_seq is None:
                state.base_seq = seq
            relative = (seq - state.base_seq) % 2**32
            category, intervals = classify(state.intervals, relative, payload_len)
            packet[IP].id = (int(packet[IP].id) + state.ipid_offset) % 65536
            if category == 'RETRANSMISSION':
                self.stats['retransmissions_bypassed'] += 1
                self.set_packet(nfpacket, packet)
                nfpacket.accept()
                self.record({'action': 'bypass_retransmission', 'tcp_seq': seq, 'relative_byte_start': relative, 'payload_len': payload_len})
                return
            if category == 'PARTIAL_OVERLAP':
                self.stats['partial_overlaps_bypassed'] += 1
                self.set_packet(nfpacket, packet)
                nfpacket.accept()
                self.record({'action': 'bypass_partial_overlap', 'tcp_seq': seq, 'relative_byte_start': relative, 'payload_len': payload_len})
                return
            state.intervals = intervals
            self.stats['eligible_originals'] += 1
            if self.identity_channel:
                # No channel operation is prescribed for CLEAN.  Avoiding a
                # needless Scapy serialize/reparse round trip keeps the
                # requested packet cadence from being changed by the harness.
                nfpacket.accept()
                return
            decision = self.plan_for(relative)
            reseg_selected = bool(decision.get('resegmentation_selected', False))
            loss_selected = bool(decision.get('loss_selected', False))
            jitter_ms = float(decision.get('jitter_ms', 0.0))
            row = {
                'tcp_seq': seq,
                'relative_byte_start': relative,
                'payload_len': payload_len,
                'block_index': decision.get('block_index'),
                'resegmentation_selected': reseg_selected,
                'loss_selected': loss_selected,
                'requested_jitter_ms': jitter_ms,
                'original_ipid': int(packet[IP].id),
                'operation_order': 'resegment>loss>jitter',
            }
            built = None
            if reseg_selected:
                self.stats['reseg_selected'] += 1
                built = split_equal(packet, ipid_base=int(packet[IP].id), minimum_child=self.args.minimum_child_payload_bytes)
                if built is not None:
                    self.stats['reseg_eligible'] += 1
                    row['split_point'] = built[1]
                else:
                    row['resegmentation_ineligible'] = True
            if loss_selected:
                self.stats['loss_selected'] += 1
                self.stats['dropped_originals'] += 1
                if built is not None:
                    self.stats['reseg_selected_then_lost'] += 1
                    state.ipid_offset = (state.ipid_offset + 1) % 65536
                nfpacket.drop()
                self.record({**row, 'action': 'drop_after_optional_resegmentation'})
                return
            if jitter_ms > 0:
                self.stats['jittered_survivors'] += 1
                self.requested_jitter_ms.append(jitter_ms)
            if built is not None:
                children, split_point = built
                self.schedule_children(children, state, jitter_ms, row)
                state.ipid_offset = (state.ipid_offset + 1) % 65536
                self.stats['reseg_emitted'] += 1
                self.stats['injected_children'] += 2
                nfpacket.drop()
                self.record({**row, 'action': 'replace_original_with_two_children', 'split_point': split_point})
                return
            self.schedule_original(nfpacket, state, packet, jitter_ms, row)
        except Exception as exc:
            self.errors.append(repr(exc))
            self.record({'action': 'callback_error_bypass', 'error': repr(exc)})
            nfpacket.accept()

    def release_loop(self) -> None:
        while self.running or self.heap:
            item = None
            with self.lock:
                if self.heap and (not self.running or self.heap[0][0] <= time.monotonic()):
                    item = heapq.heappop(self.heap)[2]
            if item is None:
                time.sleep(0.00025)
                continue
            actual = time.monotonic()
            try:
                if item.kind == 'nfpacket':
                    item.value.accept()
                else:
                    self.raw_send(item.value)
                delay = (actual - item.arrival) * 1000.0
                self.actual_delays_ms.append(delay)
                self.events[item.row_index]['actual_release_monotonic'] = actual
                self.events[item.row_index]['actual_delay_ms'] = delay
            except Exception as exc:
                self.errors.append(repr(exc))

    def write_outputs(self) -> None:
        out = self.args.output_dir
        out.mkdir(parents=True, exist_ok=True)
        with (out / 'events.csv').open('w', newline='', encoding='utf-8') as handle:
            fields: list[str] = []
            for row in self.events:
                for key in row:
                    if key not in fields:
                        fields.append(key)
            writer = csv.DictWriter(handle, fieldnames=fields, extrasaction='ignore')
            writer.writeheader()
            writer.writerows(self.events)
        n = self.stats['eligible_originals']
        summary = {
            'schema': 'spdw-sr-nfqueue-channel-result-v1',
            'terminal': True,
            'execution_valid': not self.errors and not self.heap,
            'trajectory_path': str(self.args.trajectory),
            'trajectory_file_sha256': sha256_file(self.args.trajectory),
            'condition': self.condition,
            'execution_mode': 'identity_pass_through' if self.identity_channel else 'disturbance_channel',
            'stats': self.stats,
            'actual_loss_rate': self.stats['dropped_originals'] / n if n else None,
            'actual_resegmentation_selected_rate': self.stats['reseg_eligible'] / n if n else None,
            'actual_resegmentation_observed_rate': self.stats['reseg_emitted'] / n if n else None,
            'requested_jitter_ms': {
                'count': len(self.requested_jitter_ms),
                'mean': statistics.fmean(self.requested_jitter_ms) if self.requested_jitter_ms else 0.0,
                'max': max(self.requested_jitter_ms) if self.requested_jitter_ms else 0.0,
            },
            'actual_jitter_delay_ms': {
                'count': len(self.actual_delays_ms),
                'mean': statistics.fmean(self.actual_delays_ms) if self.actual_delays_ms else 0.0,
                'max': max(self.actual_delays_ms) if self.actual_delays_ms else 0.0,
            },
            'errors': self.errors,
            'implementation_sha256': sha256_file(__file__),
            'finished_utc': utc_now(),
        }
        write_json(out / 'summary.json', summary)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--trajectory', type=Path, required=True)
    parser.add_argument('--queue', type=int, required=True)
    parser.add_argument('--port', type=int, required=True)
    parser.add_argument('--child-mark', type=int, default=68)
    parser.add_argument('--minimum-child-payload-bytes', type=int, default=64)
    parser.add_argument('--minimum-release-gap-s', type=float, default=0.000001)
    parser.add_argument('--max-runtime-s', type=float, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    try:
        from netfilterqueue import NetfilterQueue
    except ImportError as exc:
        raise SystemExit('NetfilterQueue is required') from exc
    channel = Channel(args)
    releaser = threading.Thread(target=channel.release_loop, daemon=True)
    releaser.start()
    queue = NetfilterQueue()
    queue.bind(args.queue, channel.handle, max_len=8192)

    def stop(*_args: object) -> None:
        channel.running = False
        # The main loop uses non-blocking queue dispatch, so it will observe
        # this flag even when this callback is invoked by the runtime timer.
        # Do not unbind here: unbinding from the timer thread can leave a
        # blocking queue.run() stranded until node_agent escalates to SIGKILL,
        # which loses the required terminal summary.
        if threading.current_thread() is threading.main_thread():
            raise SystemExit(0)

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    timer = threading.Timer(args.max_runtime_s, stop)
    timer.daemon = True
    timer.start()
    print('spdw_channel_ready', flush=True)
    try:
        while channel.running:
            # block=False returns after draining currently pending packets.
            # This keeps signal and timeout handling in the Python main loop
            # and guarantees the finally block below is reachable.
            queue.run(block=False)
            time.sleep(0.001)
    finally:
        channel.running = False
        try:
            queue.unbind()
        except Exception:
            pass
        releaser.join(timeout=10)
        channel.write_outputs()


if __name__ == '__main__':
    main()
