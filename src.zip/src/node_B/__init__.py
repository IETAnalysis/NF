"""Node B: forwarding and controlled channel operations."""
