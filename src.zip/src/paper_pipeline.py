"""Paper-facing map of the complete SPDW-SR processing sequence.

The sequence contains no numeric method parameters.  A caller must provide a
populated parameter set before invoking the executable stages.
"""
from __future__ import annotations

from node_A.algorithm_steps import (
    SelectiveDelayEmbedder,
    attach_crc,
    construct_watermark_frame,
    map_logical_positions,
    prepend_public_synchronization,
    tail_biting_encode,
)
from node_B.channel.trajectory import build_plan as build_disturbance_plan
from node_C.capture.interface_capture import tcpdump_command
from node_C.forward.nat_router import nat_commands
from node_D.algorithm_steps import (
    accept_first_crc_valid,
    align_dynamic_windows,
    generate_candidate_grid,
    recover_from_pcap,
    reconstruct_temporal_reference,
    retain_first_arrivals,
    score_synchronization_candidates,
    select_target_flow,
    soft_decode_candidate,
)


PAPER_STEP_ORDER = (
    "attach_crc",
    "tail_biting_encode",
    "prepend_public_synchronization",
    "map_logical_positions",
    "selective_delay_embedding",
    "controlled_channel_forwarding",
    "nat_forwarding_and_capture",
    "select_target_flow",
    "retain_first_arrivals",
    "reconstruct_temporal_reference",
    "generate_and_score_synchronization_candidates",
    "align_dynamic_windows",
    "extract_soft_metrics",
    "tail_biting_soft_decode",
    "crc_verify_or_try_next_candidate",
)


__all__ = [
    "PAPER_STEP_ORDER",
    "SelectiveDelayEmbedder",
    "accept_first_crc_valid",
    "align_dynamic_windows",
    "attach_crc",
    "build_disturbance_plan",
    "construct_watermark_frame",
    "generate_candidate_grid",
    "map_logical_positions",
    "nat_commands",
    "prepend_public_synchronization",
    "recover_from_pcap",
    "reconstruct_temporal_reference",
    "retain_first_arrivals",
    "score_synchronization_candidates",
    "select_target_flow",
    "soft_decode_candidate",
    "tail_biting_encode",
    "tcpdump_command",
]

