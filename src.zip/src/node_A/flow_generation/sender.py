"""Node-A TCP sender interface."""

from common.tcp_endpoint import load_trace, sender, set_common

__all__ = ["load_trace", "sender", "set_common"]
