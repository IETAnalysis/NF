"""Traffic-generation interfaces for node A."""
