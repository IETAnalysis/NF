"""Explicit sender-side steps corresponding to the paper method.

Core protocol parameters are imported from the intentionally blank parameter
module.  This file adds algorithm structure only and does not restore values.
"""
from __future__ import annotations

from collections.abc import Iterable

from node_A.code.frame_codec import (
    Frame,
    SPARSE3,
    build_frame,
    fixed_sync_bits,
    payload_crc_bits,
    tailbiting_encode,
)
from node_A.embed.embedder import RelativeTimingEmbedder


def attach_crc(payload: Iterable[int]) -> list[int]:
    """Append CRC(M) to a payload bit sequence."""
    payload_list = [int(bit) for bit in payload]
    return payload_list + payload_crc_bits(payload_list)


def tail_biting_encode(protected_body: Iterable[int]) -> list[int]:
    """Encode the payload-CRC body under the tail-biting constraint."""
    return tailbiting_encode([int(bit) for bit in protected_body])


def prepend_public_synchronization(coded_bits: Iterable[int]) -> list[int]:
    """Prepend the public synchronization field to coded bits."""
    return fixed_sync_bits() + [int(bit) for bit in coded_bits]


def map_logical_positions(logical_bits: Iterable[int]) -> list[int]:
    """Map logical positions to consecutive temporal-window chips."""
    return [
        int(chip)
        for bit in logical_bits
        for chip in SPARSE3[str(int(bit))]
    ]


def construct_watermark_frame(
    *, public_session_id: str, payload_bits: str
) -> Frame:
    """Run CRC, TBCC, synchronization prepend, and window mapping."""
    return build_frame(
        public_session_id=public_session_id,
        payload_bits=payload_bits,
    )


SelectiveDelayEmbedder = RelativeTimingEmbedder


__all__ = [
    "SelectiveDelayEmbedder",
    "attach_crc",
    "construct_watermark_frame",
    "map_logical_positions",
    "prepend_public_synchronization",
    "tail_biting_encode",
]

