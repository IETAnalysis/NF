"""SPDW-SR frame-code structure with core parameters intentionally blank."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

SYNC_BITS = 0
PAYLOAD_BITS = 0
CRC_BITS = 0
BODY_BITS = PAYLOAD_BITS + CRC_BITS
CODED_BITS = 2 * BODY_BITS
LOGICAL_BITS = SYNC_BITS + CODED_BITS
CHIPS_PER_LOGICAL_BIT = 0
SPARSE3: dict[str, str] = {}
CONSTRAINT_LENGTH = 0
GENERATORS_OCTAL: tuple[int, ...] = ()
CRC8_POLYNOMIAL = 0
FIXED_SYNC_WORD_HEX = 0
FIXED_SYNC_WORD = ""


def int_bits(value: int, width: int) -> list[int]:
    if not 0 <= int(value) < (1 << width):
        raise ValueError(f"value {value} does not fit {width} bits")
    return [
        (int(value) >> shift) & 1
        for shift in range(width - 1, -1, -1)
    ]


def bits_int(bits: Iterable[int]) -> int:
    value = 0
    for bit in bits:
        value = (value << 1) | int(bit)
    return value


def parse_payload_bits(payload_bits: str) -> list[int]:
    if len(payload_bits) != PAYLOAD_BITS or set(payload_bits) - {"0", "1"}:
        raise ValueError("payload must contain exactly 12 binary digits")
    return [int(bit) for bit in payload_bits]


def crc8(data: bytes) -> int:
    """CRC-8/0x07 over bytes in network-bit order.

    This helper is retained for callers that need a byte-oriented CRC.  The
    frame protocol uses :func:`payload_crc_bits` below so that its input is
    exactly the twelve payload bits, not a zero-padded 16-bit container.
    """
    value = 0
    for byte in data:
        value ^= byte
        for _ in range(8):
            value = (
                ((value << 1) ^ CRC8_POLYNOMIAL) & 0xFF
                if value & 0x80
                else (value << 1) & 0xFF
            )
    return value


def payload_crc_bits(payload_bits: Iterable[int]) -> list[int]:
    """Return CRC-8(M) for the exact twelve-bit payload stream.

    The update is MSB-first with polynomial ``x^8 + x^2 + x + 1``.  It is
    equivalent to the bit-oriented definition in the manuscript and avoids
    silently prefixing four zero bits when the payload is stored in bytes.
    """
    bits = list(map(int, payload_bits))
    if len(bits) != PAYLOAD_BITS or any(bit not in (0, 1) for bit in bits):
        raise ValueError("CRC input requires exactly 12 binary payload bits")
    value = 0
    for bit in bits:
        feedback = ((value >> 7) & 1) ^ bit
        value = (value << 1) & 0xFF
        if feedback:
            value ^= CRC8_POLYNOMIAL
    return int_bits(value, CRC_BITS)


def fixed_sync_bits() -> list[int]:
    """Return the intentionally blank fixed synchronization word."""
    if len(FIXED_SYNC_WORD) != SYNC_BITS:
        raise AssertionError("fixed synchronization word must contain 8 bits")
    return [int(bit) for bit in FIXED_SYNC_WORD]


def parity(value: int) -> int:
    return value.bit_count() & 1


def branch(state: int, bit: int) -> tuple[tuple[int, int], int]:
    register = (int(state) << 1) | int(bit)
    output = tuple(parity(register & g) for g in GENERATORS_OCTAL)
    next_state = register & ((1 << (CONSTRAINT_LENGTH - 1)) - 1)
    return (int(output[0]), int(output[1])), next_state


def tailbiting_initial_state(bits: list[int]) -> int:
    memory = CONSTRAINT_LENGTH - 1
    if len(bits) < memory:
        raise ValueError("tail-biting body is shorter than encoder memory")
    return sum(int(bits[-1 - index]) << index for index in range(memory))


def tailbiting_encode(bits: list[int]) -> list[int]:
    if len(bits) != BODY_BITS:
        raise ValueError(f"expected {BODY_BITS} body bits")
    state = tailbiting_initial_state(bits)
    initial = state
    output: list[int] = []
    for bit in bits:
        pair, state = branch(state, int(bit))
        output.extend(pair)
    if state != initial:
        raise AssertionError("tail-biting encoder path did not close")
    return output


def tailbiting_viterbi(llr: list[float]) -> tuple[list[int], float, int]:
    if len(llr) != CODED_BITS:
        raise ValueError(f"expected {CODED_BITS} coded LLRs")
    state_count = 1 << (CONSTRAINT_LENGTH - 1)
    best: tuple[list[int], float, int] | None = None
    for initial in range(state_count):
        states: dict[int, tuple[float, list[int]]] = {initial: (0.0, [])}
        for index in range(BODY_BITS):
            advanced: dict[int, tuple[float, list[int]]] = {}
            for state, (metric, path) in states.items():
                for bit in (0, 1):
                    pair, next_state = branch(state, bit)
                    score = metric
                    score += (1.0 if pair[0] else -1.0) * float(llr[2 * index])
                    score += (1.0 if pair[1] else -1.0) * float(llr[2 * index + 1])
                    prior = advanced.get(next_state)
                    if prior is None or score > prior[0]:
                        advanced[next_state] = (score, path + [bit])
            states = advanced
        closed = states.get(initial)
        if closed is not None and (best is None or closed[0] > best[1]):
            best = (closed[1], float(closed[0]), initial)
    if best is None:
        raise RuntimeError("no circular tail-biting Viterbi path")
    return best


def decode_body(transmitted_llr: list[float]) -> tuple[list[int], float, int]:
    return tailbiting_viterbi([float(value) for value in transmitted_llr])


def validate_crc(body: list[int]) -> bool:
    if len(body) != BODY_BITS:
        return False
    payload = list(map(int, body[:PAYLOAD_BITS]))
    return list(map(int, body[PAYLOAD_BITS:])) == payload_crc_bits(payload)


@dataclass(frozen=True)
class Frame:
    sync_bits: tuple[int, ...]
    payload_bits: tuple[int, ...]
    crc_bits: tuple[int, ...]
    body_bits: tuple[int, ...]
    coded_bits: tuple[int, ...]
    logical_bits: tuple[int, ...]
    chip_bits: tuple[int, ...]


def build_frame(*, public_session_id: str, payload_bits: str) -> Frame:
    # ``public_session_id`` remains in the API for manifest compatibility but
    # no longer changes protocol bits.
    _ = public_session_id
    sync = fixed_sync_bits()
    payload = parse_payload_bits(payload_bits)
    check = payload_crc_bits(payload)
    body = payload + check
    coded = tailbiting_encode(body)
    logical = sync + coded
    chips = [
        int(chip)
        for bit in logical
        for chip in SPARSE3[str(int(bit))]
    ]
    if len(logical) != LOGICAL_BITS or len(chips) != 3 * LOGICAL_BITS:
        raise AssertionError("unexpected SPDW-SR frame length")
    return Frame(
        tuple(sync), tuple(payload), tuple(check), tuple(body),
        tuple(coded), tuple(logical), tuple(chips),
    )
