"""Fixed synchronization word and autocorrelation diagnostics."""

from .frame_codec import (
    FIXED_SYNC_WORD,
    FIXED_SYNC_WORD_HEX,
    SYNC_BITS,
    fixed_sync_bits,
)


def bipolar_autocorrelation() -> list[int]:
    """Return aperiodic sidelobes for shifts 1..7."""
    values = [1 if bit else -1 for bit in fixed_sync_bits()]
    return [
        sum(values[index] * values[index + shift] for index in range(len(values) - shift))
        for shift in range(1, len(values))
    ]


__all__ = [
    "FIXED_SYNC_WORD",
    "FIXED_SYNC_WORD_HEX",
    "SYNC_BITS",
    "fixed_sync_bits",
    "bipolar_autocorrelation",
]
