"""Tail-biting convolutional-code interface."""

from .frame_codec import (
    BODY_BITS,
    CODED_BITS,
    CONSTRAINT_LENGTH,
    GENERATORS_OCTAL,
    branch,
    decode_body,
    tailbiting_encode,
    tailbiting_initial_state,
    tailbiting_viterbi,
)

__all__ = [
    "BODY_BITS", "CODED_BITS", "CONSTRAINT_LENGTH", "GENERATORS_OCTAL",
    "branch", "decode_body", "tailbiting_encode", "tailbiting_initial_state",
    "tailbiting_viterbi",
]
