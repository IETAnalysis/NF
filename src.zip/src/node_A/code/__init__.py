"""SPDW-SR frame coding primitives."""

from .frame_codec import Frame, build_frame

__all__ = ["Frame", "build_frame"]
