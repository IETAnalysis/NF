"""CRC-8(M) interface used by the paper protocol."""

from .frame_codec import CRC8_POLYNOMIAL, CRC_BITS, crc8, payload_crc_bits, validate_crc

__all__ = ["CRC8_POLYNOMIAL", "CRC_BITS", "crc8", "payload_crc_bits", "validate_crc"]
