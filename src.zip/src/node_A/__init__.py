"""Node A: traffic sender and SPDW-SR embedder."""
