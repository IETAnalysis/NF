from __future__ import annotations

import argparse
import csv
import heapq
import itertools
import json
import math
import signal
import socket
import struct
import subprocess
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from pathlib import Path


@dataclass(frozen=True)
class PulseRule:
    pair_ordinal: int
    frame_index: int
    expected_bit: str
    pair_start: float
    left_start: float
    left_end: float
    right_start: float
    right_end: float
    high_start: float
    high_end: float
    low_start: float
    low_end: float
    source_start: float
    source_end: float
    source_scan_start: float
    source_scan_end: float
    eligible_start: float
    eligible_end: float
    source_kind: str
    candidate_start: float
    candidate_end: float
    hold_start: float
    hold_end: float
    release_start: float
    release_end: float
    max_rule_delay_s: float
    logical_bit_index: int = -1
    chip_position: int = -1
    logical_bit: str = ""
    chip_bit: str = ""
    active: bool = True
    dilution_mode: str = "legacy"


@dataclass
class FlowState:
    origin: float | None = None
    last_release: float = 0.0


@dataclass
class CachedPacket:
    rel: float
    sequence: int
    tsval: int | None
    packet: object
    flow_key: tuple[str, str, int, int]
    selectable: bool = True
    source_label: str = ""


@dataclass
class QueuedPacket:
    packet: object
    accounting: dict[str, object] | None = None


@dataclass
class RuleBuffer:
    packets: list[CachedPacket] = field(default_factory=list)
    finalized: bool = False


DEFAULT_SPARSE3_CODEBOOK: dict[str, str] = {}
PAPER_NOMINAL_FRAME_START_S = 0.0
PAPER_WINDOW_S = 0.0
PAPER_LOGICAL_BITS = 0
SPREAD3_EARLY_FRACTIONS: tuple[float, ...] = ()
SPREAD3_LATE_FRACTIONS: tuple[float, ...] = ()


def parse_ipv4_tcp_metadata(
    payload: bytes,
) -> tuple[tuple[str, str, int, int], int, int, int, int | None] | None:
    """Extract the fields needed by the embedder without materializing Scapy layers.

    NFQUEUE provides an IPv4 datagram.  The embedder never modifies packet
    contents; it only needs its flow key, TCP sequence number and application
    payload length for scheduling.  A fixed-header parse keeps the normal
    non-candidate path from changing the requested send cadence.
    """
    if len(payload) < 40 or payload[0] >> 4 != 4:
        return None
    ip_header_len = (payload[0] & 0x0F) * 4
    if ip_header_len < 20 or len(payload) < ip_header_len + 20 or payload[9] != 6:
        return None
    total_length = struct.unpack_from("!H", payload, 2)[0]
    if total_length < ip_header_len + 20:
        return None
    tcp_offset = ip_header_len
    tcp_header_len = (payload[tcp_offset + 12] >> 4) * 4
    if tcp_header_len < 20 or total_length < ip_header_len + tcp_header_len:
        return None
    source = socket.inet_ntoa(payload[12:16])
    destination = socket.inet_ntoa(payload[16:20])
    sport, dport = struct.unpack_from("!HH", payload, tcp_offset)
    sequence = struct.unpack_from("!I", payload, tcp_offset + 4)[0]
    tsval: int | None = None
    option_index = tcp_offset + 20
    option_end = tcp_offset + tcp_header_len
    while option_index < option_end:
        kind = payload[option_index]
        if kind == 0:
            break
        if kind == 1:
            option_index += 1
            continue
        if option_index + 1 >= option_end:
            break
        length = payload[option_index + 1]
        if length < 2 or option_index + length > option_end:
            break
        if kind == 8 and length == 10:
            tsval = struct.unpack_from("!I", payload, option_index + 2)[0]
            break
        option_index += length
    application_length = total_length - ip_header_len - tcp_header_len
    return (source, destination, sport, dport), sequence, application_length, dport, tsval


def parse_sparse3_codebook(value: str | None) -> dict[str, str]:
    if value is None or value.strip() == "":
        return dict(DEFAULT_SPARSE3_CODEBOOK)
    codebook: dict[str, str] = {}
    for item in value.split(","):
        if ":" not in item:
            raise ValueError(f"sparse3 codebook item must be bit:chips, got {item!r}")
        bit, chips = item.split(":", 1)
        bit = bit.strip()
        chips = chips.strip()
        codebook[bit] = chips
    if set(codebook) != {"0", "1"}:
        raise ValueError(f"sparse3 codebook must define bits 0 and 1, got {sorted(codebook)}")
    for bit, chips in codebook.items():
        if len(chips) != 3 or any(chip not in "01" for chip in chips):
            raise ValueError(f"sparse3 codebook for bit {bit} must be a 3-chip binary string, got {chips!r}")
        if chips.count("1") != 1:
            raise ValueError(f"sparse3 codebook for bit {bit} must contain exactly one active chip, got {chips!r}")
    if codebook["0"] == codebook["1"]:
        raise ValueError("sparse3 codebook entries for bits 0 and 1 must differ")
    return codebook


def dilute_sparse3(frame_bits: str, codebook: dict[str, str]) -> str:
    try:
        return "".join(codebook[bit] for bit in frame_bits)
    except KeyError as exc:
        raise ValueError(f"sparse3 frame_bits contains non-binary bit: {exc.args[0]!r}") from exc


def load_rules(
    metadata_path: Path,
    *,
    dilution_mode: str = "legacy",
    sparse3_release_start_fraction: float | None = None,
    sparse3_release_end_fraction: float | None = None,
    sparse3_codebook: dict[str, str] | None = None,
) -> tuple[list[PulseRule], dict[str, object]]:
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    plan = metadata["plan"]
    config = plan["config"]
    peak = config["peak"]
    t = float(plan["t"])
    pair_gap = float(config.get("pair_gap", 0.0))
    peak_start_fraction = float(peak["peak_start_fraction"])
    peak_end_fraction = float(peak["peak_end_fraction"])
    sparse3_peak_start_fraction = (
        peak_start_fraction if sparse3_release_start_fraction is None else float(sparse3_release_start_fraction)
    )
    sparse3_peak_end_fraction = (
        peak_end_fraction if sparse3_release_end_fraction is None else float(sparse3_release_end_fraction)
    )
    if not 0.0 <= sparse3_peak_start_fraction < sparse3_peak_end_fraction <= 1.0:
        raise ValueError("sparse3 release fractions must satisfy 0 <= start < end <= 1")
    delay_limits: list[float] = []
    if peak.get("max_delay_fraction") is not None:
        delay_limits.append(float(peak["max_delay_fraction"]) * t)
    if peak.get("max_delay_cap") is not None:
        delay_limits.append(float(peak["max_delay_cap"]))
    # R003 has no explicit hard per-packet delay cap.  Infinity is an
    # internal sentinel only; JSON output records this policy as null.
    max_delay = min(delay_limits) if delay_limits else math.inf

    starts = plan["pair_starts"]
    if not math.isfinite(max_delay) and dilution_mode != "sparse3":
        raise ValueError(
            "the no-explicit-delay-cap policy is supported only for R003 Sparse3"
        )
    if dilution_mode == "sparse3":
        frame_bits = str(plan.get("frame_bits", ""))
        if len(frame_bits) != PAPER_LOGICAL_BITS or len(starts) != 3 * PAPER_LOGICAL_BITS:
            raise ValueError("SPDW-SR frame-size parameters are blank")
        if abs(t - PAPER_WINDOW_S) > 1e-12:
            raise ValueError("SPDW-SR window-duration parameter is blank")
        expected_starts = [
            PAPER_NOMINAL_FRAME_START_S + PAPER_WINDOW_S * index
            for index in range(3 * PAPER_LOGICAL_BITS)
        ]
        if any(abs(float(actual) - expected) > 1e-9 for actual, expected in zip(starts, expected_starts)):
            raise ValueError("SPDW-SR nominal-schedule parameters are blank")
        keyed = metadata.get("keyed_plan", {})
        committed_codebook = keyed.get("sparse3_codebook")
        if committed_codebook != DEFAULT_SPARSE3_CODEBOOK:
            raise ValueError(
                "private plan must commit to the paper Sparse3 codebook "
                "a configured mapping"
            )
        codebook = sparse3_codebook or dict(DEFAULT_SPARSE3_CODEBOOK)
        if codebook != committed_codebook:
            raise ValueError(
                "runtime Sparse3 codebook conflicts with the committed private plan"
            )
        chip_bits = dilute_sparse3(frame_bits, codebook)
        if len(chip_bits) != len(starts):
            raise ValueError(
                "sparse3 requires len(pair_starts)==3*len(frame_bits), "
                f"got {len(starts)} pair starts and {len(frame_bits)} frame bits"
            )

        rules: list[PulseRule] = []
        continuous_transfer = str(config.get("plan_mode", "")) == "keyed_admission_continuous"
        if continuous_transfer:
            raise ValueError(
                "cross-window Sparse3 transfer is not part of the R003 "
                "within-chip release policy"
            )
        for ordinal, (pair_start, chip_bit) in enumerate(zip(starts, chip_bits)):
            pair_start = float(pair_start)
            logical_bit_index = ordinal // 3
            chip_position = ordinal % 3
            logical_bit = frame_bits[logical_bit_index]
            active = chip_bit == "1"

            left_start = pair_start
            left_end = left_start + t
            right_start = left_end + pair_gap
            right_end = right_start + t

            release_start = left_start + sparse3_peak_start_fraction * t
            release_end = left_start + sparse3_peak_end_fraction * t
            source_scan_start = max(left_start, release_start - max_delay)
            source_scan_end = release_start
            rule_delay_cap = max_delay
            source_kind = "sparse3_active" if active else "sparse3_guard"
            eligible_start = source_scan_start
            eligible_end = source_scan_end
            hold_start = source_scan_start
            hold_end = release_start

            rules.append(
                PulseRule(
                    pair_ordinal=ordinal,
                    frame_index=logical_bit_index,
                    expected_bit=logical_bit,
                    pair_start=pair_start,
                    left_start=left_start,
                    left_end=left_end,
                    right_start=right_start,
                    right_end=right_end,
                    high_start=left_start,
                    high_end=left_end,
                    low_start=left_start,
                    low_end=left_end,
                    source_start=eligible_start,
                    source_end=eligible_end,
                    source_scan_start=source_scan_start,
                    source_scan_end=source_scan_end,
                    eligible_start=eligible_start,
                    eligible_end=eligible_end,
                    source_kind=source_kind,
                    candidate_start=source_scan_start,
                    candidate_end=source_scan_end,
                    hold_start=hold_start,
                    hold_end=hold_end,
                    release_start=release_start,
                    release_end=release_end,
                    max_rule_delay_s=rule_delay_cap,
                    logical_bit_index=logical_bit_index,
                    chip_position=chip_position,
                    logical_bit=logical_bit,
                    chip_bit=chip_bit,
                    active=active,
                    dilution_mode="sparse3",
                )
            )

        active_rules = [rule for rule in rules if rule.active]
        summary = {
            "metadata": str(metadata_path),
            "payload_bits": metadata.get("payload_bits"),
            "encoded_bits": plan.get("original_bits"),
            "frame_bits": frame_bits,
            "window_s": t,
            "pair_rules": len(rules),
            "frame_bit_count": len(frame_bits),
            "dilution_enabled": True,
                "dilution_mode": "sparse3",
                "chips_per_bit": 3,
                "codebook": codebook,
            "sparse3_release_start_fraction": sparse3_peak_start_fraction,
            "sparse3_release_end_fraction": sparse3_peak_end_fraction,
            "chip_rule_count": len(rules),
            "active_rule_count": len(active_rules),
            "guard_rule_count": len(rules) - len(active_rules),
            "chip_bits": chip_bits,
            "sparse3_transfer_semantics": "intra_pair_delay",
            "maximum_added_delay_ms": (
                1000.0 * max_delay if math.isfinite(max_delay) else None
            ),
            "explicit_maximum_added_delay_applied": math.isfinite(max_delay),
            "first_source_start_s": min(rule.source_scan_start for rule in active_rules),
            "first_rule_start_s": min(rule.source_scan_start for rule in active_rules),
            "first_release_start_s": min(rule.release_start for rule in active_rules),
            "last_rule_end_s": max(rule.release_end for rule in active_rules),
            "last_release_end_s": max(rule.release_end for rule in active_rules),
        }
        return rules, summary

    if dilution_mode == "spread3":
        frame_indices = plan["pair_frame_indices"]
        expected_bits = plan["pair_expected_bits"]
        chip_signs = plan["pair_chip_signs"]
        if not (len(starts) == len(frame_indices) == len(expected_bits) == len(chip_signs)):
            raise ValueError("spread3 metadata plan arrays have different lengths")

        rules = []
        for ordinal, (pair_start, frame_index, bit, chip_sign) in enumerate(
            zip(starts, frame_indices, expected_bits, chip_signs)
        ):
            pair_start = float(pair_start)
            bit = str(bit)
            if bit not in {"0", "1"}:
                raise ValueError(f"invalid spread3 expected bit at pair {ordinal}: {bit!r}")
            early_start = pair_start + SPREAD3_EARLY_FRACTIONS[0] * t
            early_end = pair_start + SPREAD3_EARLY_FRACTIONS[1] * t
            late_start = pair_start + SPREAD3_LATE_FRACTIONS[0] * t
            late_end = pair_start + SPREAD3_LATE_FRACTIONS[1] * t
            if bit == "0":
                release_start, release_end = early_start, early_end
                alternate_start, alternate_end = late_start, late_end
                source_kind = "spread3_early"
            else:
                release_start, release_end = late_start, late_end
                alternate_start, alternate_end = early_start, early_end
                source_kind = "spread3_late"
            source_scan_start = max(pair_start, release_start - max_delay)
            source_scan_end = release_start
            rules.append(
                PulseRule(
                    pair_ordinal=ordinal,
                    frame_index=int(frame_index),
                    expected_bit=bit,
                    pair_start=pair_start,
                    left_start=pair_start,
                    left_end=pair_start + t,
                    right_start=pair_start,
                    right_end=pair_start + t,
                    high_start=release_start,
                    high_end=release_end,
                    low_start=alternate_start,
                    low_end=alternate_end,
                    source_start=source_scan_start,
                    source_end=source_scan_end,
                    source_scan_start=source_scan_start,
                    source_scan_end=source_scan_end,
                    eligible_start=source_scan_start,
                    eligible_end=source_scan_end,
                    source_kind=source_kind,
                    candidate_start=source_scan_start,
                    candidate_end=source_scan_end,
                    hold_start=source_scan_start,
                    hold_end=source_scan_end,
                    release_start=release_start,
                    release_end=release_end,
                    max_rule_delay_s=max_delay,
                    logical_bit_index=int(frame_index),
                    chip_position=ordinal % 3,
                    logical_bit=str(plan["frame_bits"][int(frame_index)]),
                    chip_bit=bit,
                    active=True,
                    dilution_mode="spread3",
                )
            )
        return rules, {
            "metadata": str(metadata_path),
            "payload_bits": metadata.get("payload_bits"),
            "encoded_bits": plan.get("original_bits"),
            "frame_bits": plan.get("frame_bits"),
            "window_s": t,
            "pair_rules": len(rules),
            "frame_bit_count": len(plan.get("frame_bits", "")),
            "dilution_mode": "spread3",
            "copies_per_bit": int(config.get("pool_candidate_count", 3)),
            "spread3_early_start_fraction": SPREAD3_EARLY_FRACTIONS[0],
            "spread3_early_end_fraction": SPREAD3_EARLY_FRACTIONS[1],
            "spread3_late_start_fraction": SPREAD3_LATE_FRACTIONS[0],
            "spread3_late_end_fraction": SPREAD3_LATE_FRACTIONS[1],
            "first_source_start_s": min(rule.source_scan_start for rule in rules),
            "first_rule_start_s": min(rule.source_scan_start for rule in rules),
            "first_release_start_s": min(rule.release_start for rule in rules),
            "last_rule_end_s": max(rule.release_end for rule in rules),
            "last_release_end_s": max(rule.release_end for rule in rules),
        }

    if dilution_mode != "legacy":
        raise ValueError(f"unsupported dilution_mode: {dilution_mode!r}")

    frame_indices = plan["pair_frame_indices"]
    expected_bits = plan["pair_expected_bits"]
    if not (len(starts) == len(frame_indices) == len(expected_bits)):
        raise ValueError("metadata plan arrays have different lengths")

    rules: list[PulseRule] = []
    for ordinal, (pair_start, frame_index, bit) in enumerate(zip(starts, frame_indices, expected_bits)):
        pair_start = float(pair_start)
        bit = str(bit)
        if bit not in {"0", "1"}:
            raise ValueError(f"invalid expected bit at pair {ordinal}: {bit!r}")

        left_start = pair_start
        left_end = left_start + t
        right_start = left_end + pair_gap
        right_end = right_start + t

        if bit == "1":
            high_start = left_start
            high_end = left_end
            low_start = right_start
            low_end = right_end
            source_kind = "high_prefix"
        else:
            high_start = right_start
            high_end = right_end
            low_start = left_start
            low_end = left_end
            source_kind = "opposite_low"

        release_start = high_start + peak_start_fraction * t
        release_end = high_start + peak_end_fraction * t
        hold_start = release_start - max_delay
        hold_end = release_start

        if source_kind == "opposite_low":
            source_scan_start = low_start
            source_scan_end = min(low_end, release_start)
            eligible_start = max(source_scan_start, release_start - max_delay)
            eligible_end = source_scan_end
        else:
            source_scan_start = high_start
            source_scan_end = release_start
            eligible_start = max(source_scan_start, release_start - max_delay)
            eligible_end = source_scan_end
        source_start = eligible_start
        source_end = eligible_end

        rules.append(
            PulseRule(
                pair_ordinal=ordinal,
                frame_index=int(frame_index),
                expected_bit=bit,
                pair_start=pair_start,
                left_start=left_start,
                left_end=left_end,
                right_start=right_start,
                right_end=right_end,
                high_start=high_start,
                high_end=high_end,
                low_start=low_start,
                low_end=low_end,
                source_start=source_start,
                source_end=source_end,
                source_scan_start=source_scan_start,
                source_scan_end=source_scan_end,
                eligible_start=eligible_start,
                eligible_end=eligible_end,
                source_kind=source_kind,
                candidate_start=source_scan_start,
                candidate_end=source_scan_end,
                hold_start=hold_start,
                hold_end=hold_end,
                release_start=release_start,
                release_end=release_end,
                max_rule_delay_s=max_delay,
                dilution_mode=dilution_mode,
            )
        )

    summary = {
        "metadata": str(metadata_path),
        "payload_bits": metadata.get("payload_bits"),
        "encoded_bits": plan.get("original_bits"),
        "frame_bits": plan.get("frame_bits"),
        "window_s": t,
        "pair_rules": len(rules),
        "frame_bit_count": len(plan.get("frame_bits", "")),
        "dilution_mode": dilution_mode,
        "copies_per_bit": int(config.get("pool_candidate_count", 1)),
        "first_source_start_s": min(rule.source_scan_start for rule in rules),
        "first_rule_start_s": min(rule.source_scan_start for rule in rules),
        "first_release_start_s": min(rule.release_start for rule in rules),
        "last_rule_end_s": max(rule.release_end for rule in rules),
        "last_release_end_s": max(rule.release_end for rule in rules),
    }
    return rules, summary


class PlanEmbedder:
    def __init__(
        self,
        *,
        rules: list[PulseRule],
        queue_num: int,
        port: int,
        direction: str,
        origin_offset: float,
        min_release_gap: float,
        stats_interval: float,
        result_json: Path | None,
        rule_stats_csv: Path | None,
        rule_stats_json: Path | None,
        arm_file: Path | None,
        arm_timeout_s: float,
        max_runtime_s: float,
        min_rule_coverage: float,
        min_hits_per_rule: int,
        auto_align: bool,
        warmup_s: float,
        hold_extra_s: float,
        window_cache_s: float,
        fallback_window_s: float,
        max_hits_per_rule: int,
        max_rule_delay_s: float | None,
        release_inner_start_fraction: float,
        release_inner_end_fraction: float,
        release_jitter_fraction: float,
        fallback_delay_multiplier: float,
        source_scan_extra_s: float,
        align_search_s: float,
        align_step_s: float,
        align_min_packets: int,
        auto_align_max_offset_s: float,
        deadline_guard_s: float = 0.0,
        selective_queue: bool = False,
        iptables_rule_record: Path | None = None,
        queue_gate_lead_s: float = 0.010,
        queue_gate_tail_s: float = 0.005,
    ) -> None:
        self.rules = rules
        self.dilution_mode = next((rule.dilution_mode for rule in rules if rule.dilution_mode != "legacy"), "legacy")
        self.active_rule_indices = [rule.pair_ordinal for rule in rules if rule.active]
        self.guard_rule_indices = [rule.pair_ordinal for rule in rules if not rule.active]
        self.queue_num = queue_num
        self.port = port
        self.direction = direction
        self.origin_offset = origin_offset
        self.effective_offset_s: float | None = origin_offset if not auto_align else None
        self.auto_align = auto_align
        self.warmup_s = warmup_s
        self.hold_extra_s = hold_extra_s
        self.window_cache_s = window_cache_s
        self.fallback_window_s = fallback_window_s
        self.max_hits_per_rule = max(int(max_hits_per_rule), 1)
        self.max_rule_delay_s = (
            math.inf
            if max_rule_delay_s is None
            else max(float(max_rule_delay_s), 0.0)
        )
        # Reserve a small implementation margin inside the configured cap.
        # The configured cap remains the audit limit; this guard prevents
        # scheduler/FIFO jitter from consuming the whole budget.
        self.deadline_guard_s = max(float(deadline_guard_s), 0.0)
        self.release_inner_start_fraction = float(release_inner_start_fraction)
        self.release_inner_end_fraction = float(release_inner_end_fraction)
        self.release_jitter_fraction = max(float(release_jitter_fraction), 0.0)
        self.fallback_delay_multiplier = max(float(fallback_delay_multiplier), 1.0)
        self.source_scan_extra_s = max(float(source_scan_extra_s), 0.0)
        self.rules_by_release_time = sorted(
            rules,
            key=lambda rule: (rule.release_start, rule.release_end, rule.pair_ordinal),
        )
        self.rules_by_scan_time = sorted(
            rules,
            key=lambda rule: (self.scan_start_for_rule(rule), rule.release_start, rule.pair_ordinal),
        )
        self.active_rules_by_scan_time = [rule for rule in self.rules_by_scan_time if rule.active]
        self.align_search_s = max(float(align_search_s), 0.0)
        self.align_step_s = max(float(align_step_s), 0.001)
        self.align_min_packets = max(int(align_min_packets), 1)
        self.auto_align_max_offset_s = max(float(auto_align_max_offset_s), 0.0)
        self.selective_queue = bool(selective_queue)
        self.iptables_rule_record = iptables_rule_record
        self.queue_gate_lead_s = max(float(queue_gate_lead_s), 0.0)
        self.queue_gate_tail_s = max(float(queue_gate_tail_s), 0.0)
        self.selective_queue_transitioned = False
        self.selective_queue_transition_error: str | None = None
        self.selective_queue_origin: float | None = None
        self.selective_gate_rule: PulseRule | None = None
        self.selective_gate_opens = 0
        self.selective_gate_closes = 0
        self.selective_gate_open_lateness_ms: list[float] = []
        self.selective_gate_close_lateness_ms: list[float] = []
        self.selective_gate_events: list[dict[str, object]] = []
        self.iptables_lock = threading.Lock()
        self.first_rule_start_s = min((self.scan_start_for_rule(rule) for rule in self.rules_by_scan_time), default=0.0)
        self.warmup_rel_times: list[float] = []
        self.auto_align_delta_s = 0.0
        self.auto_align_score: dict[str, object] = {}
        self.first_matched_packet_monotonic: float | None = None
        self.first_matched_packet_rel_s: float | None = None
        self.first_matched_packet_utc: str | None = None
        self.embed_start_utc: str | None = None
        self.min_release_gap = min_release_gap
        self.stats_interval = stats_interval
        self.result_json = result_json
        self.rule_stats_csv = rule_stats_csv
        self.rule_stats_json = rule_stats_json
        self.arm_file = arm_file
        self.arm_timeout_s = arm_timeout_s
        self.max_runtime_s = max_runtime_s
        self.min_rule_coverage = min_rule_coverage
        self.min_hits_per_rule = min_hits_per_rule
        self.armed_monotonic: float | None = None
        self.armed_utc: str | None = None
        self.states: dict[tuple[str, str, int, int], FlowState] = defaultdict(FlowState)
        self.rule_buffers: dict[tuple[tuple[str, str, int, int], int], RuleBuffer] = {}
        self.heap: list[tuple[float, int, object]] = []
        self.counter = itertools.count()
        self.lock = threading.Lock()
        self.cache_lock = threading.Lock()
        self.running = True
        self.stop_reason = "running"
        self.matched_packets = 0
        self.targeted_packets = 0
        self.targeted_packet_ids: set[str] = set()
        self.fifo_packets = 0
        self.delayed_packets = 0
        self.delayed_packet_ids: set[str] = set()
        self.accepted_packets = 0
        self.prearm_packets = 0
        self.warmup_packets = 0
        self.error_count = 0
        self.delay_sum_s = 0.0
        self.max_delay_s = 0.0
        self.delay_samples: list[dict[str, object]] = []
        self.queue_high_water = 0
        self.rule_hits = [0 for _ in rules]
        self.cached_packets = 0
        self.cache_flushed_packets = 0
        self.cache_selected_packets = 0
        self.cache_unselected_packets = 0
        self.cache_blocked_packets = 0
        self.cache_high_water = 0
        self.strict_selected_packets = 0
        self.fallback_selected_packets = 0
        self.feasible_suffix_rules = 0
        self.fallback_suffix_rules = 0
        self.no_eligible_suffix_rules = 0
        self.finalized_rules = 0
        self.finalized_rules_with_selection = 0
        self.finalized_rules_without_selection = 0
        self.eligible_suffix_histogram: dict[int, int] = defaultdict(int)
        self.candidate_hits = [0 for _ in rules]
        self.source_low_hits = [0 for _ in rules]
        self.source_pre_high_hits = [0 for _ in rules]
        self.fallback_hits = [0 for _ in rules]
        self.natural_high_hits = [0 for _ in rules]
        self.guard_natural_hits = [0 for _ in rules]
        self.pre_pair_candidate_hits = [0 for _ in rules]
        self.pre_pair_selected_by_rule = [0 for _ in rules]
        self.pre_pair_delayed_by_rule = [0 for _ in rules]
        self.high_prefix_candidate_hits = [0 for _ in rules]
        self.high_prefix_selected_by_rule = [0 for _ in rules]
        self.high_prefix_delayed_by_rule = [0 for _ in rules]
        self.strict_selected_by_rule = [0 for _ in rules]
        self.fallback_selected_by_rule = [0 for _ in rules]
        self.cache_selected_by_rule = [0 for _ in rules]
        self.cache_unselected_by_rule = [0 for _ in rules]
        self.no_candidate_by_rule = [0 for _ in rules]
        self.no_feasible_suffix_by_rule = [0 for _ in rules]
        self.delay_cap_reject_by_rule = [0 for _ in rules]
        self.nonpositive_delay_reject_by_rule = [0 for _ in rules]
        self.finalized_by_rule = [0 for _ in rules]
        self.finalized_with_selection_by_rule = [0 for _ in rules]
        self.finalized_without_selection_by_rule = [0 for _ in rules]
        self.skipped_quota_packets = 0
        self.skipped_delay_cap_packets = 0
        self.selection_order_cap_rejects = 0
        self.selection_order_cap_retries = 0
        self.selection_order_cap_recovered_rules = 0
        self.skipped_nonpositive_delay_packets = 0
        self.fifo_extra_delay_packets = 0
        self.fifo_extra_delay_sum_s = 0.0
        self.fifo_extra_delay_max_s = 0.0
        self.fifo_deadline_abort_packets = 0
        self.actual_delay_cap_violation_packets = 0
        self.actual_delay_cap_violation_max_s = 0.0
        self.started_monotonic = time.monotonic()
        self.started_utc = datetime.now(timezone.utc).isoformat(timespec="milliseconds")

    def current_effective_offset(self) -> float:
        return self.effective_offset_s if self.effective_offset_s is not None else self.origin_offset

    def queue_rule_arguments(self) -> list[str]:
        """Return the exact OUTPUT rule installed by node_agent for this embedder.

        The dynamic gate is deliberately constrained to the same test port and
        NFQUEUE number as the short bootstrap rule.  It never changes packet
        contents or any unrelated firewall rule.
        """
        return [
            "iptables", "-t", "filter", "-I", "OUTPUT", "1", "-p", "tcp",
            "--dport", str(self.port), "-j", "NFQUEUE", "--queue-num",
            str(self.queue_num), "--queue-bypass",
        ]

    @staticmethod
    def delete_queue_rule_arguments(rule: list[str]) -> list[str]:
        delete = list(rule)
        insert_index = delete.index("-I")
        delete[insert_index] = "-D"
        # iptables -D does not accept the insertion ordinal after the chain.
        delete.pop(insert_index + 2)
        return delete

    def write_queue_rule_record(self, rule: list[str] | None) -> None:
        if self.iptables_rule_record is None:
            return
        if rule is None:
            self.iptables_rule_record.unlink(missing_ok=True)
            return
        self.iptables_rule_record.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.iptables_rule_record.with_suffix(".tmp")
        temporary.write_text(
            json.dumps(
                {
                    "rule": rule,
                    "created_utc": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
                    "owner": "nfqueue_plan_embedder_selective_gate",
                },
                ensure_ascii=False,
            ) + "\n",
            encoding="utf-8",
        )
        temporary.replace(self.iptables_rule_record)

    def run_iptables(self, command: list[str], *, action: str) -> bool:
        completed = subprocess.run(
            command,
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if completed.returncode == 0:
            return True
        self.error_count += 1
        self.selective_queue_transition_error = (
            f"iptables_{action}_failed_returncode_{completed.returncode}"
        )
        print(
            json.dumps(
                {
                    "type": "selective_queue_iptables_error",
                    "action": action,
                    "returncode": completed.returncode,
                    "command": command,
                },
                ensure_ascii=False,
            ),
            flush=True,
        )
        return False

    def transition_to_selective_queue(self, *, origin: float) -> None:
        """Remove the bootstrap full-flow rule after the watermark clock exists."""
        if not self.selective_queue or self.selective_queue_transitioned:
            return
        if self.iptables_rule_record is None:
            self.error_count += 1
            self.selective_queue_transition_error = "missing_iptables_rule_record"
            return
        bootstrap_rule = self.queue_rule_arguments()
        try:
            record = json.loads(self.iptables_rule_record.read_text(encoding="utf-8"))
            recorded_rule = list(map(str, record["rule"]))
        except Exception as exc:
            self.error_count += 1
            self.selective_queue_transition_error = f"bootstrap_rule_record_error:{exc!r}"
            return
        if recorded_rule != bootstrap_rule:
            self.error_count += 1
            self.selective_queue_transition_error = "bootstrap_rule_record_mismatch"
            return
        with self.iptables_lock:
            if not self.run_iptables(
                self.delete_queue_rule_arguments(bootstrap_rule),
                action="remove_bootstrap",
            ):
                return
            self.write_queue_rule_record(None)
            self.selective_queue_transitioned = True
            self.selective_queue_origin = origin
        print(
            json.dumps(
                {
                    "type": "selective_queue_bootstrap_removed",
                    "origin_monotonic": origin,
                    "active_windows_planned": len(self.active_rules_by_scan_time),
                    "gate_lead_s": self.queue_gate_lead_s,
                    "gate_tail_s": self.queue_gate_tail_s,
                },
                ensure_ascii=False,
            ),
            flush=True,
        )

    def open_selective_gate(self, rule: PulseRule, *, scheduled_open: float) -> None:
        if self.selective_gate_rule is not None:
            return
        queue_rule = self.queue_rule_arguments()
        with self.iptables_lock:
            if not self.run_iptables(queue_rule, action="open_gate"):
                return
            self.write_queue_rule_record(queue_rule)
            actual = time.monotonic()
            lateness_ms = 1000.0 * (actual - scheduled_open)
            self.selective_gate_rule = rule
            self.selective_gate_opens += 1
            self.selective_gate_open_lateness_ms.append(lateness_ms)
            self.selective_gate_events.append(
                {
                    "event": "open",
                    "pair_ordinal": rule.pair_ordinal,
                    "scheduled_monotonic": scheduled_open,
                    "actual_monotonic": actual,
                    "lateness_ms": lateness_ms,
                }
            )

    def close_selective_gate(self, *, scheduled_close: float | None = None) -> None:
        if self.selective_gate_rule is None:
            return
        rule = self.selective_gate_rule
        queue_rule = self.queue_rule_arguments()
        with self.iptables_lock:
            if not self.run_iptables(
                self.delete_queue_rule_arguments(queue_rule),
                action="close_gate",
            ):
                return
            self.write_queue_rule_record(None)
            actual = time.monotonic()
            lateness_ms = (
                1000.0 * (actual - scheduled_close)
                if scheduled_close is not None
                else None
            )
            self.selective_gate_rule = None
            self.selective_gate_closes += 1
            if lateness_ms is not None:
                self.selective_gate_close_lateness_ms.append(lateness_ms)
            self.selective_gate_events.append(
                {
                    "event": "close",
                    "pair_ordinal": rule.pair_ordinal,
                    "scheduled_monotonic": scheduled_close,
                    "actual_monotonic": actual,
                    "lateness_ms": lateness_ms,
                }
            )

    def maintain_selective_queue(self) -> None:
        """Open NFQUEUE only around active candidate windows after bootstrap.

        Candidate buffering ends at scan_end_for_rule().  A small lead is used
        only to cover the firewall-command latency; all early packets still go
        through normal source-window eligibility checks and are accepted.
        """
        if (
            not self.selective_queue
            or not self.selective_queue_transitioned
            or self.selective_queue_origin is None
        ):
            return
        now = time.monotonic()
        anchor = self.selective_queue_origin + self.current_effective_offset()
        desired_rule: PulseRule | None = None
        desired_open: float | None = None
        desired_close: float | None = None
        for rule in self.active_rules_by_scan_time:
            open_at = anchor + self.scan_start_for_rule(rule) - self.queue_gate_lead_s
            # The source-candidate scan ends before the delayed packet is
            # released.  Dropping the NFQUEUE rule at scan_end could race
            # with a packet retained for the rule's release subwindow.  Keep
            # the gate installed through the last legal release instant so
            # the kernel classification remains stable while queued packets
            # are drained in sequence order.
            close_at = anchor + max(
                self.scan_end_for_rule(rule), rule.release_end
            ) + self.queue_gate_tail_s
            if open_at <= now < close_at:
                desired_rule = rule
                desired_open = open_at
                desired_close = close_at
                break
            if open_at > now:
                break
        if desired_rule is not None:
            if self.selective_gate_rule is None:
                self.open_selective_gate(desired_rule, scheduled_open=desired_open or now)
            return
        if self.selective_gate_rule is not None:
            close_at = anchor + max(
                self.scan_end_for_rule(self.selective_gate_rule),
                self.selective_gate_rule.release_end,
            ) + self.queue_gate_tail_s
            self.close_selective_gate(scheduled_close=close_at)

    def cleanup_selective_queue(self) -> None:
        if self.selective_gate_rule is not None:
            self.close_selective_gate()

    def scan_start_for_rule(self, rule: PulseRule) -> float:
        # A forward scan extension can expose packets that cannot reach the
        # release subwindow without exceeding the protocol delay cap.  Such
        # packets used to consume the per-rule candidate quota and then wait
        # until finalization, which could itself exceed the cap.  Restrict the
        # runtime candidate window to packets that have at least one legal
        # release instant.
        release_lo, _ = self.release_subwindow(rule)
        earliest_feasible = release_lo - self.max_allowed_delay_for_rule(rule)
        return max(
            0.0,
            rule.source_scan_start - self.source_scan_extra_s,
            earliest_feasible,
        )

    def scan_end_for_rule(self, rule: PulseRule) -> float:
        return min(rule.release_start, rule.source_scan_end + self.source_scan_extra_s)

    def score_offset(self, rel_times: list[float], offset: float) -> tuple[int, int]:
        hit_rules: set[int] = set()
        candidate_count = 0
        for raw_rel in rel_times:
            shifted = raw_rel - offset
            if shifted < 0.0:
                continue
            candidate = False
            for rule in self.active_rules_by_scan_time:
                if self.scan_start_for_rule(rule) <= shifted < self.scan_end_for_rule(rule):
                    hit_rules.add(rule.pair_ordinal)
                    candidate_count += 1
                    candidate = True
                    break
                if self.scan_start_for_rule(rule) > shifted:
                    break
            if candidate:
                continue
            in_release = False
            for rule in self.rules_by_release_time:
                if rule.release_start <= shifted < rule.release_end:
                    in_release = True
                    break
                if rule.release_start > shifted:
                    break
            if in_release:
                continue
        return len(hit_rules), candidate_count

    def choose_auto_align_offset(self, *, raw_rel: float) -> float:
        rel_times = self.warmup_rel_times or [raw_rel]
        raw_base_offset = raw_rel - self.first_rule_start_s
        base_offset = raw_base_offset
        offset_capped = False
        if self.auto_align_max_offset_s > 0.0 and raw_base_offset > self.auto_align_max_offset_s:
            base_offset = max(0.0, self.warmup_s - self.first_rule_start_s)
            offset_capped = True
        steps = int(round(self.align_search_s / self.align_step_s))
        best_offset = base_offset
        best_score = (-1, -1, 0.0)

        for index in range(-steps, steps + 1):
            offset = base_offset + index * self.align_step_s
            rules_hit, candidate_count = self.score_offset(rel_times, offset)
            score = (rules_hit, candidate_count, -abs(offset - base_offset))
            if score > best_score:
                best_score = score
                best_offset = offset

        self.auto_align_delta_s = best_offset - base_offset
        self.auto_align_score = {
            "rules_hit": best_score[0],
            "candidate_count": best_score[1],
            "raw_base_offset_s": raw_base_offset,
            "base_offset_s": base_offset,
            "chosen_offset_s": best_offset,
            "delta_s": self.auto_align_delta_s,
            "samples": len(rel_times),
            "max_offset_s": self.auto_align_max_offset_s,
            "offset_capped": offset_capped,
        }
        return best_offset

    def establish_auto_alignment(self, *, now: float, raw_rel: float) -> None:
        utc = datetime.now(timezone.utc)
        self.effective_offset_s = self.choose_auto_align_offset(raw_rel=raw_rel)
        self.first_matched_packet_monotonic = now
        self.first_matched_packet_rel_s = raw_rel
        self.first_matched_packet_utc = utc.isoformat(timespec="milliseconds")
        self.embed_start_utc = (utc - timedelta(seconds=self.first_rule_start_s)).isoformat(timespec="milliseconds")
        print(
            json.dumps(
                {
                    "type": "plan_embedder_auto_aligned",
                    "raw_rel_s": raw_rel,
                    "first_rule_start_s": self.first_rule_start_s,
                    "effective_offset_s": self.effective_offset_s,
                    "auto_align_delta_s": self.auto_align_delta_s,
                    "auto_align_score": self.auto_align_score,
                    "embed_start_utc": self.embed_start_utc,
                    "first_matched_packet_utc": self.first_matched_packet_utc,
                    "warmup_s": self.warmup_s,
                },
                ensure_ascii=False,
            ),
            flush=True,
        )

    def load_arm_time(self) -> float | None:
        if self.armed_monotonic is not None:
            return self.armed_monotonic
        if self.arm_file is None:
            self.armed_monotonic = time.monotonic()
            self.armed_utc = self.started_utc
            return self.armed_monotonic
        try:
            raw = json.loads(self.arm_file.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return None
        except Exception as exc:
            self.error_count += 1
            print(json.dumps({"type": "embedder_arm_error", "error": repr(exc)}), flush=True)
            return None
        try:
            self.armed_monotonic = float(raw["armed_monotonic"])
        except (KeyError, TypeError, ValueError) as exc:
            self.error_count += 1
            print(json.dumps({"type": "embedder_arm_error", "error": repr(exc), "arm_file": str(self.arm_file)}), flush=True)
            return None
        self.armed_utc = str(raw.get("armed_utc", ""))
        print(
            json.dumps(
                {
                    "type": "plan_embedder_armed",
                    "arm_file": str(self.arm_file),
                    "armed_monotonic": self.armed_monotonic,
                    "armed_utc": self.armed_utc,
                },
                ensure_ascii=False,
            ),
            flush=True,
        )
        return self.armed_monotonic

    def port_matches(self, tcp) -> bool:
        value = tcp.dport if self.direction == "dport" else tcp.sport
        return int(value) == self.port

    def max_allowed_delay_for_rule(self, rule: PulseRule, *, fallback: bool = False) -> float:
        # An optional configured cap applies equally to strict and fallback
        # selection.  R003 leaves this unbounded within the chip release plan.
        max_allowed = (
            self.max_rule_delay_s
            if self.max_rule_delay_s > 0.0
            else rule.max_rule_delay_s
        )
        max_allowed = min(max_allowed, rule.max_rule_delay_s)
        if self.window_cache_s > 0.0:
            max_allowed = min(max_allowed, self.window_cache_s)
        if math.isfinite(max_allowed) and self.deadline_guard_s > 0.0:
            max_allowed = max(0.0, max_allowed - self.deadline_guard_s)
        return max_allowed

    def _max_allowed_delay(self, rule: PulseRule) -> float:
        return self.max_allowed_delay_for_rule(rule)

    def release_subwindow(self, rule: PulseRule) -> tuple[float, float]:
        span = max(rule.release_end - rule.release_start, 1e-6)
        inner_lo = float(self.release_inner_start_fraction)
        inner_hi = float(self.release_inner_end_fraction)
        if inner_hi <= inner_lo:
            inner_lo, inner_hi = 0.02, 0.45

        lo = rule.release_start + span * inner_lo
        hi = rule.release_start + span * inner_hi
        lo = min(max(lo, rule.release_start), rule.release_end)
        hi = min(max(hi, lo + 1e-6), rule.release_end)
        return lo, hi

    def feasible_release_interval(
        self,
        rule: PulseRule,
        item: CachedPacket,
        *,
        fallback: bool = False,
    ) -> tuple[float, float] | None:
        release_lo, release_hi = self.release_subwindow(rule)
        max_delay = self.max_allowed_delay_for_rule(rule, fallback=fallback)

        earliest_by_packet = item.rel + 1e-6
        latest_by_delay = item.rel + max_delay
        lo = max(release_lo, earliest_by_packet)
        hi = min(release_hi, latest_by_delay)
        if lo <= hi:
            return lo, hi
        return None

    def note_feasible_reject(self, rule: PulseRule, item: CachedPacket, *, fallback: bool = False) -> None:
        release_lo, release_hi = self.release_subwindow(rule)
        max_delay = self.max_allowed_delay_for_rule(rule, fallback=fallback)
        if item.rel + max_delay < release_lo:
            self.delay_cap_reject_by_rule[rule.pair_ordinal] += 1
        elif item.rel >= release_hi:
            self.nonpositive_delay_reject_by_rule[rule.pair_ordinal] += 1
        else:
            self.no_feasible_suffix_by_rule[rule.pair_ordinal] += 1

    def runtime_candidate_start(self, rule: PulseRule) -> float:
        return self.scan_start_for_rule(rule)

    def active_buffer_key(self, flow_key: tuple[str, str, int, int]) -> tuple[tuple[str, str, int, int], int] | None:
        with self.cache_lock:
            active = [
                key
                for key, buffer in self.rule_buffers.items()
                if key[0] == flow_key and not buffer.finalized and buffer.packets
            ]
        if not active:
            return None
        return min(active, key=lambda item: (self.scan_end_for_rule(self.rules[item[1]]), item[1]))

    def rule_has_buffered_candidates(self, flow_key: tuple[str, str, int, int], ordinal: int) -> bool:
        with self.cache_lock:
            buffer = self.rule_buffers.get((flow_key, ordinal))
            return bool(buffer is not None and not buffer.finalized and buffer.packets)

    def pre_pair_window_for_rule(self, rule: PulseRule) -> tuple[float, float]:
        max_delay = self.max_allowed_delay_for_rule(rule)
        return max(0.0, rule.release_start - max_delay), rule.high_start

    def high_prefix_window_for_rule(self, rule: PulseRule) -> tuple[float, float]:
        return rule.high_start, self.scan_end_for_rule(rule)

    def source_window_for_rule(self, rule: PulseRule, source_label: str) -> tuple[float, float]:
        if source_label == "pre_pair":
            return self.pre_pair_window_for_rule(rule)
        if source_label == "high_prefix":
            return self.high_prefix_window_for_rule(rule)
        return self.scan_start_for_rule(rule), self.scan_end_for_rule(rule)

    def find_source_rule(self, rel: float, flow_key: tuple[str, str, int, int]) -> tuple[int, str] | None:
        if self.dilution_mode == "sparse3":
            candidates: list[PulseRule] = []
            for rule in self.active_rules_by_scan_time:
                candidate_start = self.scan_start_for_rule(rule)
                candidate_end = self.scan_end_for_rule(rule)
                if not (candidate_start <= rel < candidate_end):
                    if candidate_start > rel:
                        break
                    continue
                if self.rule_hits[rule.pair_ordinal] >= self.max_hits_per_rule:
                    self.skipped_quota_packets += 1
                    continue
                candidates.append(rule)

            if not candidates:
                for rule in self.rules_by_release_time:
                    if rule.release_start <= rel < rule.release_end:
                        if rule.active:
                            self.natural_high_hits[rule.pair_ordinal] += 1
                        else:
                            self.guard_natural_hits[rule.pair_ordinal] += 1
                        return None
                    if rule.release_start > rel:
                        break
                return None

            needing_hits = [
                rule
                for rule in candidates
                if self.rule_hits[rule.pair_ordinal] < self.min_hits_per_rule
            ]
            pool = needing_hits if needing_hits else candidates
            rule = min(
                pool,
                key=lambda item: (
                    self.rule_hits[item.pair_ordinal],
                    item.release_start,
                    item.pair_ordinal,
                ),
            )
            self.candidate_hits[rule.pair_ordinal] += 1
            return rule.pair_ordinal, "sparse3_active"

        for rule in self.rules:
            if rule.release_start <= rel < rule.release_end:
                self.natural_high_hits[rule.pair_ordinal] += 1
                return None

        def collect(source_label: str) -> list[PulseRule]:
            candidates: list[PulseRule] = []
            for rule in self.rules:
                if source_label == "opposite_low" and rule.source_kind != "opposite_low":
                    continue
                if source_label in {"pre_pair", "high_prefix"} and rule.expected_bit != "1":
                    continue
                if source_label == "high_prefix" and self.rule_has_buffered_candidates(flow_key, rule.pair_ordinal):
                    continue

                candidate_start, candidate_end = self.source_window_for_rule(rule, source_label)
                if not (candidate_start <= rel < candidate_end):
                    continue

                if self.rule_hits[rule.pair_ordinal] >= self.max_hits_per_rule:
                    self.skipped_quota_packets += 1
                    continue

                candidates.append(rule)
            return candidates

        selected_source = "primary"
        candidates = collect("opposite_low") + collect("pre_pair")
        if not candidates:
            selected_source = "high_prefix"
            candidates = collect("high_prefix")

        if not candidates and self.fallback_window_s > 0.0:
            selected_source = "fallback_window"
            for rule in self.rules:
                fallback_start = max(
                    rule.low_start if rule.source_kind == "opposite_low" else rule.release_start - self._max_allowed_delay(rule),
                    rule.release_start - self.fallback_window_s,
                )
                fallback_end = rule.release_start
                if not (fallback_start <= rel < fallback_end):
                    continue

                self.candidate_hits[rule.pair_ordinal] += 1
                self.fallback_hits[rule.pair_ordinal] += 1

                if self.rule_hits[rule.pair_ordinal] >= self.max_hits_per_rule:
                    self.skipped_quota_packets += 1
                    continue

                candidates.append(rule)

        if not candidates:
            return None

        needing_hits = [
            rule
            for rule in candidates
            if self.rule_hits[rule.pair_ordinal] < self.min_hits_per_rule
        ]
        pool = needing_hits if needing_hits else candidates
        rule = min(
            pool,
            key=lambda item: (
                self.rule_hits[item.pair_ordinal],
                item.release_start,
                item.pair_ordinal,
            ),
        )
        self.candidate_hits[rule.pair_ordinal] += 1
        if selected_source == "primary":
            selected_source = "pre_pair" if rule.expected_bit == "1" else "opposite_low"

        if selected_source == "opposite_low":
            self.source_low_hits[rule.pair_ordinal] += 1
        elif selected_source == "pre_pair":
            self.pre_pair_candidate_hits[rule.pair_ordinal] += 1
            self.source_pre_high_hits[rule.pair_ordinal] += 1
        elif selected_source == "high_prefix":
            self.high_prefix_candidate_hits[rule.pair_ordinal] += 1
            self.fallback_hits[rule.pair_ordinal] += 1
        else:
            self.fallback_hits[rule.pair_ordinal] += 1
        return rule.pair_ordinal, selected_source

    def release_slot_time_for_item(
        self,
        rule: PulseRule,
        item: CachedPacket,
        slot_index: int,
        slot_count: int,
    ) -> float:
        slot_count = max(slot_count, 1)
        inner_lo = float(self.release_inner_start_fraction)
        inner_hi = float(self.release_inner_end_fraction)
        if inner_hi <= inner_lo:
            inner_lo, inner_hi = 0.05, 0.50

        base_fraction = inner_lo + (inner_hi - inner_lo) * ((slot_index + 0.5) / slot_count)
        mixed = (
            item.sequence
            ^ ((rule.pair_ordinal + 1) * 2654435761)
            ^ ((slot_index + 1) * 2246822519)
        ) & 0xFFFF
        jitter = ((mixed / 65535.0) - 0.5) * float(self.release_jitter_fraction)
        fraction = min(max(base_fraction + jitter, inner_lo), inner_hi)
        span = max(rule.release_end - rule.release_start, 1e-6)
        return rule.release_start + span * fraction

    def choose_release_time_in_interval(
        self,
        rule: PulseRule,
        item: CachedPacket,
        slot_index: int,
        slot_count: int,
        interval: tuple[float, float],
    ) -> float:
        lo, hi = interval
        slot_count = max(slot_count, 1)
        base_fraction = (slot_index + 0.5) / slot_count
        mixed = (
            item.sequence
            ^ ((rule.pair_ordinal + 1) * 2654435761)
            ^ ((slot_index + 1) * 2246822519)
        ) & 0xFFFF
        jitter = ((mixed / 65535.0) - 0.5) * float(self.release_jitter_fraction)
        fraction = min(max(base_fraction + jitter, 0.05), 0.95)
        return lo + (hi - lo) * fraction

    def choose_eligible_suffix(
        self,
        rule: PulseRule,
        packets: list[CachedPacket],
        quota: int,
    ) -> tuple[set[int], dict[int, float], bool]:
        if quota <= 0 or not packets:
            return set(), {}, False

        packets = sorted(packets, key=lambda item: (item.rel, item.sequence))
        max_count = min(quota, len(packets))

        for count in range(max_count, 0, -1):
            suffix = packets[-count:]
            intervals: list[tuple[float, float]] = []
            ok = True
            for item in suffix:
                interval = self.feasible_release_interval(rule, item, fallback=False)
                if interval is None:
                    self.note_feasible_reject(rule, item, fallback=False)
                    ok = False
                    break
                intervals.append(interval)

            if not ok:
                continue

            plan: dict[int, float] = {}
            for slot_index, (item, interval) in enumerate(zip(suffix, intervals)):
                release_rel = self.choose_release_time_in_interval(
                    rule,
                    item,
                    slot_index=slot_index,
                    slot_count=count,
                    interval=interval,
                )
                delay = release_rel - item.rel
                if delay <= 0.0:
                    ok = False
                    break
                plan[id(item)] = release_rel

            if ok:
                self.strict_selected_packets += count
                self.strict_selected_by_rule[rule.pair_ordinal] += count
                self.feasible_suffix_rules += 1
                self.eligible_suffix_histogram[count] += 1
                return {id(item) for item in suffix}, plan, False

        self.no_eligible_suffix_rules += 1
        self.no_feasible_suffix_by_rule[rule.pair_ordinal] += 1
        latest = packets[-1]
        interval = self.feasible_release_interval(rule, latest, fallback=True)
        if interval is not None:
            release_rel = self.choose_release_time_in_interval(
                rule,
                latest,
                slot_index=0,
                slot_count=1,
                interval=interval,
            )
            if release_rel > latest.rel:
                self.fallback_selected_packets += 1
                self.fallback_selected_by_rule[rule.pair_ordinal] += 1
                self.fallback_suffix_rules += 1
                self.eligible_suffix_histogram[1] += 1
                return {id(latest)}, {id(latest): release_rel}, True
        else:
            self.note_feasible_reject(rule, latest, fallback=True)

        return set(), {}, False

    def selection_respects_ordered_delay_cap(
        self,
        rule: PulseRule,
        packets: list[CachedPacket],
        selected_ids: set[int],
        release_plan: dict[int, float],
        state: FlowState | None,
        origin: float | None,
        now: float,
    ) -> bool:
        """Verify the full in-order release schedule before retaining a selection.

        TCP sequence order can differ from NFQUEUE arrival order.  A selected
        earlier-sequence packet may therefore force a later-sequence packet
        that arrived first to wait.  When a finite cap is configured, every
        retained packet must remain within it; R003's no-cap policy still
        preserves TCP sequence order before retaining a selection.
        """
        if not selected_ids or state is None or origin is None:
            return True
        anchor = origin + self.current_effective_offset()
        last_release = state.last_release
        max_delay = self.max_allowed_delay_for_rule(rule)
        for item in sorted(packets, key=lambda value: (value.sequence, value.rel)):
            desired_release = anchor + release_plan[id(item)] if id(item) in selected_ids else now
            release = max(desired_release, last_release + self.min_release_gap)
            arrival = anchor + item.rel
            if release - arrival > max_delay + 1e-9:
                return False
            last_release = max(last_release, release)
        return True

    def rollback_selection_counters(
        self,
        ordinal: int,
        selected_ids: set[int],
        used_fallback: bool,
    ) -> None:
        """Undo a tentative suffix selection before trying a smaller suffix.

        ``choose_eligible_suffix`` records selection counters immediately.  An
        in-order FIFO check can reject that tentative plan later, so retries
        must leave the counters equivalent to a single committed selection.
        """
        selected_count = len(selected_ids)
        if selected_count <= 0:
            return
        if used_fallback:
            self.fallback_selected_packets = max(
                0, self.fallback_selected_packets - selected_count
            )
            self.fallback_selected_by_rule[ordinal] = max(
                0, self.fallback_selected_by_rule[ordinal] - selected_count
            )
            self.fallback_suffix_rules = max(0, self.fallback_suffix_rules - 1)
        else:
            self.strict_selected_packets = max(
                0, self.strict_selected_packets - selected_count
            )
            self.strict_selected_by_rule[ordinal] = max(
                0, self.strict_selected_by_rule[ordinal] - selected_count
            )
            self.feasible_suffix_rules = max(0, self.feasible_suffix_rules - 1)
        self.eligible_suffix_histogram[selected_count] -= 1
        if self.eligible_suffix_histogram[selected_count] <= 0:
            del self.eligible_suffix_histogram[selected_count]

    def finalize_rule_buffer(
        self,
        flow_key: tuple[str, str, int, int],
        ordinal: int,
        *,
        quota_override: int | None = None,
    ) -> None:
        key = (flow_key, ordinal)
        with self.cache_lock:
            buffer = self.rule_buffers.get(key)
            if buffer is None or buffer.finalized:
                return
            buffer.finalized = True
            buffered_packets = list(buffer.packets)
        rule = self.rules[ordinal]
        packets = sorted(buffered_packets, key=lambda item: (item.sequence, item.rel))
        selectable = [item for item in packets if item.selectable]
        quota = (
            max(int(quota_override), 0)
            if quota_override is not None
            else max(self.max_hits_per_rule - self.rule_hits[ordinal], 0)
        )
        self.finalized_rules += 1
        self.finalized_by_rule[ordinal] += 1
        if not selectable:
            self.no_candidate_by_rule[ordinal] += 1

        if quota <= 0:
            self.skipped_quota_packets += len(selectable)
            selected_ids: set[int] = set()
            release_plan: dict[int, float] = {}
            used_fallback = False
        else:
            selected_ids, release_plan, used_fallback = self.choose_eligible_suffix(
                rule,
                selectable,
                quota,
            )
        state = self.states.get(flow_key)
        origin = state.origin if state is not None else None
        now = time.monotonic()

        if not self.selection_respects_ordered_delay_cap(
            rule,
            packets,
            selected_ids,
            release_plan,
            state,
            origin,
            now,
        ):
            initial_selected_count = len(selected_ids)
            self.selection_order_cap_rejects += 1
            self.rollback_selection_counters(ordinal, selected_ids, used_fallback)
            selected_ids = set()
            release_plan = {}
            used_fallback = False

            # A full relative quota can be infeasible after the already
            # scheduled packets are included in the TCP in-order FIFO.  Retry
            # with a smaller suffix before declaring the whole rule uncovered.
            # This preserves the configured 100 ms cap and sequence ordering;
            # it only reduces the number of packets used by this rule.
            retry_quota = initial_selected_count - 1
            while retry_quota > 0:
                self.selection_order_cap_retries += 1
                retry_ids, retry_plan, retry_fallback = self.choose_eligible_suffix(
                    rule,
                    selectable,
                    retry_quota,
                )
                if not retry_ids:
                    break
                if self.selection_respects_ordered_delay_cap(
                    rule,
                    packets,
                    retry_ids,
                    retry_plan,
                    state,
                    origin,
                    now,
                ):
                    selected_ids = retry_ids
                    release_plan = retry_plan
                    used_fallback = retry_fallback
                    self.selection_order_cap_recovered_rules += 1
                    break
                self.rollback_selection_counters(ordinal, retry_ids, retry_fallback)
                retry_quota = len(retry_ids) - 1

            self.skipped_delay_cap_packets += max(
                0, initial_selected_count - len(selected_ids)
            )
            self.delay_cap_reject_by_rule[ordinal] += max(
                0, initial_selected_count - len(selected_ids)
            )

        if selected_ids:
            self.finalized_rules_with_selection += 1
            self.finalized_with_selection_by_rule[ordinal] += 1
            for item in selectable:
                if id(item) not in selected_ids:
                    continue
                if item.source_label == "pre_pair":
                    self.pre_pair_selected_by_rule[ordinal] += 1
                elif item.source_label == "high_prefix":
                    self.high_prefix_selected_by_rule[ordinal] += 1
        else:
            self.finalized_rules_without_selection += 1
            self.finalized_without_selection_by_rule[ordinal] += 1

        for item in packets:
            is_selected = id(item) in selected_ids
            if not is_selected:
                release_abs = now
                self.cache_unselected_packets += 1
                self.cache_unselected_by_rule[ordinal] += 1
            elif origin is None:
                release_abs = now
                is_selected = False
                self.cache_unselected_packets += 1
                self.cache_unselected_by_rule[ordinal] += 1
            else:
                release_rel = release_plan[id(item)]
                planned_delay = release_rel - item.rel
                if planned_delay <= 0.0:
                    self.skipped_nonpositive_delay_packets += 1
                    self.nonpositive_delay_reject_by_rule[ordinal] += 1
                    release_abs = now
                    is_selected = False
                    self.cache_unselected_packets += 1
                    self.cache_unselected_by_rule[ordinal] += 1
                elif planned_delay > self.max_allowed_delay_for_rule(rule, fallback=used_fallback) + 1e-9:
                    self.skipped_delay_cap_packets += 1
                    self.delay_cap_reject_by_rule[ordinal] += 1
                    release_abs = now
                    is_selected = False
                    self.cache_unselected_packets += 1
                    self.cache_unselected_by_rule[ordinal] += 1
                else:
                    release_abs = origin + self.current_effective_offset() + release_rel

            packet_arrival_abs = (
                origin + self.current_effective_offset() + item.rel
                if origin is not None
                else now
            )
            fifo_adjusted = False
            if state is not None and state.last_release >= release_abs:
                old_release = release_abs
                release_abs = state.last_release + self.min_release_gap
                fifo_adjusted = True
                self.fifo_packets += 1
                fifo_extra = max(0.0, release_abs - old_release)
                self.fifo_extra_delay_packets += 1
                self.fifo_extra_delay_sum_s += fifo_extra
                self.fifo_extra_delay_max_s = max(self.fifo_extra_delay_max_s, fifo_extra)

            # Re-check the complete in-order schedule after FIFO adjustment.
            # A per-rule feasible interval alone is insufficient when a
            # previous selected packet has already advanced last_release.
            max_allowed_delay = self.max_allowed_delay_for_rule(rule, fallback=used_fallback)
            if (
                is_selected
                and math.isfinite(max_allowed_delay)
                and release_abs - packet_arrival_abs > max_allowed_delay + 1e-9
            ):
                self.skipped_delay_cap_packets += 1
                self.delay_cap_reject_by_rule[ordinal] += 1
                if fifo_adjusted:
                    self.fifo_extra_delay_packets = max(0, self.fifo_extra_delay_packets - 1)
                    self.fifo_extra_delay_sum_s = max(0.0, self.fifo_extra_delay_sum_s - fifo_extra)
                if item.source_label == "pre_pair":
                    self.pre_pair_selected_by_rule[ordinal] = max(0, self.pre_pair_selected_by_rule[ordinal] - 1)
                elif item.source_label == "high_prefix":
                    self.high_prefix_selected_by_rule[ordinal] = max(0, self.high_prefix_selected_by_rule[ordinal] - 1)
                self.cache_selected_by_rule[ordinal] = max(0, self.cache_selected_by_rule[ordinal] - 1)
                self.rule_hits[ordinal] = max(0, self.rule_hits[ordinal] - 1)
                is_selected = False
                release_abs = now

            if state is not None:
                state.last_release = max(state.last_release, release_abs)

            if release_abs <= now:
                item.packet.accept()
                self.accepted_packets += 1
                continue

            delay_s = release_abs - now
            if is_selected:
                self.targeted_packets += 1
                self.targeted_packet_ids.add(self.packet_operation_id(item))
                self.cache_selected_packets += 1
                self.cache_selected_by_rule[ordinal] += 1
                self.rule_hits[ordinal] += 1
                if item.source_label == "pre_pair":
                    self.pre_pair_delayed_by_rule[ordinal] += 1
                elif item.source_label == "high_prefix":
                    self.high_prefix_delayed_by_rule[ordinal] += 1
            operation_id = self.packet_operation_id(item)
            unique_operation = operation_id not in self.delayed_packet_ids
            self.delayed_packets += 1
            self.delayed_packet_ids.add(operation_id)
            self.delay_sum_s += delay_s
            self.max_delay_s = max(self.max_delay_s, delay_s)
            accounting: dict[str, object] = {
                "packet_id": operation_id,
                "packet_sequence": item.sequence,
                "tsval_at_nfqueue": item.tsval,
                "flow_key": ":".join(map(str, item.flow_key)),
                "rule_ordinal": ordinal,
                "source_label": item.source_label,
                "packet_relative_time_s": item.rel,
                "packet_arrival_abs_monotonic": packet_arrival_abs,
                "scheduled_release_time": release_abs,
                "release_abs_monotonic": release_abs,
                "requested_delay_ms": 1000.0 * delay_s,
                "planned_total_added_delay_ms": 1000.0 * max(0.0, release_abs - packet_arrival_abs),
                "actual_release_time": None,
                "actual_added_delay_ms": None,
                "release_lateness_ms": None,
                "manipulable_packet": bool(is_selected),
                "actually_increased_delay": None,
                "selected_for_rule": bool(is_selected),
                "fifo_adjusted": fifo_adjusted,
                "unique_operation": unique_operation,
                "unique_operation_marker": unique_operation,
            }
            self.delay_samples.append(accounting)
            self.queue_packet(
                item.packet,
                release_abs,
                retain=False,
                accounting=accounting,
            )

    def finalize_due_rule_buffers(self) -> None:
        now = time.monotonic()
        with self.cache_lock:
            items = list(self.rule_buffers.items())
        for (flow_key, ordinal), buffer in items:
            if buffer.finalized:
                continue
            state = self.states.get(flow_key)
            if state is None or state.origin is None:
                continue
            rule = self.rules[ordinal]
            finalize_abs = state.origin + self.current_effective_offset() + self.scan_end_for_rule(rule)
            if now >= finalize_abs:
                self.finalize_rule_buffer(flow_key, ordinal)

    @staticmethod
    def packet_operation_id(item: CachedPacket) -> str:
        return f"{':'.join(map(str, item.flow_key))}:{item.sequence}"

    def complete_release_accounting(self, queued: QueuedPacket, actual_release: float) -> None:
        accounting = queued.accounting
        if accounting is None:
            return
        arrival = float(accounting["packet_arrival_abs_monotonic"])
        planned = float(accounting["scheduled_release_time"])
        accounting["actual_release_time"] = actual_release
        accounting["actual_added_delay_ms"] = 1000.0 * max(0.0, actual_release - arrival)
        accounting["actually_increased_delay"] = actual_release > arrival
        accounting["release_lateness_ms"] = 1000.0 * (actual_release - planned)
        if self.max_rule_delay_s > 0.0:
            configured_deadline = arrival + self.max_rule_delay_s
            if actual_release > configured_deadline + 1e-6:
                self.actual_delay_cap_violation_packets += 1
                self.actual_delay_cap_violation_max_s = max(
                    self.actual_delay_cap_violation_max_s,
                    actual_release - configured_deadline,
                )

    def accept_queued_packet(self, queued: QueuedPacket) -> None:
        queued.packet.accept()
        actual_release = time.monotonic()
        self.complete_release_accounting(queued, actual_release)
        self.accepted_packets += 1

    def queue_packet(
        self,
        packet,
        release: float,
        *,
        retain: bool = True,
        accounting: dict[str, object] | None = None,
    ) -> None:
        if retain and hasattr(packet, "retain"):
            packet.retain()
        with self.lock:
            heapq.heappush(
                self.heap,
                (release, next(self.counter), QueuedPacket(packet=packet, accounting=accounting)),
            )
            self.queue_high_water = max(self.queue_high_water, len(self.heap))

    def handle(self, nfpacket) -> None:
        now = time.monotonic()
        try:
            self.finalize_due_rule_buffers()
            metadata = parse_ipv4_tcp_metadata(nfpacket.get_payload())
            if metadata is None:
                nfpacket.accept()
                return
            key, sequence, application_length, dport, tsval = metadata
            port_value = dport if self.direction == "dport" else key[2]
            if port_value != self.port or application_length <= 0:
                nfpacket.accept()
                return

            self.matched_packets += 1
            state = self.states[key]
            if state.origin is None:
                armed = self.load_arm_time()
                if armed is None:
                    self.prearm_packets += 1
                    nfpacket.accept()
                    self.accepted_packets += 1
                    return
                state.origin = armed
                self.transition_to_selective_queue(origin=armed)
            raw_rel = now - state.origin
            if self.auto_align and self.effective_offset_s is None:
                self.warmup_rel_times.append(raw_rel)
                if raw_rel < self.warmup_s or len(self.warmup_rel_times) < self.align_min_packets:
                    self.warmup_packets += 1
                    nfpacket.accept()
                    self.accepted_packets += 1
                    return
                self.establish_auto_alignment(now=now, raw_rel=raw_rel)
            rel = raw_rel - self.current_effective_offset()
            source_match = self.find_source_rule(rel, key) if rel >= 0.0 else None

            if source_match is not None:
                ordinal, source_label = source_match
                if hasattr(nfpacket, "retain"):
                    nfpacket.retain()
                cache_key = (key, ordinal)
                cached = False
                with self.cache_lock:
                    buffer = self.rule_buffers.setdefault(cache_key, RuleBuffer())
                    if not buffer.finalized:
                        buffer.packets.append(
                            CachedPacket(
                                rel=rel,
                                sequence=sequence,
                                tsval=tsval,
                                packet=nfpacket,
                                flow_key=key,
                                selectable=True,
                                source_label=source_label,
                            )
                        )
                        self.cached_packets += 1
                        cached = True
                    pending_cache_packets = sum(
                        len(buf.packets)
                        for buf in self.rule_buffers.values()
                        if not buf.finalized
                    )
                if cached:
                    self.cache_high_water = max(self.cache_high_water, pending_cache_packets)
                    return

            active_key = self.active_buffer_key(key)
            if active_key is not None:
                if hasattr(nfpacket, "retain"):
                    nfpacket.retain()
                cached = False
                with self.cache_lock:
                    buffer = self.rule_buffers.get(active_key)
                    if buffer is not None and not buffer.finalized:
                        buffer.packets.append(
                            CachedPacket(
                                rel=rel,
                                sequence=sequence,
                                tsval=tsval,
                                packet=nfpacket,
                                flow_key=key,
                                selectable=False,
                            )
                        )
                        self.cached_packets += 1
                        self.cache_blocked_packets += 1
                        cached = True
                    pending_cache_packets = sum(
                        len(buf.packets)
                        for buf in self.rule_buffers.values()
                        if not buf.finalized
                    )
                if cached:
                    self.cache_high_water = max(self.cache_high_water, pending_cache_packets)
                    return

            release = now
            if state.last_release >= release:
                old_release = release
                release = state.last_release + self.min_release_gap
                self.fifo_packets += 1
                fifo_extra = max(0.0, release - old_release)
                self.fifo_extra_delay_packets += 1
                self.fifo_extra_delay_sum_s += fifo_extra
                self.fifo_extra_delay_max_s = max(self.fifo_extra_delay_max_s, fifo_extra)
                if self.max_rule_delay_s > 0.0:
                    guarded_deadline = now + max(0.0, self.max_rule_delay_s - self.deadline_guard_s)
                    if release > guarded_deadline + 1e-9:
                        # Do not propagate a future FIFO deadline conflict to
                        # an otherwise unselected packet.  Accepting now is
                        # preferable to silently exceeding the cap; the event
                        # remains auditable through this counter.
                        self.fifo_deadline_abort_packets += 1
                        self.fifo_extra_delay_packets = max(0, self.fifo_extra_delay_packets - 1)
                        self.fifo_extra_delay_sum_s = max(0.0, self.fifo_extra_delay_sum_s - fifo_extra)
                        release = now
            if release <= now:
                nfpacket.accept()
                self.accepted_packets += 1
                return
            delay_s = release - now
            operation_id = f"{':'.join(map(str, key))}:{sequence}"
            unique_operation = operation_id not in self.delayed_packet_ids
            self.delayed_packets += 1
            self.delayed_packet_ids.add(operation_id)
            self.delay_sum_s += delay_s
            self.max_delay_s = max(self.max_delay_s, delay_s)
            state.last_release = release
            accounting: dict[str, object] = {
                "packet_id": operation_id,
                "packet_sequence": sequence,
                "flow_key": ":".join(map(str, key)),
                "rule_ordinal": -1,
                "source_label": "fifo_following",
                "packet_relative_time_s": rel,
                "packet_arrival_abs_monotonic": now,
                "scheduled_release_time": release,
                "release_abs_monotonic": release,
                "requested_delay_ms": 1000.0 * delay_s,
                "planned_total_added_delay_ms": 1000.0 * delay_s,
                "actual_release_time": None,
                "actual_added_delay_ms": None,
                "release_lateness_ms": None,
                "manipulable_packet": False,
                "actually_increased_delay": None,
                "selected_for_rule": False,
                "fifo_adjusted": True,
                "unique_operation": unique_operation,
                "unique_operation_marker": unique_operation,
            }
            self.delay_samples.append(accounting)
            self.queue_packet(nfpacket, release, accounting=accounting)
        except Exception as exc:
            self.error_count += 1
            print(json.dumps({"type": "embedder_error", "error": repr(exc)}), flush=True)
            nfpacket.accept()

    def releaser(self) -> None:
        while self.running:
            self.finalize_due_rule_buffers()
            item = None
            now = time.monotonic()
            with self.lock:
                if self.heap and self.heap[0][0] <= now:
                    item = heapq.heappop(self.heap)
            if item is None:
                time.sleep(0.0005)
                continue
            self.accept_queued_packet(item[2])

    def bit_source_summary(self) -> dict[str, object]:
        summary: dict[str, object] = {}
        for bit in ("0", "1"):
            indices = [rule.pair_ordinal for rule in self.rules if rule.expected_bit == bit]

            def count_rules(values: list[int], threshold: int = 1) -> int:
                return sum(1 for index in indices if values[index] >= threshold)

            summary[f"bit{bit}_rules_total"] = len(indices)
            summary[f"bit{bit}_candidate_rules_hit"] = count_rules(self.candidate_hits)
            summary[f"bit{bit}_delayed_rules_hit"] = count_rules(self.rule_hits)
            summary[f"bit{bit}_natural_high_rules_hit"] = count_rules(self.natural_high_hits)
            summary[f"bit{bit}_strict_selected_packets"] = sum(self.strict_selected_by_rule[index] for index in indices)
            summary[f"bit{bit}_fallback_selected_packets"] = sum(self.fallback_selected_by_rule[index] for index in indices)
            summary[f"bit{bit}_cache_selected_packets"] = sum(self.cache_selected_by_rule[index] for index in indices)
            summary[f"bit{bit}_cache_unselected_packets"] = sum(self.cache_unselected_by_rule[index] for index in indices)
            summary[f"bit{bit}_pre_pair_candidate_rules_hit"] = count_rules(self.pre_pair_candidate_hits)
            summary[f"bit{bit}_pre_pair_selected_packets"] = sum(self.pre_pair_selected_by_rule[index] for index in indices)
            summary[f"bit{bit}_pre_pair_delayed_packets"] = sum(self.pre_pair_delayed_by_rule[index] for index in indices)
            summary[f"bit{bit}_pre_pair_delayed_rules_hit"] = count_rules(self.pre_pair_delayed_by_rule)
            summary[f"bit{bit}_high_prefix_candidate_rules_hit"] = count_rules(self.high_prefix_candidate_hits)
            summary[f"bit{bit}_high_prefix_selected_packets"] = sum(self.high_prefix_selected_by_rule[index] for index in indices)
            summary[f"bit{bit}_high_prefix_delayed_packets"] = sum(self.high_prefix_delayed_by_rule[index] for index in indices)
            summary[f"bit{bit}_high_prefix_delayed_rules_hit"] = count_rules(self.high_prefix_delayed_by_rule)
            summary[f"bit{bit}_finalized_rules"] = count_rules(self.finalized_by_rule)
            summary[f"bit{bit}_finalized_with_selection_rules"] = count_rules(self.finalized_with_selection_by_rule)
            summary[f"bit{bit}_finalized_without_selection_rules"] = count_rules(self.finalized_without_selection_by_rule)
            summary[f"bit{bit}_no_candidate_rules"] = count_rules(self.no_candidate_by_rule)
            summary[f"bit{bit}_no_feasible_suffix_events"] = sum(self.no_feasible_suffix_by_rule[index] for index in indices)
            summary[f"bit{bit}_delay_cap_reject_events"] = sum(self.delay_cap_reject_by_rule[index] for index in indices)
            summary[f"bit{bit}_nonpositive_delay_reject_events"] = sum(
                self.nonpositive_delay_reject_by_rule[index] for index in indices
            )

        for source_kind in sorted({rule.source_kind for rule in self.rules}):
            indices = [rule.pair_ordinal for rule in self.rules if rule.source_kind == source_kind]
            if not indices:
                continue
            prefix = f"source_{source_kind}"
            summary[f"{prefix}_rules_total"] = len(indices)
            summary[f"{prefix}_candidate_rules_hit"] = sum(1 for index in indices if self.candidate_hits[index] > 0)
            summary[f"{prefix}_delayed_rules_hit"] = sum(1 for index in indices if self.rule_hits[index] > 0)
            summary[f"{prefix}_cache_selected_packets"] = sum(self.cache_selected_by_rule[index] for index in indices)
            summary[f"{prefix}_cache_unselected_packets"] = sum(self.cache_unselected_by_rule[index] for index in indices)
            summary[f"{prefix}_no_feasible_suffix_events"] = sum(
                self.no_feasible_suffix_by_rule[index] for index in indices
            )

        return summary

    def snapshot(self, summary: dict[str, object], *, final: bool = False) -> dict[str, object]:
        elapsed_s = max(time.monotonic() - self.started_monotonic, 0.0)
        with self.cache_lock:
            pending_cache_packets = sum(
                len(buffer.packets)
                for buffer in self.rule_buffers.values()
                if not buffer.finalized
            )
        pending_heap_packets = len(self.heap)
        coverage_indices = self.active_rule_indices if self.dilution_mode == "sparse3" else list(range(len(self.rules)))
        hit_rules = sum(
            1
            for index in coverage_indices
            if self.rule_hits[index] >= self.min_hits_per_rule
        )
        missed_rules = [
            index
            for index in coverage_indices
            if self.rule_hits[index] < self.min_hits_per_rule
        ]
        sorted_hits = sorted(self.rule_hits[index] for index in coverage_indices)
        if sorted_hits:
            mid = len(sorted_hits) // 2
            if len(sorted_hits) % 2:
                median_hit = float(sorted_hits[mid])
            else:
                median_hit = 0.5 * (sorted_hits[mid - 1] + sorted_hits[mid])
            min_hit = int(sorted_hits[0])
            max_hit = int(sorted_hits[-1])
        else:
            median_hit = 0.0
            min_hit = 0
            max_hit = 0
        active_rules_total = len(self.active_rule_indices) if self.dilution_mode == "sparse3" else len(self.rules)
        guard_rules_total = len(self.guard_rule_indices) if self.dilution_mode == "sparse3" else 0
        active_rule_coverage = hit_rules / active_rules_total if active_rules_total else 1.0
        rule_coverage = active_rule_coverage
        delay_values_ms = sorted(float(row["requested_delay_ms"]) for row in self.delay_samples)
        actual_delay_values_ms = sorted(
            float(row["actual_added_delay_ms"])
            for row in self.delay_samples
            if row.get("actual_added_delay_ms") is not None and bool(row.get("unique_operation"))
        )
        release_lateness_values_ms = sorted(
            float(row["release_lateness_ms"])
            for row in self.delay_samples
            if row.get("release_lateness_ms") is not None
        )
        max_actual_added_delay_ms = max(actual_delay_values_ms, default=0.0)
        explicit_delay_cap_applied = math.isfinite(self.max_rule_delay_s)
        execution_invalid_checks = [
            ("error_count_nonzero", self.error_count != 0),
            ("pending_packets_nonzero", pending_heap_packets + pending_cache_packets != 0),
            ("active_rules_not_embedded", active_rules_total > 0 and hit_rules == 0),
            ("active_rule_coverage_below_threshold", active_rule_coverage + 1e-12 < self.min_rule_coverage),
            ("no_effective_delay", len(self.delayed_packet_ids) == 0),
            ("not_armed", self.arm_file is not None and self.armed_monotonic is None),
            ("not_auto_aligned", self.auto_align and self.effective_offset_s is None),
            ("arm_timeout", self.stop_reason == "arm_timeout"),
            ("runtime_timeout", self.stop_reason == "runtime_timeout"),
        ]
        if explicit_delay_cap_applied:
            execution_invalid_checks.append(
                (
                    "actual_added_delay_exceeds_configured_cap",
                    max_actual_added_delay_ms > 1000.0 * self.max_rule_delay_s + 1e-6,
                )
            )
            execution_invalid_checks.append(
                (
                    "actual_delay_cap_runtime_violation",
                    self.actual_delay_cap_violation_packets > 0,
                )
            )
        execution_invalid_reasons = [reason for reason, failed in execution_invalid_checks if failed]
        execution_valid = not execution_invalid_reasons
        summary_prefixed = {f"plan_{key}": value for key, value in summary.items()}
        def value_percentile(values: list[float], pct: float) -> float:
            if not values:
                return 0.0
            if len(values) == 1:
                return values[0]
            pos = (len(values) - 1) * pct / 100.0
            lo = math.floor(pos)
            hi = math.ceil(pos)
            if lo == hi:
                return values[lo]
            return values[lo] * (hi - pos) + values[hi] * (pos - lo)

        delay_samples_csv = (
            str(self.rule_stats_csv.with_name("delay_samples.csv"))
            if self.rule_stats_csv is not None
            else None
        )
        return {
            "type": "plan_embedder_result" if final else "plan_embedder_status",
            "started_utc": self.started_utc,
            "finished_utc": datetime.now(timezone.utc).isoformat(timespec="milliseconds") if final else None,
            "elapsed_s": elapsed_s,
            "matched_packets": self.matched_packets,
            "matched_pps": self.matched_packets / elapsed_s if elapsed_s > 0.0 else 0.0,
            "targeted_packets": self.targeted_packets,
            "targeted_unique_packets": len(self.targeted_packet_ids),
            "targeted_packet_rate": (
                len(self.targeted_packet_ids) / self.accepted_packets
                if self.accepted_packets
                else 0.0
            ),
            "fifo_packets": self.fifo_packets,
            "delayed_packets": self.delayed_packets,
            "delayed_unique_packets": len(self.delayed_packet_ids),
            "delayed_packet_rate": (
                len(self.delayed_packet_ids) / self.accepted_packets
                if self.accepted_packets
                else 0.0
            ),
            "accepted_packets": self.accepted_packets,
            "prearm_packets": self.prearm_packets,
            "warmup_packets": self.warmup_packets,
            "pending_packets": pending_heap_packets + pending_cache_packets,
            "pending_heap_packets": pending_heap_packets,
            "pending_cache_packets": pending_cache_packets,
            "queue_high_water": self.queue_high_water,
            "cached_packets": self.cached_packets,
            "cache_selected_packets": self.cache_selected_packets,
            "cache_unselected_packets": self.cache_unselected_packets,
            "cache_blocked_packets": self.cache_blocked_packets,
            "cache_flushed_packets": self.cache_flushed_packets,
            "cache_high_water": self.cache_high_water,
            "strict_selected_packets": self.strict_selected_packets,
            "fallback_selected_packets": self.fallback_selected_packets,
            "feasible_suffix_rules": self.feasible_suffix_rules,
            "fallback_suffix_rules": self.fallback_suffix_rules,
            "no_eligible_suffix_rules": self.no_eligible_suffix_rules,
            "finalized_rules": self.finalized_rules,
            "finalized_rules_with_selection": self.finalized_rules_with_selection,
            "finalized_rules_without_selection": self.finalized_rules_without_selection,
            "eligible_suffix_histogram": dict(self.eligible_suffix_histogram),
            "mean_requested_delay_ms": 1000.0 * self.delay_sum_s / self.delayed_packets if self.delayed_packets else 0.0,
            "p50_requested_delay_ms": value_percentile(delay_values_ms, 50.0),
            "p95_requested_delay_ms": value_percentile(delay_values_ms, 95.0),
            "max_requested_delay_ms": 1000.0 * self.max_delay_s,
            "actual_release_recorded_packets": len(actual_delay_values_ms),
            "mean_actual_added_delay_ms": (
                sum(actual_delay_values_ms) / len(actual_delay_values_ms)
                if actual_delay_values_ms
                else 0.0
            ),
            "p50_actual_added_delay_ms": value_percentile(actual_delay_values_ms, 50.0),
            "p95_actual_added_delay_ms": value_percentile(actual_delay_values_ms, 95.0),
            "max_actual_added_delay_ms": max_actual_added_delay_ms,
            "explicit_actual_added_delay_cap_applied": explicit_delay_cap_applied,
            "maximum_allowed_actual_added_delay_ms": (
                1000.0 * self.max_rule_delay_s if explicit_delay_cap_applied else None
            ),
            "actual_added_delay_cap_met": (
                max_actual_added_delay_ms <= 1000.0 * self.max_rule_delay_s + 1e-6
                if explicit_delay_cap_applied
                else None
            ),
            "actual_added_delay_policy": (
                "configured_hard_cap"
                if explicit_delay_cap_applied
                else "no_explicit_hard_cap_within_chip_release_window"
            ),
            "p50_release_lateness_ms": value_percentile(release_lateness_values_ms, 50.0),
            "p95_release_lateness_ms": value_percentile(release_lateness_values_ms, 95.0),
            "max_release_lateness_ms": max(release_lateness_values_ms, default=0.0),
            "rules_hit": hit_rules,
            "rules_total": active_rules_total,
            "rule_coverage": rule_coverage,
            "chip_rules_total": len(self.rules),
            "active_rules_total": active_rules_total,
            "guard_rules_total": guard_rules_total,
            "active_rules_hit": hit_rules,
            "active_rule_coverage": active_rule_coverage,
            "guard_natural_rules_hit": sum(1 for index in self.guard_rule_indices if self.guard_natural_hits[index] > 0),
            "guard_natural_packets": sum(self.guard_natural_hits[index] for index in self.guard_rule_indices),
            "min_rule_coverage": self.min_rule_coverage,
            "min_hits_per_rule": self.min_hits_per_rule,
            "rule_hits_min": min_hit,
            "rule_hits_median": median_hit,
            "rule_hits_max": max_hit,
            "rules_below_min_hits": missed_rules,
            "rules_below_min_hits_count": len(missed_rules),
            "embedding_execution_valid": execution_valid,
            "embedding_execution_invalid_reasons": execution_invalid_reasons,
            "embedding_coverage_value": active_rule_coverage,
            "embedding_coverage_reference_threshold": self.min_rule_coverage,
            "embedding_coverage_reference_met": active_rule_coverage >= self.min_rule_coverage,
            # Compatibility aliases now describe execution validity only.
            "experiment_valid": execution_valid,
            "invalid_reasons": execution_invalid_reasons,
            "stop_reason": self.stop_reason,
            "dilution_mode": self.dilution_mode,
            "auto_align": self.auto_align,
            "warmup_s": self.warmup_s,
            "source_scan_extra_s": self.source_scan_extra_s,
            "align_search_s": self.align_search_s,
            "align_step_s": self.align_step_s,
            "align_min_packets": self.align_min_packets,
            "auto_align_delta_s": self.auto_align_delta_s,
            "auto_align_score": self.auto_align_score,
            "hold_extra_s": self.hold_extra_s,
            "window_cache_s": self.window_cache_s,
            "fallback_window_s": self.fallback_window_s,
            "max_hits_per_rule": self.max_hits_per_rule,
            "max_rule_delay_s": (
                self.max_rule_delay_s if explicit_delay_cap_applied else None
            ),
            "deadline_guard_s": self.deadline_guard_s,
            "deadline_guard_ms": 1000.0 * self.deadline_guard_s,
            "release_inner_start_fraction": self.release_inner_start_fraction,
            "release_inner_end_fraction": self.release_inner_end_fraction,
            "release_jitter_fraction": self.release_jitter_fraction,
            "fallback_delay_multiplier": self.fallback_delay_multiplier,
            "candidate_rules_hit": sum(1 for count in self.candidate_hits if count > 0),
            "source_low_rules_hit": sum(1 for count in self.source_low_hits if count > 0),
            "source_pre_high_rules_hit": sum(1 for count in self.source_pre_high_hits if count > 0),
            "fallback_rules_hit": sum(1 for count in self.fallback_hits if count > 0),
            "natural_high_rules_hit": sum(1 for count in self.natural_high_hits if count > 0),
            "pre_pair_candidate_rules_hit": sum(1 for count in self.pre_pair_candidate_hits if count > 0),
            "pre_pair_selected_packets": sum(self.pre_pair_selected_by_rule),
            "pre_pair_delayed_packets": sum(self.pre_pair_delayed_by_rule),
            "pre_pair_delayed_rules_hit": sum(1 for count in self.pre_pair_delayed_by_rule if count > 0),
            "high_prefix_candidate_rules_hit": sum(1 for count in self.high_prefix_candidate_hits if count > 0),
            "high_prefix_selected_packets": sum(self.high_prefix_selected_by_rule),
            "high_prefix_delayed_packets": sum(self.high_prefix_delayed_by_rule),
            "high_prefix_delayed_rules_hit": sum(1 for count in self.high_prefix_delayed_by_rule if count > 0),
            "skipped_quota_packets": self.skipped_quota_packets,
            "skipped_delay_cap_packets": self.skipped_delay_cap_packets,
            "selection_order_cap_rejects": self.selection_order_cap_rejects,
            "selection_order_cap_retries": self.selection_order_cap_retries,
            "selection_order_cap_recovered_rules": self.selection_order_cap_recovered_rules,
            "skipped_nonpositive_delay_packets": self.skipped_nonpositive_delay_packets,
            "fifo_extra_delay_packets": self.fifo_extra_delay_packets,
            "mean_fifo_extra_delay_ms": (
                1000.0 * self.fifo_extra_delay_sum_s / self.fifo_extra_delay_packets
                if self.fifo_extra_delay_packets
                else 0.0
            ),
            "max_fifo_extra_delay_ms": 1000.0 * self.fifo_extra_delay_max_s,
            "fifo_deadline_abort_packets": self.fifo_deadline_abort_packets,
            "actual_delay_cap_violation_packets": self.actual_delay_cap_violation_packets,
            "actual_delay_cap_violation_max_ms": 1000.0 * self.actual_delay_cap_violation_max_s,
            "queue_execution_mode": (
                "selective_active_source_windows" if self.selective_queue else "full_flow_nfqueue"
            ),
            "selective_queue_transitioned": self.selective_queue_transitioned,
            "selective_queue_transition_error": self.selective_queue_transition_error,
            "selective_queue_active_windows_planned": len(self.active_rules_by_scan_time),
            "selective_queue_gate_lead_s": self.queue_gate_lead_s,
            "selective_queue_gate_tail_s": self.queue_gate_tail_s,
            "selective_queue_gate_opens": self.selective_gate_opens,
            "selective_queue_gate_closes": self.selective_gate_closes,
            "selective_queue_gate_open_lateness_ms": self.selective_gate_open_lateness_ms,
            "selective_queue_gate_close_lateness_ms": self.selective_gate_close_lateness_ms,
            "selective_queue_gate_events": self.selective_gate_events,
            "origin_offset_s": self.origin_offset,
            "effective_offset_s": self.current_effective_offset(),
            "embed_start_utc": self.embed_start_utc,
            "first_matched_packet_time": {
                "monotonic": self.first_matched_packet_monotonic,
                "relative_to_arm_s": self.first_matched_packet_rel_s,
                "utc": self.first_matched_packet_utc,
            },
            "first_rule_start_s": self.first_rule_start_s,
            "rule_stats_csv": str(self.rule_stats_csv) if self.rule_stats_csv is not None else None,
            "rule_stats_json": str(self.rule_stats_json) if self.rule_stats_json is not None else None,
            "delay_samples_csv": delay_samples_csv,
            "arm_file": str(self.arm_file) if self.arm_file is not None else None,
            "armed_monotonic": self.armed_monotonic,
            "armed_utc": self.armed_utc,
            "rule_hits": self.rule_hits,
            "candidate_hits": self.candidate_hits,
            "source_low_hits": self.source_low_hits,
            "source_pre_high_hits": self.source_pre_high_hits,
            "fallback_hits": self.fallback_hits,
            "natural_high_hits": self.natural_high_hits,
            "guard_natural_hits": self.guard_natural_hits,
            "pre_pair_candidate_hits": self.pre_pair_candidate_hits,
            "pre_pair_selected_by_rule": self.pre_pair_selected_by_rule,
            "pre_pair_delayed_by_rule": self.pre_pair_delayed_by_rule,
            "high_prefix_candidate_hits": self.high_prefix_candidate_hits,
            "high_prefix_selected_by_rule": self.high_prefix_selected_by_rule,
            "high_prefix_delayed_by_rule": self.high_prefix_delayed_by_rule,
            "flow_count": len(self.states),
            "error_count": self.error_count,
            **self.bit_source_summary(),
            "plan_summary": summary,
            **summary_prefixed,
        }

    def reporter(self, summary: dict[str, object]) -> None:
        while self.running:
            time.sleep(self.stats_interval)
            if self.running:
                print(json.dumps(self.snapshot(summary), ensure_ascii=False), flush=True)

    def rule_stats_rows(self) -> list[dict[str, object]]:
        rows: list[dict[str, object]] = []
        for rule, hits in zip(self.rules, self.rule_hits):
            rows.append(
                {
                    "pair_ordinal": rule.pair_ordinal,
                    "frame_index": rule.frame_index,
                    "expected_bit": rule.expected_bit,
                    "logical_bit_index": rule.logical_bit_index,
                    "chip_position": rule.chip_position,
                    "logical_bit": rule.logical_bit,
                    "chip_bit": rule.chip_bit,
                    "active": rule.active,
                    "dilution_mode": rule.dilution_mode,
                    "pair_start": rule.pair_start,
                    "left_start": rule.left_start,
                    "left_end": rule.left_end,
                    "right_start": rule.right_start,
                    "right_end": rule.right_end,
                    "high_start": rule.high_start,
                    "high_end": rule.high_end,
                    "low_start": rule.low_start,
                    "low_end": rule.low_end,
            "source_kind": rule.source_kind,
            "source_start": rule.source_start,
            "source_end": rule.source_end,
            "source_scan_start": rule.source_scan_start,
            "source_scan_end": rule.source_scan_end,
                    "eligible_start": rule.eligible_start,
                    "eligible_end": rule.eligible_end,
                    "candidate_start": self.runtime_candidate_start(rule),
            "candidate_end": self.scan_end_for_rule(rule),
                    "pre_pair_candidate_start": self.pre_pair_window_for_rule(rule)[0] if rule.expected_bit == "1" else "",
                    "pre_pair_candidate_end": self.pre_pair_window_for_rule(rule)[1] if rule.expected_bit == "1" else "",
                    "high_prefix_candidate_start": self.high_prefix_window_for_rule(rule)[0] if rule.expected_bit == "1" else "",
                    "high_prefix_candidate_end": self.high_prefix_window_for_rule(rule)[1] if rule.expected_bit == "1" else "",
                    "hold_start": rule.hold_start,
                    "hold_end": rule.hold_end,
                    "release_start": rule.release_start,
                    "release_end": rule.release_end,
                    "candidate_hits": self.candidate_hits[rule.pair_ordinal],
                    "source_low_hits": self.source_low_hits[rule.pair_ordinal],
                    "source_pre_high_hits": self.source_pre_high_hits[rule.pair_ordinal],
                    "fallback_hits": self.fallback_hits[rule.pair_ordinal],
                    "natural_high_hits": self.natural_high_hits[rule.pair_ordinal],
                    "guard_natural_hits": self.guard_natural_hits[rule.pair_ordinal],
                    "pre_pair_candidate_hits": self.pre_pair_candidate_hits[rule.pair_ordinal],
                    "pre_pair_selected_by_rule": self.pre_pair_selected_by_rule[rule.pair_ordinal],
                    "pre_pair_delayed_by_rule": self.pre_pair_delayed_by_rule[rule.pair_ordinal],
                    "high_prefix_candidate_hits": self.high_prefix_candidate_hits[rule.pair_ordinal],
                    "high_prefix_selected_by_rule": self.high_prefix_selected_by_rule[rule.pair_ordinal],
                    "high_prefix_delayed_by_rule": self.high_prefix_delayed_by_rule[rule.pair_ordinal],
                    "strict_selected_by_rule": self.strict_selected_by_rule[rule.pair_ordinal],
                    "fallback_selected_by_rule": self.fallback_selected_by_rule[rule.pair_ordinal],
                    "cache_selected_by_rule": self.cache_selected_by_rule[rule.pair_ordinal],
                    "cache_unselected_by_rule": self.cache_unselected_by_rule[rule.pair_ordinal],
                    "finalized_by_rule": self.finalized_by_rule[rule.pair_ordinal],
                    "finalized_with_selection_by_rule": self.finalized_with_selection_by_rule[rule.pair_ordinal],
                    "finalized_without_selection_by_rule": self.finalized_without_selection_by_rule[rule.pair_ordinal],
                    "no_candidate_by_rule": self.no_candidate_by_rule[rule.pair_ordinal],
                    "no_feasible_suffix_by_rule": self.no_feasible_suffix_by_rule[rule.pair_ordinal],
                    "delay_cap_reject_by_rule": self.delay_cap_reject_by_rule[rule.pair_ordinal],
                    "nonpositive_delay_reject_by_rule": self.nonpositive_delay_reject_by_rule[rule.pair_ordinal],
                    "hits": hits,
                    "covered": hits >= self.min_hits_per_rule,
                }
            )
        return rows

    def write_rule_stats(self) -> None:
        rows = self.rule_stats_rows()
        if self.rule_stats_csv is not None:
            self.rule_stats_csv.parent.mkdir(parents=True, exist_ok=True)
            with self.rule_stats_csv.open("w", newline="", encoding="utf-8") as handle:
                fieldnames = [
                    "pair_ordinal",
                    "frame_index",
                    "expected_bit",
                    "logical_bit_index",
                    "chip_position",
                    "logical_bit",
                    "chip_bit",
                    "active",
                    "dilution_mode",
                    "pair_start",
                    "left_start",
                    "left_end",
                    "right_start",
                    "right_end",
                    "high_start",
                    "high_end",
                    "low_start",
                    "low_end",
            "source_kind",
            "source_start",
            "source_end",
            "source_scan_start",
            "source_scan_end",
            "eligible_start",
            "eligible_end",
                    "candidate_start",
                    "candidate_end",
                    "pre_pair_candidate_start",
                    "pre_pair_candidate_end",
                    "high_prefix_candidate_start",
                    "high_prefix_candidate_end",
                    "hold_start",
                    "hold_end",
                    "release_start",
                    "release_end",
                    "candidate_hits",
                    "source_low_hits",
                    "source_pre_high_hits",
                    "fallback_hits",
                    "natural_high_hits",
                    "guard_natural_hits",
                    "pre_pair_candidate_hits",
                    "pre_pair_selected_by_rule",
                    "pre_pair_delayed_by_rule",
                    "high_prefix_candidate_hits",
                    "high_prefix_selected_by_rule",
                    "high_prefix_delayed_by_rule",
                    "strict_selected_by_rule",
                    "fallback_selected_by_rule",
                    "cache_selected_by_rule",
                    "cache_unselected_by_rule",
                    "finalized_by_rule",
                    "finalized_with_selection_by_rule",
                    "finalized_without_selection_by_rule",
                    "no_candidate_by_rule",
                    "no_feasible_suffix_by_rule",
                    "delay_cap_reject_by_rule",
                    "nonpositive_delay_reject_by_rule",
                    "hits",
                    "covered",
                ]
                writer = csv.DictWriter(handle, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(rows)
        if self.rule_stats_json is not None:
            self.rule_stats_json.parent.mkdir(parents=True, exist_ok=True)
            self.rule_stats_json.write_text(
                json.dumps({"type": "rule_stats", "rows": rows}, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
        if self.rule_stats_csv is not None:
            delay_samples_csv = self.rule_stats_csv.with_name("delay_samples.csv")
            with delay_samples_csv.open("w", newline="", encoding="utf-8") as handle:
                fieldnames = [
                    "packet_id",
                    "packet_sequence",
                    "tsval_at_nfqueue",
                    "flow_key",
                    "rule_ordinal",
                    "source_label",
                    "packet_relative_time_s",
                    "packet_arrival_abs_monotonic",
                    "scheduled_release_time",
                    "release_abs_monotonic",
                    "requested_delay_ms",
                    "planned_total_added_delay_ms",
                    "actual_release_time",
                    "actual_added_delay_ms",
                    "release_lateness_ms",
                    "manipulable_packet",
                    "actually_increased_delay",
                    "selected_for_rule",
                    "fifo_adjusted",
                    "unique_operation",
                    "unique_operation_marker",
                ]
                writer = csv.DictWriter(handle, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(self.delay_samples)
            accounting_csv = self.rule_stats_csv.with_name("embedding_packet_accounting.csv")
            with accounting_csv.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(self.delay_samples)
            selected_actual_times = [
                float(row["actual_release_time"])
                for row in self.delay_samples
                if bool(row.get("selected_for_rule")) and row.get("actual_release_time") is not None
            ]
            timestamps = {
                "clock": "time.monotonic",
                "release_semantics": "NFQUEUE verdict accept time; wire time requires B-ingress correlation",
                "first_embedding_operation_time": min(selected_actual_times, default=None),
                "last_embedding_operation_time": max(selected_actual_times, default=None),
                "selected_operations_with_actual_release": len(selected_actual_times),
            }
            self.rule_stats_csv.with_name("embedding_timestamps.json").write_text(
                json.dumps(timestamps, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )

    def flush(self) -> None:
        with self.lock:
            pending = [heapq.heappop(self.heap) for _ in range(len(self.heap))]
        for _, _, queued in pending:
            self.accept_queued_packet(queued)

    def flush_rule_buffers(self) -> None:
        with self.cache_lock:
            buffers = [buffer for buffer in self.rule_buffers.values() if not buffer.finalized]
            for buffer in buffers:
                buffer.finalized = True
                buffer.packets = sorted(buffer.packets, key=lambda item: (item.sequence, item.rel))
        for buffer in buffers:
            for item in buffer.packets:
                item.packet.accept()
                self.accepted_packets += 1
                self.cache_flushed_packets += 1

    def run(self, summary: dict[str, object]) -> None:
        from netfilterqueue import NetfilterQueue

        thread = threading.Thread(target=self.releaser, daemon=True)
        thread.start()
        reporter_thread = None
        if self.stats_interval > 0.0:
            reporter_thread = threading.Thread(target=self.reporter, args=(summary,), daemon=True)
            reporter_thread.start()
        nfq = NetfilterQueue()
        nfq.bind(self.queue_num, self.handle)

        def stop(_sig, _frame) -> None:
            self.stop_reason = "signal"
            self.running = False

        signal.signal(signal.SIGINT, stop)
        signal.signal(signal.SIGTERM, stop)
        print(json.dumps({"type": "plan_embedder_ready", "queue": self.queue_num, "port": self.port, "direction": self.direction, **summary}), flush=True)
        if self.arm_file is not None:
            print(
                json.dumps(
                    {
                        "type": "plan_embedder_waiting_for_arm",
                        "arm_file": str(self.arm_file),
                        "arm_timeout_s": self.arm_timeout_s,
                    },
                    ensure_ascii=False,
                ),
                flush=True,
            )
        try:
            while self.running:
                self.maintain_selective_queue()
                if self.max_runtime_s > 0.0 and time.monotonic() - self.started_monotonic > self.max_runtime_s:
                    self.stop_reason = "runtime_timeout"
                    print(json.dumps({"type": "plan_embedder_timeout", "max_runtime_s": self.max_runtime_s}), flush=True)
                    self.running = False
                    break
                if (
                    self.arm_file is not None
                    and self.armed_monotonic is None
                    and self.arm_timeout_s > 0.0
                    and time.monotonic() - self.started_monotonic > self.arm_timeout_s
                ):
                    self.stop_reason = "arm_timeout"
                    print(json.dumps({"type": "plan_embedder_arm_timeout", "arm_timeout_s": self.arm_timeout_s}), flush=True)
                    self.running = False
                    break
                nfq.run(block=False)
                self.maintain_selective_queue()
                time.sleep(0.0005)
        finally:
            if self.stop_reason == "running":
                self.stop_reason = "normal_exit"
            self.running = False
            self.cleanup_selective_queue()
            nfq.unbind()
            thread.join(timeout=1.0)
            self.flush_rule_buffers()
            self.flush()
            if reporter_thread is not None:
                reporter_thread.join(timeout=min(self.stats_interval + 0.1, 1.0))
            self.write_rule_stats()
            result = self.snapshot(summary, final=True)
            if self.result_json is not None:
                self.result_json.parent.mkdir(parents=True, exist_ok=True)
                self.result_json.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            print(json.dumps(result, ensure_ascii=False), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="Plan-driven SOCD-H NFQUEUE egress embedder.")
    parser.add_argument("--metadata", type=Path, required=True)
    parser.add_argument("--dilution-mode", choices=("legacy", "sparse3", "spread3"), default="legacy")
    parser.add_argument(
        "--sparse3-codebook",
        default="",
        help="Paper mapping parameter; intentionally blank.",
    )
    parser.add_argument("--sparse3-release-start-fraction", type=float)
    parser.add_argument("--sparse3-release-end-fraction", type=float)
    parser.add_argument("--port", type=int, default=45123)
    parser.add_argument("--direction", choices=("sport", "dport"), default="dport")
    parser.add_argument("--queue", type=int, default=20)
    parser.add_argument("--origin-offset", type=float, default=0.0)
    parser.add_argument("--min-release-gap", type=float, default=0.000001)
    parser.add_argument("--stats-interval", type=float, default=30.0)
    parser.add_argument("--result-json", type=Path)
    parser.add_argument("--rule-stats-csv", type=Path)
    parser.add_argument("--rule-stats-json", type=Path)
    parser.add_argument("--describe-only", action="store_true")
    parser.add_argument("--arm-file", type=Path, help="Wait for sender arm timestamp before starting the watermark clock.")
    parser.add_argument("--arm-timeout-s", type=float, default=60.0)
    parser.add_argument("--max-runtime-s", type=float, default=0.0, help="Stop after this many seconds; 0 disables timeout.")
    parser.add_argument("--min-rule-coverage", type=float, default=0.0, help="Mark result invalid below this coverage fraction.")
    parser.add_argument("--min-hits-per-rule", type=int, default=1, help="A rule is covered only if it is hit at least this many times.")
    parser.add_argument("--auto-align", action="store_true", help="Align the first active rule to the first matched payload packet after --warmup-s.")
    parser.add_argument("--warmup-s", type=float, default=0.0, help="Ignore matched payload packets before this many seconds after arming when --auto-align is enabled.")
    parser.add_argument("--hold-extra-s", type=float, default=0.0, help="Extend every rule's hold window earlier by this many seconds.")
    parser.add_argument("--window-cache-s", type=float, default=0.0, help="Bound rule-level candidate caching to this many seconds before release_start; 0 disables the bound.")
    parser.add_argument("--fallback-window-s", type=float, default=0.0, help="If strict source candidates are empty, allow this much pre-release fallback window; 0 disables fallback.")
    parser.add_argument("--max-hits-per-rule", type=int, default=3, help="Stop assigning delayed packets to a rule after this many hits.")
    parser.add_argument("--max-rule-delay-s", type=float, default=None, help="Optional hard runtime cap for planned per-rule delay; omit for R003 no-cap mode.")
    parser.add_argument("--release-inner-start-fraction", type=float, default=0.05, help="Lower fraction of release window used for planned releases.")
    parser.add_argument("--release-inner-end-fraction", type=float, default=0.50, help="Upper fraction of release window used for planned releases.")
    parser.add_argument("--release-jitter-fraction", type=float, default=0.02, help="Small deterministic jitter fraction added within the release inner window.")
    parser.add_argument("--fallback-delay-multiplier", type=float, default=1.0, help="Must remain 1.0 so fallback does not change the scheduled release policy.")
    parser.add_argument("--source-scan-extra-s", type=float, default=0.03, help="Expand source scan windows on both sides without expanding release windows.")
    parser.add_argument("--align-search-s", type=float, default=0.12, help="Search this many seconds around the first-packet auto-align offset.")
    parser.add_argument("--align-step-s", type=float, default=0.005, help="Step size for candidate-coverage auto-align search.")
    parser.add_argument("--align-min-packets", type=int, default=200, help="Collect at least this many matched packets before auto-align scoring.")
    parser.add_argument("--auto-align-max-offset-s", type=float, default=0.0, help="If positive, cap implausibly late auto-align offsets by falling back near --warmup-s.")
    parser.add_argument("--deadline-guard-s", type=float, default=0.0, help="Reserve this margin inside a finite actual-delay cap.")
    parser.add_argument("--selective-queue", action="store_true", help="After bootstrap, queue only active source candidate windows.")
    parser.add_argument("--iptables-rule-record", type=Path, help="node_agent's exact NFQUEUE rule record, used for safe selective-gate cleanup.")
    parser.add_argument("--queue-gate-lead-s", type=float, default=0.010, help="Firewall-command lead before a candidate scan window.")
    parser.add_argument("--queue-gate-tail-s", type=float, default=0.005, help="Firewall-command tail after a candidate scan window.")
    args = parser.parse_args()

    if not 0.0 <= args.min_rule_coverage <= 1.0:
        raise SystemExit("--min-rule-coverage must be between 0 and 1")
    if args.min_hits_per_rule < 1:
        raise SystemExit("--min-hits-per-rule must be >= 1")
    if args.warmup_s < 0:
        raise SystemExit("--warmup-s must be non-negative")
    if args.hold_extra_s < 0:
        raise SystemExit("--hold-extra-s must be non-negative")
    if args.window_cache_s < 0:
        raise SystemExit("--window-cache-s must be non-negative")
    if args.fallback_window_s < 0:
        raise SystemExit("--fallback-window-s must be non-negative")
    if args.max_hits_per_rule < 1:
        raise SystemExit("--max-hits-per-rule must be >= 1")
    if args.max_rule_delay_s is not None and not 0.0 < args.max_rule_delay_s:
        raise SystemExit("--max-rule-delay-s must be positive when supplied")
    if args.release_jitter_fraction < 0:
        raise SystemExit("--release-jitter-fraction must be non-negative")
    if abs(args.fallback_delay_multiplier - 1.0) > 1e-12:
        raise SystemExit("--fallback-delay-multiplier must be exactly 1.0")
    if args.source_scan_extra_s < 0:
        raise SystemExit("--source-scan-extra-s must be non-negative")
    if args.align_search_s < 0:
        raise SystemExit("--align-search-s must be non-negative")
    if args.align_step_s <= 0:
        raise SystemExit("--align-step-s must be positive")
    if args.align_min_packets < 1:
        raise SystemExit("--align-min-packets must be >= 1")
    if args.auto_align_max_offset_s < 0:
        raise SystemExit("--auto-align-max-offset-s must be non-negative")
    if args.deadline_guard_s < 0:
        raise SystemExit("--deadline-guard-s must be non-negative")
    if args.selective_queue and args.iptables_rule_record is None:
        raise SystemExit("--selective-queue requires --iptables-rule-record")
    if args.queue_gate_lead_s < 0 or args.queue_gate_tail_s < 0:
        raise SystemExit("--queue-gate-lead-s and --queue-gate-tail-s must be non-negative")
    try:
        sparse3_codebook = parse_sparse3_codebook(args.sparse3_codebook)
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc
    if args.result_json is not None:
        if args.rule_stats_csv is None:
            args.rule_stats_csv = args.result_json.with_name("per_rule_stats.csv")
        if args.rule_stats_json is None:
            args.rule_stats_json = args.result_json.with_name("rule_stats.json")

    rules, summary = load_rules(
        args.metadata,
        dilution_mode=args.dilution_mode,
        sparse3_release_start_fraction=args.sparse3_release_start_fraction,
        sparse3_release_end_fraction=args.sparse3_release_end_fraction,
        sparse3_codebook=sparse3_codebook,
    )
    if args.describe_only:
        print(json.dumps(summary, indent=2))
        return
    PlanEmbedder(
        rules=rules,
        queue_num=args.queue,
        port=args.port,
        direction=args.direction,
        origin_offset=args.origin_offset,
        min_release_gap=args.min_release_gap,
        stats_interval=max(args.stats_interval, 0.0),
        result_json=args.result_json,
        arm_file=args.arm_file,
        arm_timeout_s=max(args.arm_timeout_s, 0.0),
        max_runtime_s=max(args.max_runtime_s, 0.0),
        min_rule_coverage=args.min_rule_coverage,
        min_hits_per_rule=args.min_hits_per_rule,
        rule_stats_csv=args.rule_stats_csv,
        rule_stats_json=args.rule_stats_json,
        auto_align=args.auto_align,
        warmup_s=args.warmup_s,
        hold_extra_s=args.hold_extra_s,
        window_cache_s=args.window_cache_s,
        fallback_window_s=args.fallback_window_s,
        max_hits_per_rule=args.max_hits_per_rule,
        max_rule_delay_s=(math.inf if args.max_rule_delay_s is None else args.max_rule_delay_s),
        release_inner_start_fraction=args.release_inner_start_fraction,
        release_inner_end_fraction=args.release_inner_end_fraction,
        release_jitter_fraction=args.release_jitter_fraction,
        fallback_delay_multiplier=args.fallback_delay_multiplier,
        source_scan_extra_s=args.source_scan_extra_s,
        align_search_s=args.align_search_s,
        align_step_s=args.align_step_s,
        align_min_packets=args.align_min_packets,
        auto_align_max_offset_s=args.auto_align_max_offset_s,
        deadline_guard_s=args.deadline_guard_s,
        selective_queue=args.selective_queue,
        iptables_rule_record=args.iptables_rule_record,
        queue_gate_lead_s=args.queue_gate_lead_s,
        queue_gate_tail_s=args.queue_gate_tail_s,
    ).run(summary)


if __name__ == "__main__":
    main()
