#!/usr/bin/env python3
"""Create private embedder metadata and a truth-free SPDW-SR receiver plan."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from node_A.code.frame_codec import (
    CODED_BITS,
    CRC_BITS,
    LOGICAL_BITS,
    PAYLOAD_BITS,
    SPARSE3,
    build_frame,
)
from node_D.detect.spdw_sr_detector import build_public_plan

NOMINAL_FRAME_START_S = 0.0
WINDOW_S = 0.0
FRAME_DURATION_S = 0.0
DEFAULT_MAXIMUM_ADDED_DELAY_S = 0.0
ADDED_DELAY_POLICY = ""


def canonical_sha256(value: object) -> str:
    return hashlib.sha256(
        json.dumps(
            value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
    ).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".partial")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--session-id", required=True)
    parser.add_argument("--payload-bits", required=True)
    parser.add_argument("--private-output", type=Path, required=True)
    parser.add_argument("--public-output", type=Path, required=True)
    parser.add_argument("--start-s", type=float, default=NOMINAL_FRAME_START_S)
    parser.add_argument("--window-s", type=float, default=WINDOW_S)
    parser.add_argument("--duration-s", type=float, default=150.0)
    parser.add_argument("--rate-pps", type=float, default=120.0)
    parser.add_argument(
        "--maximum-added-delay-s",
        type=float,
        default=DEFAULT_MAXIMUM_ADDED_DELAY_S,
    )
    parser.add_argument("--added-delay-policy")
    args = parser.parse_args()
    if abs(args.start_s - NOMINAL_FRAME_START_S) > 1e-12:
        raise ValueError("SPDW-SR watermark-start parameter is blank")
    if abs(args.window_s - WINDOW_S) > 1e-12:
        raise ValueError("SPDW-SR window-duration parameter is blank")
    maximum_added_delay_s = float(args.maximum_added_delay_s)
    if not 0.0 < maximum_added_delay_s <= DEFAULT_MAXIMUM_ADDED_DELAY_S:
        raise ValueError("maximum-added-delay parameter is blank")
    added_delay_policy = args.added_delay_policy or ADDED_DELAY_POLICY
    if added_delay_policy != ADDED_DELAY_POLICY:
        raise ValueError("SPDW-SR requires the configured_hard_cap delay policy")

    frame = build_frame(
        public_session_id=args.session_id,
        payload_bits=args.payload_bits,
    )
    starts = [
        args.start_s + index * args.window_s
        for index in range(3 * LOGICAL_BITS)
    ]
    if starts[-1] + args.window_s > args.duration_s:
        raise ValueError("duration does not contain the configured frame")
    if abs(3 * LOGICAL_BITS * args.window_s - FRAME_DURATION_S) > 1e-12:
        raise AssertionError("paper frame geometry parameters are blank")

    private = {
        "schema": "spdw-sr-private-embedder-plan-v3",
        "frame_protocol": "",
        "session_id": args.session_id,
        "payload_bits": args.payload_bits,
        "payload_truth_available": True,
        "record_count": int(round(args.rate_pps * args.duration_s)),
        "rate_pps": args.rate_pps,
        "duration_seconds": args.duration_s,
        "plan": {
            "original_bits": "".join(map(str, frame.coded_bits)),
            "frame_bits": "".join(map(str, frame.logical_bits)),
            "payload_positions": [],
            "pair_starts": starts,
            "t": args.window_s,
            "config": {
            "plan_mode": "contiguous_intra_window_sparse3_hard_delay_cap",
                "pair_gap": 0.0,
                "min_window_packets": 8,
                "peak": {
                    "peak_start_fraction": 0.60,
                    "peak_end_fraction": 0.78,
                    "max_delay_fraction": maximum_added_delay_s / args.window_s,
                    "max_delay_cap": maximum_added_delay_s,
                    "min_window_packets": 8,
                    "min_holding_packets": 2,
                    "max_shift_packets": 64,
                    "min_release_gap": 0.001,
                },
            },
        },
        "keyed_plan": {
            "sync_bits": "".join(map(str, frame.sync_bits)),
            "payload_bits": PAYLOAD_BITS,
            "crc_bits": CRC_BITS,
            "crc_scope": "payload_only_M",
            "coded_bits": CODED_BITS,
            "logical_bits": LOGICAL_BITS,
            "sparse3_codebook": SPARSE3,
            "relative_delay_fraction": 0.0,
            "transfer_semantics": "intra_chip_early_to_late_delay",
            "maximum_actual_added_delay_s": maximum_added_delay_s,
            "added_delay_policy": added_delay_policy,
            "tbcc": {
                "constraint_length": 0,
                "generators_octal": [],
                "tail_biting_initial_state": "",
                "output_order": "",
                "interleaving": False,
            },
        },
        "success_definition": "infrastructure_valid AND crc_pass AND payload_exact",
        "watermark_mode": "watermarked",
    }
    private["canonical_sha256_before_field"] = canonical_sha256(private)
    public = build_public_plan(args.session_id)
    write_json(args.private_output, private)
    write_json(args.public_output, public)
    print(json.dumps({
        "schema": private["schema"],
        "logical_bits": LOGICAL_BITS,
        "sparse3_windows": 3 * LOGICAL_BITS,
        "frame_duration_s": 3 * LOGICAL_BITS * args.window_s,
        "crc_scope": "",
        "private_plan_sha256": canonical_sha256(private),
        "public_plan_sha256": public["canonical_sha256_before_field"],
    }))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
