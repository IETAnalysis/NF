"""Node-A plan generation and NFQUEUE embedding."""
