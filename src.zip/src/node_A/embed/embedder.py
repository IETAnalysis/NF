#!/usr/bin/env python3
"""Relative-share adapter for the SPDW-SR NFQUEUE timing embedder."""
from __future__ import annotations

import json
import math
import os
import sys

from node_A.embed import scheduler as base


def _extract_fraction() -> float:
    flag = "--delay-fraction"
    if flag in sys.argv:
        index = sys.argv.index(flag)
        try:
            value = float(sys.argv[index + 1])
        except (IndexError, ValueError) as exc:
            raise SystemExit(f"{flag} requires a numeric value") from exc
        del sys.argv[index:index + 2]
        return value
    return float(os.environ.get("SPDW_DELAY_FRACTION", "0"))


DELAY_FRACTION = _extract_fraction()


class RelativeTimingEmbedder(base.PlanEmbedder):
    def __init__(self, *args, **kwargs):
        if not 0.0 < DELAY_FRACTION <= 1.0:
            raise ValueError("SPDW-SR delay fraction must be in (0,1]")
        self.delay_fraction = DELAY_FRACTION
        super().__init__(*args, **kwargs)
        print(json.dumps({
            "event": "spdw_sr_relative_delay_enabled",
            "delay_fraction": self.delay_fraction,
            "quota_policy": "ceil(selectable_candidates * delay_fraction)",
            "transfer_semantics": "intra_chip_early_to_late_delay",
        }), flush=True)

    def finalize_rule_buffer(self, flow_key, ordinal):
        key = (flow_key, ordinal)
        with self.cache_lock:
            buffer = self.rule_buffers.get(key)
            if buffer is None or buffer.finalized:
                return
            selectable_count = sum(bool(item.selectable) for item in buffer.packets)
        relative_target = int(math.ceil(selectable_count * self.delay_fraction))
        return super().finalize_rule_buffer(
            flow_key,
            ordinal,
            quota_override=relative_target,
        )


base.PlanEmbedder = RelativeTimingEmbedder


if __name__ == "__main__":
    base.main()
