#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import socket
import time
from pathlib import Path
from typing import Any

from common.io_utils import sha256_file, utc_now, write_json


def set_common(sock: socket.socket, *, mss: int | None = None) -> None:
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    if mss:
        try:
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_MAXSEG, int(mss))
        except OSError:
            pass


def load_trace(path: Path | None, payload_bytes: int, chunk_size: int, rate_pps: float) -> list[tuple[int, float]]:
    if path is not None:
        data = json.loads(path.read_text(encoding='utf-8'))
        rows = data.get('events', data)
        trace = []
        for row in rows:
            length = int(row['payload_len'])
            gap = float(row.get('gap_s', row.get('inter_send_s', 0.0)))
            if length <= 0 or gap < 0:
                raise ValueError('invalid trace row')
            trace.append((length, gap))
        if not trace:
            raise ValueError('empty trace')
        return trace
    count = max(1, (payload_bytes + chunk_size - 1) // chunk_size)
    gap = 1.0 / rate_pps if rate_pps > 0 else 0.0
    return [(min(chunk_size, payload_bytes - i * chunk_size), gap if i else 0.0) for i in range(count)]


def sender(args: argparse.Namespace) -> None:
    payload = args.payload.read_bytes()
    if args.mss is not None and args.chunk_size > args.mss:
        raise SystemExit(
            f"chunk-size ({args.chunk_size}) exceeds configured TCP MSS "
            f"({args.mss}); use one application write per TCP segment"
        )
    expected_hash = args.payload_sha256 or hashlib.sha256(payload).hexdigest()
    if hashlib.sha256(payload).hexdigest() != expected_hash:
        raise SystemExit('payload SHA-256 mismatch')
    trace = load_trace(args.trace, len(payload), args.chunk_size, args.rate_pps)
    if sum(length for length, _ in trace) != len(payload):
        raise SystemExit('trace payload total differs from payload file')
    started_utc = utc_now()
    started_wall = time.time()
    started_mono = time.monotonic()
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        set_common(sock, mss=args.mss)
        sock.settimeout(args.timeout_s)
        if args.bind_ip:
            sock.bind((args.bind_ip, 0))
        sock.connect((args.host, args.port))
        local = list(sock.getsockname())
        remote = list(sock.getpeername())
        offset = 0
        event_rows: list[dict[str, Any]] = []
        cumulative_gap = 0.0
        for index, (length, gap_s) in enumerate(trace):
            cumulative_gap += gap_s
            if gap_s > 0:
                target = started_mono + cumulative_gap
                sleep = target - time.monotonic()
                if sleep > 0:
                    time.sleep(sleep)
            chunk = payload[offset : offset + length]
            before = time.monotonic()
            sock.sendall(chunk)
            after = time.monotonic()
            event_rows.append({
                'event_index': index,
                'byte_start': offset,
                'payload_len': length,
                'requested_gap_s': gap_s,
                'send_start_elapsed_s': before - started_mono,
                'send_complete_elapsed_s': after - started_mono,
            })
            offset += length
        try:
            sock.shutdown(socket.SHUT_WR)
        except OSError:
            pass
        completed_mono = time.monotonic()
    result = {
        'schema': 'spdw-sr-tcp-sender-result-v1',
        'terminal': True,
        'success': offset == len(payload),
        'started_utc': started_utc,
        'started_wall_s': started_wall,
        'duration_s': completed_mono - started_mono,
        'payload_path': str(args.payload),
        'payload_sha256': expected_hash,
        'payload_bytes': len(payload),
        'events': len(trace),
        'local_endpoint': local,
        'remote_endpoint': remote,
        'event_log': event_rows,
    }
    write_json(args.result_json, result)
    print(json.dumps({'type': 'sender_completed', **{k: result[k] for k in ('success','duration_s','payload_bytes')}}, ensure_ascii=False), flush=True)


def receiver(args: argparse.Namespace) -> None:
    args.output.parent.mkdir(parents=True, exist_ok=True)
    started_wall = time.time()
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((args.host, args.port))
        server.listen(1)
        server.settimeout(args.timeout_s)
        print('spdw_receiver_ready', flush=True)
        connection, peer = server.accept()
        with connection:
            set_common(connection)
            connection.settimeout(args.timeout_s)
            local = list(connection.getsockname())
            started_mono = time.monotonic()
            digest = hashlib.sha256()
            total = 0
            with args.output.open('wb') as handle:
                while True:
                    data = connection.recv(args.recv_buffer)
                    if not data:
                        break
                    handle.write(data)
                    digest.update(data)
                    total += len(data)
            completed_mono = time.monotonic()
    actual_hash = digest.hexdigest()
    expected_ok = args.expected_sha256 is None or actual_hash == args.expected_sha256
    result = {
        'schema': 'spdw-sr-tcp-receiver-result-v1',
        'terminal': True,
        'success': expected_ok,
        'started_wall_s': started_wall,
        'duration_s': completed_mono - started_mono,
        'receiver_completed_wall_s': time.time(),
        'payload_bytes': total,
        'payload_sha256': actual_hash,
        'expected_sha256': args.expected_sha256,
        'hash_match': expected_ok,
        'local_endpoint': local,
        'peer_endpoint': list(peer),
        'output_path': str(args.output),
    }
    write_json(args.result_json, result)
    print(json.dumps({'type': 'receiver_completed', 'success': expected_ok, 'payload_bytes': total}, ensure_ascii=False), flush=True)
    if not expected_ok:
        raise SystemExit(2)


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='command', required=True)
    send = sub.add_parser('sender')
    send.add_argument('--host', required=True)
    send.add_argument('--port', type=int, required=True)
    send.add_argument('--bind-ip')
    send.add_argument('--timeout-s', type=float, default=180)
    send.add_argument('--payload', type=Path, required=True)
    send.add_argument('--payload-sha256')
    send.add_argument('--trace', type=Path)
    send.add_argument('--chunk-size', type=int, default=1000)
    send.add_argument('--rate-pps', type=float, default=100)
    send.add_argument('--mss', type=int)
    send.add_argument('--result-json', type=Path, required=True)
    recv = sub.add_parser('receiver')
    recv.add_argument('--host', required=True)
    recv.add_argument('--port', type=int, required=True)
    recv.add_argument('--timeout-s', type=float, default=180)
    recv.add_argument('--expected-sha256')
    recv.add_argument('--recv-buffer', type=int, default=65536)
    recv.add_argument('--output', type=Path, required=True)
    recv.add_argument('--result-json', type=Path, required=True)
    args = parser.parse_args()
    if args.command == 'sender':
        sender(args)
    else:
        receiver(args)


if __name__ == '__main__':
    main()
