"""Node D: TCP receiver, capture, and SPDW-SR recovery."""
