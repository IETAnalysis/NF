"""Candidate scoring and constrained block-wise phase alignment."""

from node_D.detect.spdw_sr_detector import activity_score_matrix, best_block_phase_path, structural_score_matrix

__all__ = ["activity_score_matrix", "best_block_phase_path", "structural_score_matrix"]
