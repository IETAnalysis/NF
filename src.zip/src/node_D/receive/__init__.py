"""Application receiver interfaces."""

from .tcp_receiver import receiver

__all__ = ["receiver"]
