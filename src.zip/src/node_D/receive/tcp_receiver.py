"""Node-D TCP application receiver."""

from common.tcp_endpoint import receiver, set_common

__all__ = ["receiver", "set_common"]
