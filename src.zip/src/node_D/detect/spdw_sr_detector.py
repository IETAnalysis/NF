"""Truth-blind receiver for SPDW-SR.

The receiver sees only the receiver-ingress PCAP, destination port and a
truth-free public plan.  It reconstructs a sender-time reference from TCP
TSval when available, performs full-flow candidate search, applies constrained
dynamic-window alignment, soft TBCC decoding, and tests candidates in public
alignment-score order until CRC-8(M) passes.  No fixed synchronization
threshold is used as a candidate-acceptance rule.
"""
from __future__ import annotations

import argparse
import hashlib
import ipaddress
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
import struct
from typing import Any, Iterable

import numpy as np

from node_A.code.frame_codec import (
    CODED_BITS,
    LOGICAL_BITS,
    PAYLOAD_BITS,
    SYNC_BITS,
    bits_int,
    decode_body,
    FIXED_SYNC_WORD,
    FIXED_SYNC_WORD_HEX,
    fixed_sync_bits,
    validate_crc,
)

PCAP_MAGICS = {
    b"\xd4\xc3\xb2\xa1": ("<", 1_000_000.0),
    b"\xa1\xb2\xc3\xd4": (">", 1_000_000.0),
    b"\x4d\x3c\xb2\xa1": ("<", 1_000_000_000.0),
    b"\xa1\xb2\x3c\x4d": (">", 1_000_000_000.0),
}
ARM_ORDER = (
    "FULL",
    "NO_TSVAL",
    "NO_LOCAL_RESIDUAL",
    "FIXED_WINDOW",
    "HARD_DECISION",
)
# Receiver phase-grid parameters are intentionally blank in this package.
PHASE_GRID_SECONDS: tuple[float, ...] = ()
SOURCE_REGION: tuple[float, ...] = ()
RELEASE_REGION: tuple[float, ...] = ()
CHIPS_PER_BIT = 0


@dataclass(frozen=True)
class ModuleConfig:
    tsval_sender_reference: bool
    local_residual_correction: bool
    dynamic_window: bool
    soft_information: bool


FULL_MODULES = ModuleConfig(True, True, True, True)
ARM_MODULES = {
    "FULL": FULL_MODULES,
    "NO_TSVAL": ModuleConfig(False, True, True, True),
    "NO_LOCAL_RESIDUAL": ModuleConfig(True, False, True, True),
    "FIXED_WINDOW": ModuleConfig(True, True, False, True),
    "HARD_DECISION": ModuleConfig(True, True, True, False),
}


@dataclass(frozen=True)
class Segment:
    packet_index: int
    capture_time: float
    source_ip: str
    source_port: int
    destination_ip: str
    destination_port: int
    tcp_sequence: int
    payload_length: int
    tsval: int | None
    ipv4_id: int


def canonical_hash(value: object) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def one_factor_delta(arm: str) -> dict[str, dict[str, bool]]:
    if arm not in ARM_MODULES:
        raise ValueError(f"unknown SPDW-SR arm {arm}")
    current = asdict(ARM_MODULES[arm])
    full = asdict(FULL_MODULES)
    return {
        field: {"full": full[field], "arm": current[field]}
        for field in full
        if full[field] != current[field]
    }


def assert_strict_one_factor() -> None:
    if ARM_MODULES["FULL"] != FULL_MODULES:
        raise AssertionError("FULL module configuration changed")
    for arm in ARM_ORDER[1:]:
        if len(one_factor_delta(arm)) != 1:
            raise AssertionError(f"{arm} is not a one-factor arm")


def build_public_plan(public_session_id: str) -> dict[str, Any]:
    """Build the immutable truth-free receiver contract for one flow."""
    sync = "".join(map(str, fixed_sync_bits()))
    plan: dict[str, Any] = {
        "schema": "spdw-sr-public-receiver-plan-v3-fixed-sync",
        "public_session_id": str(public_session_id),
        "protocol": {
            "public_sync_bits": sync,
            "synchronization_mode": "fixed_word",
            "fixed_sync_word": FIXED_SYNC_WORD,
            "fixed_sync_word_hex": f"0x{FIXED_SYNC_WORD_HEX:02X}",
            "sync_bit_count": SYNC_BITS,
            "profile_id": "",
            "codec_id": "",
            "tbcc_constraint_length": 0,
            "tbcc_generators_octal": [],
            "tbcc_output_order": "",
            "tbcc_interleaving": False,
            "crc_id": "",
            "payload_bit_count": PAYLOAD_BITS,
            "coded_bit_count": CODED_BITS,
            "logical_bit_count": LOGICAL_BITS,
            "sparse_mapping": {},
        },
        "timing_template": {
            "chip_s": 0.0,
            "chips_per_logical_bit": CHIPS_PER_BIT,
            "logical_bit_offsets_s": [
                0.0
                for index in range(LOGICAL_BITS)
            ],
            "source_region_fraction": list(SOURCE_REGION),
            "release_region_fraction": list(RELEASE_REGION),
            "tsval_tick_s": 0.0,
            "local_baseline_quantile": 0.0,
            "local_baseline_horizon_s": 0.0,
            "minimum_local_baseline_packets": 0,
            "global_baseline_quantile": 0.0,
            "window_evidence_weights": {
                "source_deficit": 0.0,
                "positive_residual": 0.0,
            },
        },
        "candidate_search": {
            "full_flow_blind": True,
            "start_s": 0.0,
            "end_s": 0.0,
            "step_ms": 0,
            "retain_top": 0,
            "ranking_fields": [
                "coarse_structural_metric",
                "optimized_blockwise_alignment_metric",
                "earlier_public_grid_start_tiebreak",
            ],
            "fixed_sync_threshold_used_for_acceptance": False,
            "candidate_acceptance": "rank_then_decode_then_crc",
            "crc_used_in_ranking": False,
            "truth_used_in_ranking": False,
        },
        "dynamic_window": {
            "phase_grid_seconds": list(PHASE_GRID_SECONDS),
            "max_transition_phase_steps": 0,
            "logical_positions_per_block": 0,
            "smoothness_penalty_per_phase_step": 0.0,
            "retain_top_aligned": 0,
            "path_emission": {
                "public_sync_prefix": "known_complementary_structural_score",
                "unknown_coded_body": "bit_symmetric_complementary_structural_score",
            },
            "fixed_window_phase_s": 0.0,
        },
        "module_arms": {
            arm: {
                "modules": asdict(ARM_MODULES[arm]),
                "one_factor_delta": one_factor_delta(arm),
            }
            for arm in ARM_ORDER
        },
        "decoder_blindness": {
            "not_given": [
                "frame_start", "payload_truth", "coded_truth", "chip_truth",
                "channel_family", "channel_strength", "channel_seed",
                "realized_edit_positions",
            ],
            "private_plan_allowed": False,
        },
    }
    plan["canonical_sha256_before_field"] = canonical_hash(plan)
    assert_public_plan_truth_free(plan)
    return plan


def assert_public_plan_truth_free(plan: dict[str, Any]) -> None:
    if plan.get("schema") != "spdw-sr-public-receiver-plan-v3-fixed-sync":
        raise ValueError("unexpected SPDW-SR fixed-sync public-plan schema")
    expected = plan.get("canonical_sha256_before_field")
    value = dict(plan)
    value.pop("canonical_sha256_before_field", None)
    if expected != canonical_hash(value):
        raise ValueError("SPDW-SR public-plan hash mismatch")
    forbidden_exact = {
        "payload12", "payload_bits", "coded_bits", "logical_frame_bits",
        "chip_bits", "frame_start_s", "private_plan", "channel_seed",
        "channel_strength", "channel_family", "realized_edit_positions",
        "true_start",
    }

    def walk(node: object) -> Iterable[str]:
        if isinstance(node, dict):
            for key, item in node.items():
                yield str(key)
                yield from walk(item)
        elif isinstance(node, list):
            for item in node:
                yield from walk(item)

    leaked = sorted(set(walk(plan)) & forbidden_exact)
    if leaked:
        raise ValueError(f"private/truth fields leaked into public plan: {leaked}")

def _tcp_timestamp(options: bytes) -> int | None:
    index = 0
    while index < len(options):
        kind = options[index]
        if kind == 0:
            break
        if kind == 1:
            index += 1
            continue
        if index + 1 >= len(options):
            break
        length = options[index + 1]
        if length < 2 or index + length > len(options):
            break
        if kind == 8 and length == 10:
            return int(struct.unpack("!I", options[index + 2 : index + 6])[0])
        index += length
    return None


def _parse_ethernet_ipv4_tcp(
    frame: bytes,
    *,
    packet_index: int,
    capture_time: float,
) -> Segment | None:
    if len(frame) < 14 or frame[12:14] != b"\x08\x00":
        return None
    packet = frame[14:]
    if len(packet) < 20 or packet[0] >> 4 != 4 or packet[9] != 6:
        return None
    ip_header_length = (packet[0] & 0x0F) * 4
    total_length = int(struct.unpack("!H", packet[2:4])[0])
    if (
        ip_header_length < 20
        or total_length < ip_header_length
        or len(packet) < total_length
    ):
        return None
    source_ip = str(ipaddress.IPv4Address(packet[12:16]))
    destination_ip = str(ipaddress.IPv4Address(packet[16:20]))
    ipv4_id = int(struct.unpack("!H", packet[4:6])[0])
    tcp = packet[ip_header_length:total_length]
    if len(tcp) < 20:
        return None
    source_port, destination_port, sequence = struct.unpack("!HHI", tcp[:8])
    tcp_header_length = (tcp[12] >> 4) * 4
    if tcp_header_length < 20 or tcp_header_length > len(tcp):
        return None
    payload_length = len(tcp) - tcp_header_length
    if payload_length <= 0:
        return None
    return Segment(
        packet_index=packet_index,
        capture_time=float(capture_time),
        source_ip=source_ip,
        source_port=int(source_port),
        destination_ip=destination_ip,
        destination_port=int(destination_port),
        tcp_sequence=int(sequence),
        payload_length=int(payload_length),
        tsval=_tcp_timestamp(tcp[20:tcp_header_length]),
        ipv4_id=ipv4_id,
    )


def read_receiver_pcap(path: Path, destination_port: int) -> list[Segment]:
    segments: list[Segment] = []
    with path.open("rb") as stream:
        header = stream.read(24)
        if len(header) != 24 or header[:4] not in PCAP_MAGICS:
            raise ValueError(f"unsupported or truncated classic PCAP: {path}")
        byte_order, fraction_scale = PCAP_MAGICS[header[:4]]
        linktype = int(struct.unpack(f"{byte_order}I", header[20:24])[0])
        if linktype != 1:
            raise ValueError(f"SPDW-SR requires Ethernet PCAP linktype, got {linktype}")
        packet_index = 0
        while True:
            packet_header = stream.read(16)
            if not packet_header:
                break
            if len(packet_header) != 16:
                raise ValueError("truncated PCAP packet header")
            seconds, fraction, included, original = struct.unpack(
                f"{byte_order}IIII", packet_header
            )
            frame = stream.read(included)
            if len(frame) != included:
                raise ValueError("truncated PCAP frame")
            if included != original:
                raise ValueError("SPDW-SR refuses snaplen-truncated frames")
            segment = _parse_ethernet_ipv4_tcp(
                frame,
                packet_index=packet_index,
                capture_time=float(seconds) + float(fraction) / fraction_scale,
            )
            packet_index += 1
            if (
                segment is not None
                and segment.destination_port == int(destination_port)
            ):
                segments.append(segment)
    if not segments:
        raise ValueError("SPDW-SR target flow has no receiver payload segments")
    flows: dict[tuple[str, int, str, int], list[Segment]] = {}
    for segment in segments:
        key = (
            segment.source_ip,
            segment.source_port,
            segment.destination_ip,
            segment.destination_port,
        )
        flows.setdefault(key, []).append(segment)
    if len(flows) != 1:
        raise ValueError(
            "receiver port contains multiple TCP flows; a formal SPDW-SR "
            "decode must be bound to one target 4-tuple"
        )
    return next(iter(flows.values()))


def _unwrap(sequence: int, reference: int) -> int:
    delta = (int(sequence) - int(reference)) % (2**32)
    if delta >= 2**31:
        delta -= 2**32
    return int(reference) + delta


def first_arrivals(segments: list[Segment]) -> list[dict[str, Any]]:
    ordered = sorted(segments, key=lambda row: (row.capture_time, row.packet_index))
    reference = ordered[0].tcp_sequence
    seen_starts: set[int] = set()
    unique: list[dict[str, Any]] = []
    for row in ordered:
        unwrapped = _unwrap(row.tcp_sequence, reference)
        if unwrapped in seen_starts:
            continue
        seen_starts.add(unwrapped)
        unique.append(
            {
                "capture_time": float(row.capture_time),
                "application_byte_start": int(unwrapped - reference),
                "payload_length": int(row.payload_length),
                "tsval": row.tsval,
                "packet_index": int(row.packet_index),
            }
        )
    if not unique:
        raise ValueError("SPDW-SR has no first-arrival observations")
    return unique


def _quantile(values: list[float], probability: float) -> float:
    if not values:
        raise ValueError("quantile requires observations")
    ordered = sorted(float(value) for value in values)
    position = probability * (len(ordered) - 1)
    lower = int(math.floor(position))
    upper = int(math.ceil(position))
    if lower == upper:
        return ordered[lower]
    fraction = position - lower
    return ordered[lower] * (1.0 - fraction) + ordered[upper] * fraction


def _rolling_quantile(
    values: list[float], window: int, probability: float
) -> list[float]:
    radius = max(1, int(window) // 2)
    return [
        _quantile(
            values[max(0, index - radius) : min(len(values), index + radius + 1)],
            probability,
        )
        for index in range(len(values))
    ]


def _unwrap_tsval_axis(rows: list[dict[str, Any]]) -> tuple[list[float], dict[str, int]]:
    """Reconstruct sender time in TCP sequence order, not capture order.

    Watermark holding can release a packet carrying an older TSval after a
    packet carrying a newer TSval.  TSval therefore need not be monotone in
    receiver capture order, while it remains the sender-side reference tied
    to the packet's TCP sequence position.  Unwrapping in application-byte
    order preserves that reference and exposes the release reordering to the
    residual model instead of folding it into the counter unwrap.
    """
    axis_rows = sorted(
        rows,
        key=lambda row: (
            int(row["application_byte_start"]),
            int(row["packet_index"]),
        ),
    )
    raw_axis = [int(row["tsval"]) for row in axis_rows]
    if not raw_axis:
        raise ValueError("TSval axis requires at least one row")

    def steps(values: list[int]) -> list[int]:
        output: list[int] = []
        for previous, current in zip(values, values[1:]):
            delta = (int(current) - int(previous)) % (2**32)
            if delta >= 2**31:
                delta -= 2**32
            output.append(int(delta))
        return output

    axis_steps = steps(raw_axis)
    unwrapped = [raw_axis[0]]
    for delta in axis_steps:
        unwrapped.append(unwrapped[-1] + delta)
    origin = unwrapped[0]
    by_packet = {
        int(row["packet_index"]): float(value - origin)
        for row, value in zip(axis_rows, unwrapped)
    }
    capture_steps = steps([int(row["tsval"]) for row in rows])
    diagnostics = {
        "capture_order_negative_step_count": int(sum(value < 0 for value in capture_steps)),
        "capture_order_duplicate_step_count": int(sum(value == 0 for value in capture_steps)),
        "sequence_order_negative_step_count": int(sum(value < 0 for value in axis_steps)),
        "sequence_order_duplicate_step_count": int(sum(value == 0 for value in axis_steps)),
    }
    return [by_packet[int(row["packet_index"])] for row in rows], diagnostics


def prepare_observations(
    segments: list[Segment],
    *,
    sender_axis: str,
    baseline_mode: str,
    public_plan: dict[str, Any],
) -> dict[str, Any]:
    if sender_axis not in {"tsval", "sequence_rate"}:
        raise ValueError(f"unsupported sender axis {sender_axis}")
    if baseline_mode not in {"local", "global"}:
        raise ValueError(f"unsupported baseline mode {baseline_mode}")
    rows = first_arrivals(segments)
    capture_origin = min(float(row["capture_time"]) for row in rows)
    capture_times = [
        float(row["capture_time"]) - capture_origin for row in rows
    ]
    tsval_rows = sum(row["tsval"] is not None for row in rows)
    tsval_ordering: dict[str, int] = {}
    if sender_axis == "tsval":
        if tsval_rows != len(rows):
            raise ValueError(
                "SPDW-SR TSval arm requires complete first-arrival TSval coverage"
            )
        tick = float(public_plan["timing_template"]["tsval_tick_s"])
        sender_ticks, tsval_ordering = _unwrap_tsval_axis(rows)
        sender_times = [value * tick for value in sender_ticks]
    else:
        ordered_by_byte = sorted(
            rows,
            key=lambda row: (
                int(row["application_byte_start"]),
                int(row["packet_index"]),
            ),
        )
        span = max(
            int(row["application_byte_start"]) + int(row["payload_length"])
            for row in ordered_by_byte
        )
        duration = max(capture_times)
        sender_by_packet = {
            int(row["packet_index"]): (
                int(row["application_byte_start"]) / max(span, 1)
            )
            * duration
            for row in ordered_by_byte
        }
        sender_times = [
            float(sender_by_packet[int(row["packet_index"])]) for row in rows
        ]
    paired = sorted(zip(sender_times, capture_times), key=lambda row: row[0])
    sender_times = [float(row[0]) for row in paired]
    capture_times = [float(row[1]) for row in paired]
    residual = [
        capture - sender for sender, capture in zip(sender_times, capture_times)
    ]
    steps = [
        right - left
        for left, right in zip(sender_times, sender_times[1:])
        if right > left
    ]
    median_step = _quantile(steps, 0.50) if steps else 0.01
    timing = public_plan["timing_template"]
    baseline_packets = max(
        int(timing["minimum_local_baseline_packets"]),
        int(round(float(timing["local_baseline_horizon_s"]) / median_step)),
    )
    if baseline_mode == "local":
        baseline = _rolling_quantile(
            residual,
            baseline_packets,
            float(timing["local_baseline_quantile"]),
        )
    else:
        global_baseline = _quantile(
            residual, float(timing["global_baseline_quantile"])
        )
        baseline = [global_baseline] * len(residual)
    detrended = [
        value - local for value, local in zip(residual, baseline)
    ]
    detrended_median = _quantile(detrended, 0.50)
    residual_scale = max(
        1e-6,
        _quantile(
            [abs(value - detrended_median) for value in detrended], 0.50
        ),
    )
    corrected = [sender + value for sender, value in zip(sender_times, detrended)]
    return {
        "corrected_times": corrected,
        "sender_times": sender_times,
        "capture_times": capture_times,
        "positive_residuals": [
            max(value - residual_scale, 0.0) for value in detrended
        ],
        "residual_scale_s": float(residual_scale),
        "residual_scale_method": "MAD_of_detrended_residuals",
        "baseline_window_packets": int(baseline_packets),
        "sender_axis": sender_axis,
        "baseline_mode": baseline_mode,
        "first_arrival_segments": len(rows),
        "tsval_segments": int(tsval_rows),
        "tsval_coverage": float(tsval_rows / len(rows)),
        "tsval_unwrap_order": "application_byte_start" if sender_axis == "tsval" else None,
        "tsval_ordering": tsval_ordering,
    }


def _count_window(
    ordered_times: np.ndarray, lower: np.ndarray, upper: np.ndarray
) -> np.ndarray:
    return np.searchsorted(
        ordered_times, upper, side="left"
    ) - np.searchsorted(ordered_times, lower, side="left")


def _sum_window(
    ordered_times: np.ndarray,
    weights: np.ndarray,
    lower: np.ndarray,
    upper: np.ndarray,
) -> np.ndarray:
    """Sum sender-indexed evidence in each half-open time interval."""
    left = np.searchsorted(ordered_times, lower, side="left")
    right = np.searchsorted(ordered_times, upper, side="left")
    prefix = np.concatenate((np.asarray([0.0]), np.cumsum(weights)))
    return prefix[right] - prefix[left]


def activity_score_matrix(
    *,
    sender_times: list[float],
    corrected_times: list[float],
    positive_residuals: list[float],
    residual_scale_s: float,
    starts: np.ndarray,
    phases_s: np.ndarray,
    logical_count: int,
    public_plan: dict[str, Any],
) -> np.ndarray:
    """Evaluate the manuscript's source-deficit/release-surplus score ``g``.

    The score is evaluated for each candidate, logical position, phase and
    physical chip.  It remains independent of the unknown coded payload.
    """
    sender = np.asarray(sender_times, dtype=np.float64)
    if sender.size != len(corrected_times) or sender.size != len(positive_residuals):
        raise ValueError("sender, corrected and residual evidence rows differ")
    corrected = np.asarray(sorted(float(value) for value in corrected_times), dtype=np.float64)
    residual_weights = np.asarray(positive_residuals, dtype=np.float64)
    if np.any(np.diff(sender) < 0.0):
        raise ValueError("sender-time observations must be ordered before scoring")

    timing = public_plan["timing_template"]
    chip_s = float(timing["chip_s"])
    source_fraction = tuple(float(value) for value in timing["source_region_fraction"])
    release_fraction = tuple(float(value) for value in timing["release_region_fraction"])
    if not 0.0 <= source_fraction[0] < source_fraction[1] <= release_fraction[0] < release_fraction[1] <= 1.0:
        raise ValueError("source/release regions must be ordered within a chip")
    source_duration = (source_fraction[1] - source_fraction[0]) * chip_s
    release_duration = (release_fraction[1] - release_fraction[0]) * chip_s
    weights = timing.get("window_evidence_weights", {})
    source_deficit_weight = float(weights.get("source_deficit", 1.0))
    residual_weight = float(weights.get("positive_residual", 1.0))
    logical_offsets = np.arange(logical_count, dtype=np.float64) * CHIPS_PER_BIT * chip_s
    output = np.empty((len(starts), logical_count, len(phases_s), CHIPS_PER_BIT), dtype=np.float64)

    for phase_index, phase_s in enumerate(phases_s):
        for chip_index in range(CHIPS_PER_BIT):
            nominal = (
                starts[:, None]
                + logical_offsets[None, :]
                + chip_index * chip_s
                + float(phase_s)
            )
            source_lower = nominal + source_fraction[0] * chip_s
            source_upper = nominal + source_fraction[1] * chip_s
            release_lower = nominal + release_fraction[0] * chip_s
            release_upper = nominal + release_fraction[1] * chip_s
            source_count = _count_window(sender, source_lower, source_upper).astype(np.float64)
            corrected_source_count = _count_window(corrected, source_lower, source_upper).astype(np.float64)
            corrected_release_count = _count_window(corrected, release_lower, release_upper).astype(np.float64)
            observed = corrected_source_count + corrected_release_count
            expected_release = observed * release_duration / (source_duration + release_duration)
            release_variance = np.maximum(
                observed * source_duration * release_duration / (source_duration + release_duration) ** 2,
                1.0,
            )
            release_surplus = (corrected_release_count - expected_release) / np.sqrt(release_variance)
            source_deficit = (source_count - corrected_source_count) / np.sqrt(np.maximum(source_count, 1.0))
            positive_evidence = _sum_window(sender, residual_weights, source_lower, source_upper)
            positive_evidence /= np.sqrt(np.maximum(source_count, 1.0))
            positive_evidence = np.minimum(
                positive_evidence / max(float(residual_scale_s), 1e-6),
                6.0,
            )
            output[:, :, phase_index, chip_index] = (
                release_surplus
                + source_deficit_weight * source_deficit
                + residual_weight * positive_evidence
            )
    return output


def structural_score_matrix(activity: np.ndarray, sync_bits: list[int]) -> np.ndarray:
    """Compute the public-sync and payload-independent structural scores."""
    if activity.shape[1] != LOGICAL_BITS or activity.shape[3] != CHIPS_PER_BIT:
        raise ValueError("structural-score geometry parameters are blank")
    output = np.empty(activity.shape[:3], dtype=np.float64)
    for logical_index, sync_bit in enumerate(sync_bits):
        active = 0
        complementary = 3 - active
        output[:, logical_index, :] = (
            activity[:, logical_index, :, active]
            - 0.5 * (
                activity[:, logical_index, :, complementary]
                + activity[:, logical_index, :, 0]
            )
        )
    output[:, SYNC_BITS:, :] = (
        0.5 * (activity[:, SYNC_BITS:, :, 1] + activity[:, SYNC_BITS:, :, 2])
        - activity[:, SYNC_BITS:, :, 0]
    )
    return output


def best_block_phase_path(
    structural: np.ndarray,
    *,
    positions_per_block: int,
    max_transition_steps: int,
    smoothness_penalty: float,
) -> tuple[list[int], list[int], float]:
    """Optimize the manuscript's block-wise constrained phase path."""
    if structural.shape[0] != LOGICAL_BITS:
        raise ValueError("phase-path geometry parameters are blank")
    if positions_per_block <= 0 or LOGICAL_BITS % positions_per_block:
        raise ValueError("logical positions must form equal dynamic-alignment blocks")
    phase_count = structural.shape[1]
    block_count = LOGICAL_BITS // positions_per_block
    emissions = np.empty((block_count, phase_count), dtype=np.float64)
    for block in range(block_count):
        lower = block * positions_per_block
        upper = lower + positions_per_block
        emissions[block, :] = np.sum(structural[lower:upper, :], axis=0)

    state = emissions[0, :].copy()
    backpointers: list[np.ndarray] = []
    for block in range(1, block_count):
        next_state = np.full(phase_count, -np.inf, dtype=np.float64)
        previous = np.zeros(phase_count, dtype=np.int64)
        for current in range(phase_count):
            lower = max(0, current - max_transition_steps)
            upper = min(phase_count, current + max_transition_steps + 1)
            candidates = state[lower:upper] - smoothness_penalty * np.abs(
                np.arange(lower, upper) - current
            )
            selected = lower + int(np.argmax(candidates))
            next_state[current] = emissions[block, current] + state[selected] - smoothness_penalty * abs(selected - current)
            previous[current] = selected
        state = next_state
        backpointers.append(previous)
    block_path = [int(np.argmax(state))]
    final_metric = float(state[block_path[0]])
    for previous in reversed(backpointers):
        block_path.append(int(previous[block_path[-1]]))
    block_path.reverse()
    logical_path = [phase for phase in block_path for _ in range(positions_per_block)]
    return logical_path, block_path, final_metric


def _rank_top(metrics: np.ndarray, starts: np.ndarray, retain: int) -> list[tuple[float, float, int]]:
    order = sorted(
        ((float(metrics[index]), float(starts[index]), int(index)) for index in range(len(starts))),
        key=lambda row: (-row[0], row[1]),
    )
    return order[: min(retain, len(order))]


def decode_segments(
    segments: list[Segment],
    public_plan: dict[str, Any],
    arm: str,
) -> dict[str, Any]:
    assert_strict_one_factor()
    assert_public_plan_truth_free(public_plan)
    if arm not in ARM_MODULES:
        raise ValueError(f"unknown SPDW-SR arm {arm}")
    modules = ARM_MODULES[arm]
    observations = prepare_observations(
        segments,
        sender_axis=("tsval" if modules.tsval_sender_reference else "sequence_rate"),
        baseline_mode=("local" if modules.local_residual_correction else "global"),
        public_plan=public_plan,
    )
    timing = public_plan["timing_template"]
    chip_s = float(timing["chip_s"])
    frame_s = LOGICAL_BITS * CHIPS_PER_BIT * chip_s
    if max(observations["sender_times"]) - min(observations["sender_times"]) < frame_s:
        return {
            "schema": "spdw-sr-receiver-result-v3-fixed-sync",
            "terminal": True,
            "decode_completed": False,
            "arm": arm,
            "reason": "capture_too_short_for_72s_frame",
            "modules": asdict(modules),
            "observations": observations,
        }

    search = public_plan["candidate_search"]
    step_s = float(search["step_ms"]) / 1000.0
    start_s = float(search["start_s"])
    end_s = float(search["end_s"])
    candidate_count = int(round((end_s - start_s) / step_s)) + 1
    starts = start_s + np.arange(candidate_count, dtype=np.float64) * step_s
    dynamic = public_plan["dynamic_window"]
    phases_s = np.asarray(
        dynamic["phase_grid_seconds"] if modules.dynamic_window else [dynamic["fixed_window_phase_s"]],
        dtype=np.float64,
    )
    transition_steps = int(dynamic["max_transition_phase_steps"]) if modules.dynamic_window else 0
    positions_per_block = int(dynamic["logical_positions_per_block"])
    smoothness_penalty = float(dynamic["smoothness_penalty_per_phase_step"])
    declared_sync = str(public_plan["protocol"].get("public_sync_bits", ""))
    if declared_sync != FIXED_SYNC_WORD:
        raise ValueError(
            "receiver plan synchronization word does not match the blank parameter set"
        )
    sync_bits = fixed_sync_bits()

    activity = activity_score_matrix(
        sender_times=observations["sender_times"],
        corrected_times=observations["corrected_times"],
        positive_residuals=observations["positive_residuals"],
        residual_scale_s=float(observations["residual_scale_s"]),
        starts=starts,
        phases_s=phases_s,
        logical_count=LOGICAL_BITS,
        public_plan=public_plan,
    )
    structural = structural_score_matrix(activity, sync_bits)
    zero_phase = int(np.argmin(np.abs(phases_s)))
    coarse_metrics = np.sum(structural[:, :, zero_phase], axis=1)
    coarse_candidates = _rank_top(
        coarse_metrics, starts, int(search["retain_top"])
    )

    aligned_candidates: list[dict[str, Any]] = []
    for coarse_rank, (coarse_metric, start, ordinal) in enumerate(coarse_candidates, 1):
        phase_path, block_path, alignment_metric = best_block_phase_path(
            structural[ordinal, :, :],
            positions_per_block=positions_per_block,
            max_transition_steps=transition_steps,
            smoothness_penalty=smoothness_penalty,
        )
        aligned_candidates.append(
            {
                "coarse_rank": coarse_rank,
                "coarse_metric": coarse_metric,
                "alignment_metric": alignment_metric,
                "start_s": start,
                "grid_ordinal": ordinal,
                "phase_path_indices": phase_path,
                "block_phase_indices": block_path,
            }
        )
    aligned_candidates.sort(key=lambda row: (-float(row["alignment_metric"]), float(row["start_s"])))
    aligned_candidates = aligned_candidates[: int(dynamic["retain_top_aligned"])]

    decoded_candidates: list[dict[str, Any]] = []
    selected: dict[str, Any] | None = None
    for rank, candidate_seed in enumerate(aligned_candidates, 1):
        ordinal = int(candidate_seed["grid_ordinal"])
        path = list(candidate_seed["phase_path_indices"])
        logical_llr = [
            float(
                activity[ordinal, logical_index, phase_index, 1]
                - activity[ordinal, logical_index, phase_index, 2]
            )
            for logical_index, phase_index in enumerate(path)
        ]
        body_llr = logical_llr[SYNC_BITS:]
        decoder_input = (
            body_llr
            if modules.soft_information
            else [1.0 if value >= 0.0 else -1.0 for value in body_llr]
        )
        body, decoder_metric, circular_state = decode_body(decoder_input)
        payload = body[:PAYLOAD_BITS]
        crc = body[PAYLOAD_BITS:]
        candidate = {
            **candidate_seed,
            "rank": rank,
            "sync_metric": float(candidate_seed["coarse_metric"]),
            "phase_path_seconds": [float(phases_s[index]) for index in path],
            "block_phase_seconds": [float(phases_s[index]) for index in candidate_seed["block_phase_indices"]],
            "body_soft_llr": body_llr,
            "decoder_metric": float(decoder_metric),
            "circular_initial_final_state": int(circular_state),
            "recovered_payload_bits": "".join(map(str, payload)),
            "recovered_payload12": bits_int(payload),
            "recovered_crc_bits": "".join(map(str, crc)),
            "crc_pass": bool(validate_crc(body)),
        }
        decoded_candidates.append(candidate)
        if candidate["crc_pass"]:
            selected = candidate
            break

    result: dict[str, Any] = {
        "schema": "spdw-sr-receiver-result-v3-fixed-sync",
        "terminal": True,
        "decode_completed": bool(selected is not None),
        "arm": arm,
        "modules": asdict(modules),
        "one_factor_delta": one_factor_delta(arm),
        "public_plan_sha256": public_plan["canonical_sha256_before_field"],
        "candidate_count": candidate_count,
        "coarse_candidate_budget": int(search["retain_top"]),
        "aligned_candidate_budget": int(dynamic["retain_top_aligned"]),
        "candidate_ranking": "coarse_structural_score_then_blockwise_alignment_score_then_crc8_M",
        "candidate_acceptance": "rank_then_soft_tbcc_k3_decode_then_crc8_M",
        "fixed_sync_threshold_used_for_acceptance": False,
        "crc_used_in_candidate_ranking": False,
        "truth_used_in_candidate_ranking": False,
        "sync_success": bool(aligned_candidates),
        "top_candidates_decoded": decoded_candidates,
        "phase_grid_seconds": phases_s.tolist(),
        "max_transition_phase_steps": transition_steps,
        "logical_positions_per_block": positions_per_block,
        "decision_mode": "soft_metric" if modules.soft_information else "hard_sign",
        "observations": observations,
        "receiver_was_not_given": public_plan["decoder_blindness"]["not_given"],
    }
    if selected is None:
        result.update(
            {
                "reason": "no_crc8_M_verified_candidate",
                "selected_candidate_rank": None,
                "selected_start_s": None,
                "selected_grid_ordinal": None,
                "sync_metric": None,
                "alignment_metric": None,
                "selected_phase_path_indices": None,
                "selected_phase_path_seconds": None,
                "transmitted_coded_soft_llr": None,
                "decoder_metric": None,
                "circular_initial_final_state": None,
                "recovered_payload_bits": None,
                "recovered_payload12": None,
                "recovered_crc_bits": None,
                "crc_pass": False,
                "confirmed_without_threshold": False,
            }
        )
        return result

    result.update(
        {
            "selected_candidate_rank": int(selected["rank"]),
            "selected_start_s": float(selected["start_s"]),
            "selected_grid_ordinal": int(selected["grid_ordinal"]),
            "sync_metric": float(selected["sync_metric"]),
            "alignment_metric": float(selected["alignment_metric"]),
            "selected_phase_path_indices": selected["phase_path_indices"],
            "selected_phase_path_seconds": selected["phase_path_seconds"],
            "transmitted_coded_soft_llr": selected["body_soft_llr"],
            "decoder_metric": selected["decoder_metric"],
            "circular_initial_final_state": selected["circular_initial_final_state"],
            "recovered_payload_bits": selected["recovered_payload_bits"],
            "recovered_payload12": selected["recovered_payload12"],
            "recovered_crc_bits": selected["recovered_crc_bits"],
            "crc_pass": True,
            "confirmed_without_threshold": True,
        }
    )
    return result


def decode_pcap(
    pcap_path: Path,
    destination_port: int,
    public_plan: dict[str, Any],
    arm: str,
) -> dict[str, Any]:
    segments = read_receiver_pcap(pcap_path, destination_port)
    result = decode_segments(segments, public_plan, arm)
    result.update(
        {
            "receiver_pcap_path": str(pcap_path),
            "receiver_pcap_sha256": sha256_file(pcap_path),
            "receiver_payload_segment_rows": len(segments),
        }
    )
    return result


def write_json(path: Path, value: object) -> None:
    if path.exists():
        raise FileExistsError(f"refusing to overwrite {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_suffix(path.suffix + ".partial")
    partial.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    partial.replace(path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pcap", type=Path, required=True)
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--public-plan", type=Path, required=True)
    parser.add_argument("--arm", choices=ARM_ORDER, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    plan = json.loads(args.public_plan.read_text(encoding="utf-8"))
    result = decode_pcap(args.pcap, args.port, plan, args.arm)
    write_json(args.output, result)
    print(
        json.dumps(
            {
                "arm": args.arm,
                "decode_completed": result["decode_completed"],
                "output": str(args.output),
            }
        )
    )


if __name__ == "__main__":
    main()
