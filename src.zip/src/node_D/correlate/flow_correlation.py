"""Five-tuple equality used to associate capture records with a target flow."""

from __future__ import annotations

from typing import Mapping


def same_five_tuple(left: Mapping[str, object], right: Mapping[str, object]) -> bool:
    fields = ("src_ip", "src_port", "dst_ip", "dst_port", "protocol")
    return all(left.get(field) == right.get(field) for field in fields)
