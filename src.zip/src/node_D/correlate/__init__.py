"""Optional flow-correlation interfaces."""
