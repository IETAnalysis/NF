"""Explicit receiver-side steps corresponding to the paper method.

Every numeric method parameter is supplied by the caller or public plan.  No
paper parameter value is embedded in this interface layer.
"""
from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from node_A.code.frame_codec import PAYLOAD_BITS, decode_body, validate_crc
from node_D.detect.spdw_sr_detector import (
    Segment,
    activity_score_matrix,
    best_block_phase_path,
    decode_pcap,
    decode_segments,
    first_arrivals,
    prepare_observations,
    read_receiver_pcap,
    structural_score_matrix,
)


@dataclass(frozen=True)
class CandidateRecovery:
    """Soft-decoder output for one ranked alignment candidate."""

    payload_bits: tuple[int, ...]
    body_bits: tuple[int, ...]
    decoder_metric: float
    circular_state: int
    crc_pass: bool


def select_target_flow(pcap_path: Path, destination_port: int) -> list[Segment]:
    """Select one receiver-side target TCP flow from a capture."""
    return read_receiver_pcap(pcap_path, destination_port)


def retain_first_arrivals(segments: list[Segment]) -> list[dict[str, Any]]:
    """Remove retransmitted or duplicate observations before reconstruction."""
    return first_arrivals(segments)


def reconstruct_temporal_reference(
    segments: list[Segment],
    *,
    sender_axis: str,
    baseline_mode: str,
    public_plan: dict[str, Any],
) -> dict[str, Any]:
    """Reconstruct sender-relative time and apply local residual correction."""
    return prepare_observations(
        segments,
        sender_axis=sender_axis,
        baseline_mode=baseline_mode,
        public_plan=public_plan,
    )


def generate_candidate_grid(
    *, start_s: float, end_s: float, step_s: float
) -> np.ndarray:
    """Generate coarse synchronization offsets on a caller-defined grid."""
    if step_s <= 0.0:
        raise ValueError("candidate-grid step must be supplied")
    if end_s < start_s:
        raise ValueError("candidate-grid end precedes start")
    count = int(round((end_s - start_s) / step_s)) + 1
    return start_s + np.arange(count, dtype=np.float64) * step_s


def score_synchronization_candidates(
    *,
    sender_times: list[float],
    corrected_times: list[float],
    positive_residuals: list[float],
    residual_scale_s: float,
    starts: np.ndarray,
    phases_s: np.ndarray,
    logical_count: int,
    public_plan: dict[str, Any],
    sync_bits: list[int],
) -> tuple[np.ndarray, np.ndarray]:
    """Build window evidence and synchronization-structure scores."""
    activity = activity_score_matrix(
        sender_times=sender_times,
        corrected_times=corrected_times,
        positive_residuals=positive_residuals,
        residual_scale_s=residual_scale_s,
        starts=starts,
        phases_s=phases_s,
        logical_count=logical_count,
        public_plan=public_plan,
    )
    return activity, structural_score_matrix(activity, sync_bits)


def align_dynamic_windows(
    structural_scores: np.ndarray,
    *,
    positions_per_block: int,
    max_transition_steps: int,
    smoothness_penalty: float,
) -> tuple[list[int], list[int], float]:
    """Find the continuity-constrained optimal block-phase path."""
    return best_block_phase_path(
        structural_scores,
        positions_per_block=positions_per_block,
        max_transition_steps=max_transition_steps,
        smoothness_penalty=smoothness_penalty,
    )


def soft_decode_candidate(coded_soft_metrics: Iterable[float]) -> CandidateRecovery:
    """Soft-decode one candidate and perform CRC consistency verification."""
    body, metric, state = decode_body([float(value) for value in coded_soft_metrics])
    payload = tuple(int(bit) for bit in body[:PAYLOAD_BITS])
    return CandidateRecovery(
        payload_bits=payload,
        body_bits=tuple(int(bit) for bit in body),
        decoder_metric=float(metric),
        circular_state=int(state),
        crc_pass=bool(validate_crc(body)),
    )


def accept_first_crc_valid(
    ranked_candidate_metrics: Iterable[Iterable[float]],
) -> CandidateRecovery | None:
    """Try ranked candidates in order and accept the first CRC-valid result."""
    for candidate_metrics in ranked_candidate_metrics:
        recovery = soft_decode_candidate(candidate_metrics)
        if recovery.crc_pass:
            return recovery
    return None


def recover_from_segments(
    segments: list[Segment], public_plan: dict[str, Any], arm: str
) -> dict[str, Any]:
    """Execute the integrated receiver algorithm on parsed TCP segments."""
    return decode_segments(segments, public_plan, arm)


def recover_from_pcap(
    pcap_path: Path,
    destination_port: int,
    public_plan: dict[str, Any],
    arm: str,
) -> dict[str, Any]:
    """Execute the integrated receiver algorithm on a classic PCAP."""
    return decode_pcap(pcap_path, destination_port, public_plan, arm)


__all__ = [
    "CandidateRecovery",
    "accept_first_crc_valid",
    "align_dynamic_windows",
    "generate_candidate_grid",
    "recover_from_pcap",
    "recover_from_segments",
    "reconstruct_temporal_reference",
    "retain_first_arrivals",
    "score_synchronization_candidates",
    "select_target_flow",
    "soft_decode_candidate",
]

