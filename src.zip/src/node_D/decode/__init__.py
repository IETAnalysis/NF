"""Soft SPDW-SR decoding interface."""

from .soft_decoder import decode_pcap, decode_segments

__all__ = ["decode_pcap", "decode_segments"]
