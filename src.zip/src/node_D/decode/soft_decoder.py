"""Soft-metric TBCC decoding and CRC-verified candidate acceptance."""

from node_D.detect.spdw_sr_detector import decode_pcap, decode_segments

__all__ = ["decode_pcap", "decode_segments"]
