"""Node C: NAT, routing, and ingress/egress capture."""
