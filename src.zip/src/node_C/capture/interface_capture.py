"""Construct a lossless tcpdump command for a monitored TCP flow."""

from __future__ import annotations

from pathlib import Path


def tcpdump_command(*, interface: str, port: int, output: Path, snaplen: int = 0) -> list[str]:
    return ["tcpdump", "-U", "-n", "-i", interface, "-s", str(snaplen), "-B", "65536", "-w", str(output), f"tcp port {int(port)}"]
