"""Node-C capture command helpers."""

from .interface_capture import tcpdump_command

__all__ = ["tcpdump_command"]
