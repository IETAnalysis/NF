"""Build or apply the node-C DNAT/MASQUERADE rule set."""

from __future__ import annotations

import subprocess


def nat_commands(*, ingress_iface: str, egress_iface: str, destination: str, port: int) -> list[list[str]]:
    target = f"{destination}:{int(port)}"
    return [
        ["sysctl", "-w", "net.ipv4.ip_forward=1"],
        ["iptables", "-t", "nat", "-A", "PREROUTING", "-i", ingress_iface, "-p", "tcp", "--dport", str(port), "-j", "DNAT", "--to-destination", target],
        ["iptables", "-t", "nat", "-A", "POSTROUTING", "-o", egress_iface, "-p", "tcp", "-d", destination, "--dport", str(port), "-j", "MASQUERADE"],
        ["iptables", "-A", "FORWARD", "-p", "tcp", "-d", destination, "--dport", str(port), "-j", "ACCEPT"],
    ]


def configure_nat(**kwargs: object) -> list[list[str]]:
    commands = nat_commands(**kwargs)  # type: ignore[arg-type]
    for command in commands:
        subprocess.run(command, check=True)
    return commands
